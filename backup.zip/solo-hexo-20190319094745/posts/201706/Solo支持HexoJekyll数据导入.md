title: Solo 支持 Hexo/Jekyll 数据导入
date: '2017-06-27 07:17:11'
updated: '2017-06-28 01:24:07'
tags: [Solo, Hexo, Jekyll, 导入]
permalink: /articles/2017/06/26/1498490209748.html
---
自 [Solo](https://hacpai.com/tag/Solo) 2.2.0 开始将支持对 Hexo/Jekyll 两款静态博客系统的文章导入，具体使用方法如下：

1. 在 Solo 根目录下放置 markdowns 目录，里面放置待导入的一些 md 文件（可新建目录，方便标识，比如可将 Hexo 的 \_posts 文件夹直接拷贝进来）
2. 重启 Solo，启动后将逐篇进行自动导入，可通过日志查看导入情况
3. 导入结束后原 md 文件将被重命名为 .md.{时间毫秒} 这样的格式，如不需要，可将这类后缀的文件删除
4. 导入失败的 md 文件不会被重命名，可将日志和 md 文件反馈给我们，以帮助我们继续改进 :heartbeat: 

另外，目前仅支持已发布的 post，不支持 draft、page 等。

----

Some technical details

每个 md 文件都会按照 Hexo/Jekyll 定义的头部进行解析，已确定标题、标签等：

* [Hexo 头](https://hexo.io/zh-cn/docs/front-matter.html)
* [Jekyll 头](https://jekyllrb.com/docs/frontmatter/) 
* 支持头信息中使用 `description`、`summary`、`abstract` 作为文章摘要，如果没有的话将自动截取正文部分
* 如果没有定义头信息，或者解析失败，则以文件名作为标题、`Note`作为标签、当前时间作为发布时间进行导入，这也是导入普通 md 文件的规则
