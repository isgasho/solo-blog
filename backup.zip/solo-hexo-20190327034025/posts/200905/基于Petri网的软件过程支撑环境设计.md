title: 基于 Petri 网的软件过程支撑环境设计
date: '2009-05-04 15:34:00'
updated: '2009-05-04 15:34:00'
tags: [BeyondTrack, J2EE/JavaEE, Software Engineering, JBoss Seam, Mathematics]
permalink: /articles/2009/05/03/1241393640000.html
---
<div>
<div>
<div>
<h1>基于 Petri 网的软件过程支撑环境设计<br /></h1>
<br />
<div id="WritelyTableOfContents" class="writely-toc"><ol class="writely-toc-none">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_High_Level_Petri_Nets_1570396" target="_self">基于 Petri 网的软件过程支撑环境设计</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_8003452663834293_446333391194_2229142286479019" target="_self">摘要</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_1_1388352720116368_2716843567" target="_self">第 1 章 绪论</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_1_5159390391271211_275953689" target="_self">1.1 软件过程与过程建模</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_3__780068034589648" target="_self">1.3 软件过程支撑环境现状</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_3_00018081280370307873_94404" target="_self">1.3 本课题的研究内容及意义</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_3_1_028681047868219456_00648" target="_self">1.3.1 研究内容</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_3_2_11199214029270765_852720" target="_self">1.3.2 意义</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#1_4_Petri_Nets_925016248581512" target="_self">1.4 Petri 网简介</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_2_8308693370062991_3526675778" target="_self">第 2 章 软件过程定义语言</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_1_SPDL_040858003565423906_09_4259748263509201" target="_self">2.1 SPDL 概述</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_2_SPDL_025611659795485298_34_004932047498921066" target="_self">2.2 SPDL 元模型</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_2_2_XML_Schema_5824128249899" target="_self">2.2.1 XML Schema</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_2_37726097486484167_37019983_6280798376486112" target="_self">2.3 模型变换</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_2_1_SPDL_Java_10170411018148_8048523622885639" target="_self">2.3.1 SPDL 域到 Java 域的变换</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_1_06316301911600453_93956129_7826743534428375" target="_self">2.3.2 SPDL 实例的 Petri 网图生成</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_3_2_1_6909392616490296_65774_874312677230697" target="_self">2.3.2.1 基元块</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_3_2_2_026949359406927442_152_03583747535352089" target="_self">2.3.2.2 Petri 网图生成</a></li>
</ol></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#2_4_SPDL_7633491211394602_2876_46701420512155445" target="_self">2.4 基于 SPDL 的软件过程建模方法</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_3_18324534912390866_428228514" target="_self">第 3 章 软件过程执行控制</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#3_1_6162554744702771_786880372_6190911951750134" target="_self">3.1 过程生存周期</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#3_3_2_6247080558796566_9465532_6578297759450403" target="_self">3.2 过程执行控制</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#3_2_1_23129765298025928_670078_3917669516068203" target="_self">3.2.1 标记网初始化</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#3_2_2_8100095147149176_5749420" target="_self">3.2.2 点火控制</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#3_3_42911771617760786_45381730_9634287789530159" target="_self">3.3 历史追踪</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_4_3833686623076361_6622715409" target="_self">第 4 章 软件过程支撑环境设计</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#4_1_BeyondTrack_29861802095786" target="_self">4.1 BeyondTrack 项目简介</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#4_2_5742416844827937_521630099_12236272447205265" target="_self">4.2 体系结构设计</a></li>
</ol></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_06133262252268856_14436166173_6351142753341671" target="_self">结论</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_08763730267221181_61051997246_24555782346959898" target="_self">致谢</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_5477265844133755_569682300497_2104099456909394" target="_self">参考文献</a></li>
<li><a href="http://www.blogger.com/post-edit.g?blogID=3975962728033178069&amp;postID=110363233203892653#_6802148896332174_481782926157" target="_self">附录</a></li>
</ol></li>
</ol></div>
<h2><a id="_8003452663834293_446333391194_2229142286479019" name="_8003452663834293_446333391194_2229142286479019"></a>摘要 </h2>
<p>
在软件的生存周期中，软件过程是整个软件开发实施的核心。成功实施的软件项目必须基于一个良好的软件过程元模型与相应的软件过程支撑环境。本论文为提出了
一个基于 XML Schema 定义的以活动为中心的软件过程定义语言 SPDL，设计并初步实现了其基于 Petri
网理论进行软件过程执行控制的支撑环境。</p>
<br /><strong>关键词：</strong>Petri 网，软件过程，过程模型，SPDL<br /><br />
<h2>Abstract </h2>
Software
process is the core of development in software life cycle. Successful
software project must base on a good software process meta model and a
corresponding support environment. The thesis presents a XML
Schema-based and activity-centric software process definition language
SPDL, then designs and implements a execution controlling support
environment based on the Petri net theory.<br /><br /><strong>Keywords: </strong>Petri net, software process, process model, SPDL<br /><br />
<h2><a id="_1_1388352720116368_2716843567" name="_1_1388352720116368_2716843567"></a>第 1 章 绪论 </h2>
<h3><a id="1_1_5159390391271211_275953689" name="1_1_5159390391271211_275953689"></a>1.1 软件过程与过程建模<br /></h3>
软件过程是软件生存周期中所涉及的一系列相关过程。过程是活动的集合，活动是任务的集合，任务是把输入转换为输出的操作[3]。软件过程模型是软件过程的静态描述，是软件过程执行的依据。软件过程是软件过程模型的执行实例，它是软件过程模型的动态表现。<br />在进行具体软模块时，都需要对其进行建模，根据 L. Osterweil 提出的&ldquo;软件过程也是软件&rdquo;[3]的观点出发，软件过程需要建模是自然的。目前，对软件模块进行建模时最为常用的建模工具是 UML[1]，它提供了对面向对象软件模块进行建模的统一标准。<br />
<h3><a id="1_3__780068034589648" name="1_3__780068034589648"></a>1.3 软件过程支撑环境现状<br /></h3>
对于软件过程建模来说，目前尚未形成类似 UML 影响力的建模工具。OMG 提出了 SPEM（Software Process<br />Engineering Meta-Model ）[16] 用于描述软件过程模型，文献[17]提出了基于 SPEM 的 CMM<br />软件过程元模型，但都却缺乏一个软件过程执行、过程演化的执行支撑环境。<br />在文献[3]中提出了一个的软件并行开发模型及其控制模型，并基于 Petri 网理论对这些模型进行了精确定义，表明了 Petri 网理论是解决软件过程建模与执行控制的有效途径。<br /><br /><a id="1_2_9936811177077666_457187516_28972784249254624" name="1_2_9936811177077666_457187516_28972784249254624"></a>
<h3><a id="1_3_00018081280370307873_94404" name="1_3_00018081280370307873_94404"></a>1.3 本课题的研究内容及意义 </h3>
<h4><a id="1_3_1_028681047868219456_00648" name="1_3_1_028681047868219456_00648"></a>1.3.1 研究内容<br /></h4>
<ol>
<li> 软件过程与软件过程模型<br />软件过程是指软件生存周期中所涉及的一系列相关过程，软件过程模型是软件过程的静态描述。如何准确地描述软件过程模型是重中之重。</li>
<li> 软件过程控制<br />为了精确地进行软件过程执行控制，基于 Petri 网的软件过程模型描述与软件过程控制是解决这一问题的有效途径之一。<br /></li>
<li>软件过程支撑环境<br />软件过程建模、软件过程模型修改（模型演化）、软件过程执行管理最终的目的是为了提高软件生产率，所以提供一个高质量的支撑环境是必然的。</li>
</ol>
<h4><a id="1_3_2_11199214029270765_852720" name="1_3_2_11199214029270765_852720"></a>1.3.2 意义<br /></h4>
近年来，随着社会对软件需求的与日俱增，如何控制软件生产过程以及如何持续地改进、演化软件过程就成为了软件工程研究的核心问题之一。我认为提出一个精确
的软件过程定义语言，并实现针对此语言可用的软件过程支撑环境是非常有必要的。在该支撑环境下，软件开发者：<br /><ol>
<li> 能够准确地定义软件生存周期涉及的各类软件过程模型 </li>
<li> 能够根据定义的软件过程模型精确地完成相应的软件过程 </li>
<li> 在发现已定义的软件过程模型有缺陷时能够将其及时修正</li>
</ol>      综上，通过软件过程的精确控制及其模型的不断演化，达到软件开发者认为最优的软件过程，从而提高其软件生产率。<br /><br />
<h3><a id="1_4_Petri_Nets_925016248581512" name="1_4_Petri_Nets_925016248581512"></a>1.4 Petri 网简介 </h3>
Petri 网是一种用于描述离散的、分布式系统的数学建模工具。1962 年，Carl Adam Petri 以其著名的论文&ldquo;<em>Kommunikation mit Automaten</em>&rdquo;获得博士学位。在该论文中，他正式提出了 Petri 网论，这一年被视作 Petri 网的诞生之年。1970 年以后，Petri 又将他的网论发展为通用网论。现在，世界各地有许多科研人员专注于 Petri 网的研究，每年都举行 Petri 网国际会议。<br /><br />Petri 网含有五个基本元素：<br />
<ul>
<li>place（库所）<br />一般用圆圈表示，可以形容为容纳标码的场所。它可以有容量限制也可以假设为容量无穷大。 </li>
<li>transition（变迁）<br />一般用矩形或者一条短线表示，描述了从一个状态到另一状态的变化。变迁的发生是发生一般是原子性的，即不可中断。</li>
<li>arc（有向弧）<br />一般用一段有向弧表示，从库所指向变迁或者由变迁指向库所，表征了两者之前一种偏序关系。弧上可以设定权值大小，即一次性消耗的资源数目。</li>
<li>token（标码）<br />即网系统中的资源，标码的数目即资源数。在活的网系统中，资源可以在库所变迁中不断流动。</li>
<li>marking（标记）<br />记录了 Petri 网中 token 的分布情况，描述了 Petri 网的状态。</li>
</ul>
</div>
<div><br /><br /></div>
</div>
<p><a id="Variations_on_the_definition" name="Variations_on_the_definition"></a></p>
<br />
<h2><a id="_2_8308693370062991_3526675778" name="_2_8308693370062991_3526675778"></a>第 2 章 软件过程定义语言<br /></h2>
<a id="2_1_SPDL_03411545267983507_643_5415882479713331" name="2_1_SPDL_03411545267983507_643_5415882479713331"></a>
<h3><a id="2_1_SPDL_040858003565423906_09_4259748263509201" name="2_1_SPDL_040858003565423906_09_4259748263509201"></a>2.1 SPDL 概述 </h3>
软件过程定义语言 &mdash;&mdash; SPDL 是一种面向软件过程建模者、以活动为中心的模型定义语言。它具有如下特征：<br />
<ul>
<li>涵盖了软件过程所涉及的基本元素，对这些元素的关联、功能、信息进行了描述</li>
<li>能够对软件过程中的活动进行并行描述</li>
<li>能够对软件过程中涉及的角色进行统一的职责描述，定义各角色的权限</li>
<li>使用 XML 作为过程模型描述载体，具有良好的可读性与互操作性</li>
</ul>
<h3><a id="2_2_SPDL_025611659795485298_34_004932047498921066" name="2_2_SPDL_025611659795485298_34_004932047498921066"></a>2.2 SPDL 元模型<br /></h3>
元模型（meta-model）是用来定义语义模型的构造（construct）和规则（rule）的，通常称为定义表达模型的语言的模型[1]。软件过
程定义语言 &mdash;&mdash; SPDL 的元模型是用于描述软件过程模型中的各个元素、元素之间的关系以及元素属性的。<br />对象管理组织（OMG）使用元对象设施（Meta-Object Facility, MOF）对 UML 进行元模型建模[4]。MOF 是一个 4 层体系结构的模型驱动工程[5]， <span><span>如下图：</span></span><br />
<div id="wzlt" style="text-align: center;">
<div id="g7ot" style="text-align: center;"><img style="width: 620px; height: 320px;" src="http://docs.google.com/File?id=ddrm6c35_506d7qqpthg_b" alt="" /><br />图 2.1 MOF 模型<br /></div>
<br />
<div style="text-align: left;">
在 M3 层中，MOF 定义了最基本的元元模型；在 M2 层中，使用了 MOF 定义的元元模型定义了 UML 元模型；在 M1 层中，使用了
UML 元模型进行软件模型建模；在 M0 层中，将建模好的软件模型进行实例化，该实例描述了真实世界中的对象。<br /></div>
</div>
<br />效仿 UML 的元模型建模方法，得出 SPDL 元模型建模体系结构<span><span>如下图：</span></span><br />
<div id="ppct" style="text-align: center;"><img style="width: 613px; height: 322px;" src="http://docs.google.com/File?id=ddrm6c35_507hjv9wkz6_b" alt="" /><br />图 2.2 SPDL 模型<br /><br /></div>
在 M3 层中，XML Schema[15] 定义了最基本的元元模型；在 M2 层中，使用了 XML Schema 定义的元元模型定义了 SPDL 元模型；在 M1 层中，使用了 SPDL 元模型进行软件过程<span><span>模型建模；在 M0 层中，将建模好的软件过程模型进行实例化，该实例描述了真实世界中的软件过程实例。<br />下图是 SPDL 的类设计（为简洁起见，所有类图都隐去了属性以及操作）</span></span>
<div id="y11n" style="text-align: center;"><br />
<div id="i8e7" style="text-align: center;"><img style="width: 633px; height: 382px;" src="http://docs.google.com/File?id=ddrm6c35_500frtgwhfq_b" alt="" /><br />图 2.3 SPDL 类图<br /></div>
</div>
<h4><a id="2_2_2_XML_Schema_5824128249899" name="2_2_2_XML_Schema_5824128249899"></a>2.2.1 XML Schema </h4>
附录1<br />
<h3><a id="2_2_37726097486484167_37019983_6280798376486112" name="2_2_37726097486484167_37019983_6280798376486112"></a>2.3 模型变换<br /></h3>
2001 年，对象管理组织（OMG）提出了 MDA[2] 开发的概念，其中提到下面两种类型的模型：<br />
<ul>
<li>PIM（平台独立的模型，Platform Independent Model）<br />此类模型不与任何具体特定的平台技术相关。例如，当我们在讨论 SPDL 概念时，我们只关心什么是过程定义、什么是活动定义、什么是任务定义，而不会去关心 SPDL 的支撑环境是如何实现这些概念。</li>
</ul>
<ul>
<li>PSM（平台特定的模型，Platform Specific Model）<br />此类模型非常重视给定平台的特殊性与平台的能力，让模型变换以及代码生成成为可能。例如，一个银行应用的 PIM 可以使用 UML 来建模，然后变换这个 PIM UML 模型到 PSM Java EJB 模型以及生成绝大部分的 Java 代码。</li>
</ul>
</div>
<div>
<div>      下图给出了从一种模型变换成另一种模型的原理概要：<br /><br />
<div id="vw8j" style="text-align: center;"><img style="width: 350px; height: 296px;" src="http://docs.google.com/File?id=ddrm6c35_191czwk66cd_b" alt="" /><br />图 2.4 模型变换原理概要<br />
<div style="text-align: left;">
<h4><a id="2_2_1_SPDL_Java_10170411018148_8048523622885639" name="2_2_1_SPDL_Java_10170411018148_8048523622885639"></a>2.3.1 SPDL 域到 Java 域的变换 </h4>
一个 SPDL 的实例是一个 XML 文档，它描述了一个软件过程模型。当 SPDL 实例部署到支撑环境中时，必须解析并生成相应的一些 Java 对象，以方便操作，例如进行 Petri 网图的生成，过程模型与过程的关联等。<br />在实现从 XML 领域到 Java 领域的模型变换时，JAXB 2.0（JSR 222）[7] 提供了规范的方法，下图给出这个变换处理的原理概要：
<div id="atpg" style="text-align: center;">
<div id="aocq" style="text-align: center;"><img style="width: 366px; height: 204px;" src="http://docs.google.com/File?id=ddrm6c35_492hdnx6qch_b" alt="" /></div>
图 2.5 JAXB 2.0 原理概要<br /></div>
</div>
</div>
<h4><a id="2_1_06316301911600453_93956129_7826743534428375" name="2_1_06316301911600453_93956129_7826743534428375"></a>2.3.2 SPDL 实例的 Petri 网图生成<br /></h4>
Petri 网可以从两个层次去描述，一是静态层次，即 Petri 网图；二是动态层次，即标记网。本节主要阐述 Petri 网图及其生成。<br />下面给出 Petri 网图的形式定义及其基本术语。<br /><strong>      定义 1.1</strong>[3] 如果三元组  (S, T, W) 称为一个 Petri 网图，那么<br />
<ul>
<li><span class="texhtml">S 是库所的有限集合</span></li>
<li><span class="texhtml">T 是变迁的有限集合<br /></span></li>
<li><span class="texhtml">S</span> &cup; T &ne; &Phi;，且 S &cap; T = &Phi;</li>
<li>W: (S &times; T) &cup; (T &times; S) &rarr; N 为弧的多重集</li>
</ul>
<p>      流关系是弧的集合：F = {(x, y) | W(x, y) &amp;gt; 0}。在一些介绍 Petri 网相关文献中，弧的重度只定义为 1，并在定义 Petri 网图时使用 F 代替了 W。</p>
<p><strong>      定义 1.2</strong>[3] 设 N = (S, T, F) 为一个 Petri 网图，x &isin; S &cup; T，则</p>
<ul>
<li><sup><strong><span style="font-size: small;">.</span></strong></sup>x = {y &isin; S &cup; T | (y, x) &isin; F}</li>
<li>x<sup><strong><span style="font-size: small;">.</span></strong></sup> = {y &isin; S &cup; T | (x, y) &isin; F}</li>
<li><strong><sup><span style="font-size: small;">.</span></sup></strong>x<strong><sup><span style="font-size: small;">.</span></sup></strong><span style="font-size: large;"><strong><sup> </sup></strong></span>＝ <sup><span style="font-size: small;"><strong>.</strong></span></sup>x &cup; x<sup><span style="font-size: small;"><strong>.</strong></span></sup></li>
</ul>
其中，<sup><strong><span style="font-size: small;">.</span></strong></sup>x 称为 x 的前提，x<sup><span style="font-size: small;"><strong>. </strong></span></sup> 称为 x 的后提，<span style="font-size: medium;"><strong><sup>.</sup></strong></span>x<span style="font-size: medium;"><sup><strong>. </strong></sup></span>称为 x 的前后提。<br /><br />根据定义 1.1， Petri 网图的 UML 建模如下：<br /><br /><br /><br />
<div style="text-align: center;">
<div id="u96s" style="text-align: center;"><img style="width: 277px; height: 233px;" src="http://docs.google.com/File?id=ddrm6c35_5173qnpjv9d_b" alt="" /><br /><span><span>图 2.6 Petri 网</span></span>图类图<br /></div>
</div>
<br />根据 SPDL 的元素结构，可以将其定义的软件过程模型分为如下三种基本结构：<br /><ol>
<li>顺序结构</li>
<li>选择结构</li>
<li>并行结构</li>
</ol><br />在实际的软件过程建模中，一般需要组合这三种基本结构从而定义出实用的软件过程模型。<br />
<h5><a id="2_3_2_1_6909392616490296_65774_874312677230697" name="2_3_2_1_6909392616490296_65774_874312677230697"></a>2.3.2.1 基元块<br /></h5>
基元块使用 Petri 网刻画了 SPDL 过程模型中的基本结构。基元块有以下几类：<br /><ol>
<li>顺序块<br />刻画了活动 e<sub>i</sub> 与 e<sub>j</sub> 是依次串行进<span><span>行的，如图所示。</span></span>
<div id="dblt" style="text-align: center;"><img style="width: 283px; height: 136px;" src="http://docs.google.com/File?id=ddrm6c35_536tmnnjjdg_b" alt="" /><br />图 2.7 顺序块<br /><br /></div>
</li>
<li>选择块<br />刻画了活动 e<sub>i</sub> 与 e<sub>j</sub> 是有选择地进<span><span>行，如图所示。</span></span>
<div id="hi2r" style="text-align: center;"><img style="width: 233px; height: 184px;" src="http://docs.google.com/File?id=ddrm6c35_537ck2qp6cr_b" alt="" /><br />图 2.8 选择块<br /><br /></div>
</li>
<li>并行块<br />刻画了活动 e<sub>i</sub> 与 e<sub>j</sub> 是并行进<span><span>行的，如图所示。</span></span>
<div id="k6vg" style="text-align: center;"><img style="width: 207px; height: 243px;" src="http://docs.google.com/File?id=ddrm6c35_538gf8wzvr5_b" alt="" /><br />图 2.9 并行块<br /></div>
</li>
</ol><br />
<h5><a id="2_3_2_2_026949359406927442_152_03583747535352089" name="2_3_2_2_026949359406927442_152_03583747535352089"></a>2.3.2.2 Petri 网图生成 </h5>
</div>
<div><span><span><span><span><span><span><span><span><span><span><span><span>根据 SPDL 实例生成的 Petri 网图中，库所用于存放标码，一个标码描述了一个过程实例；变迁描述了 SPDL 活动，活动的完成将导致变迁的点火，从而引起标码的移动。</span></span></span></span></span></span></span></span></span></span></span></span><br />下面各图分别展示了顺序、选择与并行结构的 Petri 网图生成实例。<br />
<ul>
<li>顺序结构<br />
<div id="b6nk" style="text-align: center;">
<div id="crja" style="text-align: center;"><img style="width: 357px; height: 376px;" src="http://docs.google.com/File?id=ddrm6c35_502dj6b3ghq_b" alt="" /></div>
</div>
<div style="text-align: center;"><span><span>图 2.10 顺</span></span>序结构的 Petri 网图生成<br /><br /></div>
</li>
<li>选择结构<br />
<div style="text-align: center;">
<div id="urmz" style="text-align: center;">
<div id="mxzj" style="text-align: center;">
<div id="kq4l" style="text-align: center;"><img style="width: 441px; height: 371px;" src="http://docs.google.com/File?id=ddrm6c35_2f4wrbvhp_b" alt="" /></div>
</div>
</div>
</div>
<div style="text-align: center;"><span><span>图 2.11 选择</span></span>结构的 Petri 网图生成<br /><br /></div>
</li>
<li>并行结构<br />在进行并行结构的 Petri 网图生成时，将生成 Join 库所队列结构。这个结构是一个顺序块，其中库所的个数与变迁的个数都等于并行活动个数 － 1。</li>
</ul>
<div id="p:bj" style="text-align: center;">
<div style="text-align: center;">
<div id="flnd" style="text-align: center;">
<div id="as9x" style="text-align: center;">
<div id="iwy4" style="text-align: center;"><img style="width: 579px; height: 456px;" src="http://docs.google.com/File?id=ddrm6c35_8gdbsb7ck_b" alt="" /></div>
</div>
</div>
</div>
<span><span>图 2.12 并</span></span>行结构的 Petri 网图生成<br /></div>
<br /><br /><a id="2_4_SPDL_9326087167019562_7883_4111730517573573" name="2_4_SPDL_9326087167019562_7883_4111730517573573"></a><br />
<h3><a id="2_4_SPDL_7633491211394602_2876_46701420512155445" name="2_4_SPDL_7633491211394602_2876_46701420512155445"></a>2.4 基于 SPDL 的软件过程建模方法<br /></h3>
基于 SPDL 进行软件过程建模时有两种基本策略：<br /><ol>
<li>自顶向下<br />从过程开始建模，发现过程模型中所需要的活动不存在时进行活动建模、任务建模等。</li>
<li>自底向上<br />从参与者、属性等开始建模，最后将这些实体组合成过程。</li>
</ol><br />这两种策略在建模时是交替使用的，自顶向下的策略可以看作是对过程建模的逐步精化；自底向上的策略可以看作是对过程元素的复用。<br />下面是基于 SPDL 的软件过程建模方法的 UML 用例图。<br />
<div id="w30_" style="text-align: center;"><img style="width: 528px; height: 286px;" src="http://docs.google.com/File?id=ddrm6c35_504xbzqfqc9_b" alt="" /><br /><span><span>图 2.13 建</span></span>模方法 UML 用例图<br /><br /></div>
下图是基于 SPDL 的软件过程建模方法的 UML 活动图。
<div id="pfvz" style="text-align: center;"><img style="width: 590px; height: 364px;" src="http://docs.google.com/File?id=ddrm6c35_5036b3khxc2_b" alt="" /><br /><span><span>图 2.14 建模方</span></span>法 UML 活动图<br /><br /></div>
<h2><a id="_3_18324534912390866_428228514" name="_3_18324534912390866_428228514"></a>第 3 章 软件过程执行控制<br /></h2>
<h3><a id="3_1_6162554744702771_786880372_6190911951750134" name="3_1_6162554744702771_786880372_6190911951750134"></a>3.1 过程生存周期<br /></h3>
过程是从无到有的，首先经过过程建模，得到一个原始的过程模型。该过程模型部署后执行时将得到过程实例，在过程实例的执行期对其进行监控，并针对过程执行中的数据、问题进行分析，可以得到一个改进的过程模型，最终将原始的过程模型进行重建模，并反复这个过程。<br />综上，软件过程是动态的，根据过程执行的反馈，按需修改过程模型，达到进一步提高软件生产率的目标。软件过程的生存<span><span>周期如下图所示。</span></span>
<div id="snng" style="text-align: center;">
<div id="arct" style="text-align: center;">
<div id="p:5." style="text-align: center;"><img style="width: 418px; height: 355px;" src="http://docs.google.com/File?id=ddrm6c35_511gv4p36c9_b" alt="" /><br /><span><span>图 3.1 软件过程生存周期</span></span><br /></div>
</div>
</div>
<div>
<h3><a id="3_3_2_6247080558796566_9465532_6578297759450403" name="3_3_2_6247080558796566_9465532_6578297759450403"></a>3.2 过程执行控制<br /></h3>
SPDL 为建模者提供了一种软件过程模型的定义语言。在软件过程模型实例化出一个软件过程后必须精确地控制其执行，而基于 Petri 网的过程控制正是解决这一问题的有效途径之一。<br />在执行的过程中，活动的完成将导致过程的完成或者导致下一<span><span>个活动的创建，该执行控制是基于 Petri 网进行控制的。在一次点火后，将改变过程状态，生成新的活动，如下图所示。</span></span><br />
<div id="iwlz" style="text-align: center;">
<div id="j0c7" style="text-align: center;">
<div id="ofz1" style="text-align: center;"><img style="width: 349px; height: 458px;" src="http://docs.google.com/File?id=ddrm6c35_5ppbvmwdw_b" alt="" /></div>
<span><span>图 3.2 过</span></span>程执行控制概览<br /></div>
</div>
<h4><a id="3_2_1_23129765298025928_670078_3917669516068203" name="3_2_1_23129765298025928_670078_3917669516068203"></a>3.2.1 标记网初始化<br /></h4>
标记网用于描述 Petri 网图的状态的，在软件过程支撑环境中用于描述过程的状态。<br />下面给出标记网的形式定义及其基本术语。<br />
<p><strong>      定义 1.3</strong>[3] 设 N = (S, T, F) 为一个 Petri 网图，&sum; ＝ (S, T, F, M) 称为一个标记网，其中</p>
<ul>
<li>M &sube; S，称为 N 的一个标记或一个瞬态</li>
<li>若 S &isin; T，且 <sup><strong><span style="font-size: small;">.</span></strong></sup>x &sube; M，x<sup><strong><span style="font-size: small;">.</span></strong></sup> &cap; M ＝ &Phi;，称事件 x 为可触发的</li>
<li>若事件 x 被触发（称为点火），则标记网 &sum; 转化为 &sum;' = (S, T, F, M')，其中 M' = (M - <sup><strong><span style="font-size: small;">.</span></strong></sup>x) &cup; x<sup><strong><span style="font-size: small;">.</span></strong></sup>，M' 也是 N 的一个标记，&sum;' 也是一个标记网</li>
</ul>
<br />使用一个给定的过程模型实例化一个过程时就是在与给定的过程模型对应的 Petri 网图中初始化一个标记网的过程。<br />过程实例化的 UML 时序图如下：
<div id="tups" style="text-align: center;">
<div id="v3m5" style="text-align: left;">
<div id="ti8x" style="text-align: left;">
<div id="rs9y" style="text-align: center;"><img style="width: 538px; height: 301px;" src="http://docs.google.com/File?id=ddrm6c35_516swdfc4fv_b" alt="" /><br /><span><span>图 3.3 过</span></span>程实例化 UML 时序图<br /></div>
</div>
</div>
</div>
<br />
<h4><a id="3_2_2_8100095147149176_5749420" name="3_2_2_8100095147149176_5749420"></a>3.2.2 点火控制 </h4>
当一个过程执行时，其中某一个活动满足了其完成条件时将触发一次对应此活动的变迁的点火。如果点火顺利完成，则相关标码也会被成功移动，并生成对应的活动或结束整个过程。<br />根据基元块类别，可以将点火控制分为如下三类：<br /><ol>
<li>顺序块点火</li>
<li>选择块点火</li>
<li>并行块点火</li>
</ol><br /><span style="background-color: #ffffff;">      </span><span><span>在控制这三种基本结构中的变迁点火时都基于如下步骤概要： </span></span></div>
<div><ol>
<li>检查变迁的点火条件是否满足，如果满足进行步骤 2；如果不满足则退出点火</li>
<li>在输入库所中根据需要完成活动所在的过程选出对应标码将标码</li>
<li>从输入库所移到输出库所，即进行点火</li>
</ol><a id="3_3_2_1_7037535011820709_52286" name="3_3_2_1_7037535011820709_52286"></a>      下面各图分别展示了顺序块、选择块与并行块的点火控制实例。
<ul>
<li>顺序块点火
<div id="w:ea" style="text-align: center;"><img style="width: 312px; height: 271px;" src="http://docs.google.com/File?id=ddrm6c35_518gkb64rgt_b" alt="" /><br />图 3.4 顺序块点火<br /><br /></div>
</li>
<li>选择块点火
<div id="hv39" style="text-align: center;">
<div id="xan7" style="text-align: center;">
<div id="r2we" style="text-align: center;"><img style="width: 560px; height: 400px;" src="http://docs.google.com/File?id=ddrm6c35_3s7ptw6dh_b" alt="" /></div>
</div>
图 3.5 选择块点火（1）<br />
<div style="text-align: left;">点火 Activity 1[Choice]，说明在过程执行时选择了 Activity 1。<br /></div>
<div id="omdb" style="text-align: center;">
<div id="kv1_" style="text-align: center;"><img style="width: 562px; height: 396px;" src="http://docs.google.com/File?id=ddrm6c35_4dtww9ncj_b" alt="" /></div>
图 3.6 选择块点火（2）<br />
<div style="text-align: left;"><br /></div>
</div>
</div>
</li>
<li>并行块点火<br />在完成 Start Activity 活动时将引起其相关联的 Petri 网的执行：与这个完成活动的过程相关联的标码将与 Start Activity[Start] 库所移动到 Fork 库所。<br /><br />
<div id="qj35" style="text-align: center;">
<div id="yb7i" style="text-align: center;"><img style="width: 495px; height: 366px;" src="http://docs.google.com/File?id=ddrm6c35_529fcmfmzgk_b" alt="" /></div>
图 3.7 并行块点火（1）<br /><br />
<div id="qj35" style="text-align: center;">
<div style="text-align: left;">当标码移动到 Fork 库所时，自动进行一次 Fork 变迁点火。<br /></div>
<div id="eojo" style="text-align: center;">
<div id="oa11" style="text-align: center;"><img style="width: 510px; height: 367px;" src="http://docs.google.com/File?id=ddrm6c35_530c63hvcfv_b" alt="" /></div>
</div>
图 3.8 并行块点火（2）<br /><br />
<div style="text-align: left;">当
各并行的活动之一完成时，其对应的变迁的输入库所中的标码将被移动到 Join 输出库所。此时，变迁 Activity 2
是不能被点火的，如果活动 Activity 2 在这个时刻完成，其对应的变迁 Activity 2 的点火将在变迁 Join 自动点火后进行。<br /></div>
<div id="z.:d" style="text-align: center;">
<div id="jw0e" style="text-align: center;">
<div id="g.dj" style="text-align: center;"><img style="width: 496px; height: 363px;" src="http://docs.google.com/File?id=ddrm6c35_532dz36zxdk_b" alt="" /></div>
</div>
图 3.9 并行块点火（3）<br /><br />
<div style="text-align: left;">当标码移动到 Join 库所时，自动进行一次 Join 变迁点火，使得这一标码进入 Join 库所队列中。如果并行活动个数为 n，则在这个库所队列中进行（n - 2）次点火，使得标码移动到队列的尾部库所（Join Queue n-1）。<br /></div>
<div id="i7-5" style="text-align: center;">
<div id="md9j" style="text-align: center;"><img style="width: 491px; height: 363px;" src="http://docs.google.com/File?id=ddrm6c35_533cj9gnqdc_b" alt="" /></div>
图 3.10 并行块点火（4）<br /><br />
<div style="text-align: left;">当各并行的活动之一完成时，其对应的变迁的输入库所中的标码将被移动到 Join 输出库所。此时，若不能进行变迁 Join 点火，说明所有的并行活动已经完成，因为 Join 库所队列已经放置满了标码。<br /></div>
<div style="text-align: left;">
<div id="i91z" style="text-align: center;"><img style="width: 491px; height: 365px;" src="http://docs.google.com/File?id=ddrm6c35_534g4zgv9gg_b" alt="" /><br />图 3.11 并行块点火（5）<br /><br />
<div style="text-align: left;">并行活动已完成后，点火 Join 库所队列队尾变迁，结束整个并行块。<br /></div>
<div id="a6t1" style="text-align: center;"><img style="width: 490px; height: 361px;" src="http://docs.google.com/File?id=ddrm6c35_535cf8pbwwx_b" alt="" /><br />图 3.12 并行块点火（6）<br /></div>
<br /></div>
</div>
</div>
</div>
</div>
</div>
</li>
</ul>
<h3><a id="3_3_42911771617760786_45381730_9634287789530159" name="3_3_42911771617760786_45381730_9634287789530159"></a>3.3 历史追踪<br /></h3>
</div>
<div>      过程是动态的，其状态随着过程执行而变化，所以必须记录每次过程状态的变化。通过对历史的追踪，可以得到很多重要的数据，对这些数据进行挖掘整理，有助于对过程模型的演化提供信息，并可以提供项目管理所需的必要数据。<br />根据软件过程的结构[6]，将历史记录分为如下三个部分：<br /><ol>
<li>过程历史<br />记录了过程在某一操作发生时的关键数据。例如过程创建 / 完成，过程的活动执行路径，优先级变更等。</li>
<li>活动历史<br />记录了过程中的活动在某一操作发生时的关键数据。例如活动创建 / 完成，活动所有者变更等。</li>
<li>任务历史<br />记录了活动中的任务在某一操作发生时的关键数据。例如任务创建 / 完成，参与者、优先级变更等。</li>
</ol><br />
<h2><a id="_4_3833686623076361_6622715409" name="_4_3833686623076361_6622715409"></a>第 4 章 软件过程支撑环境设计<br /></h2>
<h3><a id="4_1_BeyondTrack_29861802095786" name="4_1_BeyondTrack_29861802095786"></a>4.1 BeyondTrack 项目简介 </h3>
ByondTrack <span style="font-family: DejaVu Sans;">是一个基于<br /></span>JavaEE <span style="font-family: DejaVu Sans;">平台的 </span>B/S<br /><span style="font-family: DejaVu Sans;">结构的软件过程支撑环境。在该环境下，使用者可以进行：<br /></span><br />
<ul>
<li>可视化的软件过程建模</li>
<li>自定制过程变量</li>
<li>过程变量粒度的权限管理</li>
<li>过程任务、参与者管理</li>
<li>基于 Wiki 的文档管理</li>
<li>追踪过程事件历史</li>
</ul>
<h3><a id="4_2_5742416844827937_521630099_12236272447205265" name="4_2_5742416844827937_521630099_12236272447205265"></a>4.2 体系结构设计<br /></h3>
<a id="4_1_1_47797776373387213_349116_4349006680574222" name="4_1_1_47797776373387213_349116_4349006680574222"></a>BeyondTrack 项目涉及到的主要技术以及相应的使用情况如下：<br />
<ul>
<li>在 SPDL 处理上使用 JAXB 2.0（JSR 222）</li>
<li>在应用框架上使用 JBoss Seam 框架[8]（2.1.1.GA），该框架为 Java Context and Dependency Injection（JSR 299）[9]的超集实现</li>
<li>数据库持久化方面使用 JPA 1.0 （a part of JSR 220）[10]的 Hibernate[14] 实现，使用 Seam 托管的实体管理与事务管理</li>
<li>表现层选择了 JSF 1.2（JSR 252）[11]的 RichFaces[12] 实现，以 Facelets[13] 作为 JSF 视图定义框架</li>
</ul>
<br />这里简述一下选择 JBoss Seam 框架的原因：<br />
<ul>
<li>优秀的组件作用域与组件生存周期管理</li>
<li>Annotation-based 组件配置，框架配置非常简洁</li>
<li>整合了很多应用功能，例如规则引擎、工作流引擎、PDF 生成等</li>
<li>是一个 full-stack 的应用框架，提供了表现层、业务逻辑层与数据持久化层的整体解决方案</li>
<li>是 Java 企业级应用框架的"准规范"</li>
</ul>
<br />高层组件设计如下：
<div id="k1g5" style="text-align: left;">
<div id="z99x" style="text-align: center;"><img style="width: 458px; height: 440px;" src="http://docs.google.com/File?id=ddrm6c35_317ghcbz8c5_b" alt="" /><br />图 4.1 BeyondTrack 组件设计<br /><br />
<div style="text-align: left;">高层包设计如下：
<div id="h70q" style="text-align: center;">
<div id="c0ry" style="text-align: center;">
<div id="l-x3" style="text-align: left;">
<div style="text-align: center;"><img style="width: 470px; height: 478px;" src="http://docs.google.com/File?id=ddrm6c35_320c83qq8dx_b" alt="" /><br /></div>
<div style="text-align: center;">图 4.2 BeyondTrack 包设计<br /><br /></div>
</div>
<div style="text-align: left;"><a id="4_2_3_9631857090007863_2704264" name="4_2_3_9631857090007863_2704264"></a></div>
</div>
</div>
</div>
</div>
</div>
<a id="4_3_40073059625642193_92062475_333090995308295" name="4_3_40073059625642193_92062475_333090995308295"></a><a id="_6_6772560880962736_4984706167" name="_6_6772560880962736_4984706167"></a>
<h2><a id="_06133262252268856_14436166173_6351142753341671" name="_06133262252268856_14436166173_6351142753341671"></a>结论 </h2>
<span style="background-color: #ffffff;">      </span><span><span>软
件过程模型是软件项目进行可控实施的基本保证，一个优良的、项目规模适用的软件过程元模型是软件过程模型建模的必要条件。使用 SPDL
能够描述简单的（顺序 / 选择 / 并行）软件过程模型，并在 BeyondTrack
系统中得到过程建模、部署、执行、优化全生存周期的全支撑，在一定程度上提高了软件开发效率。 在进一步的工作中，将继续完善 SPDL
元模型，使之能够描述更复杂的软件过程（例如子过程），并加入对活动变迁条件的定义，使之在基于 Petri
网的过程执行控制时能够自动或半自动地进行。</span></span><br /><br />
<h2><a id="_08763730267221181_61051997246_24555782346959898" name="_08763730267221181_61051997246_24555782346959898"></a>致谢 </h2>
在此衷心感谢我的导师李彤博士，正是有了他辛勤的工作，细心的指导和严格的要求，才有了本篇论文的顺利完成。<br />感谢金峰软件公司，在那里我学习到了很多学校里学不到的软件工程实践与经验。<br />感谢 BeyondTrack 项目组的成员，大家一起齐心协力，成功地完成了这个项目。这里特别感谢赵禹同学，他给出了很多细心的建议，在项目实现上也尽心尽责。<br />最后感谢我的家人，是你们深情的教诲和无微不至的关怀，才有了我今天的成绩，对你们的感激之情无论用多少语言都无法表达！<br />
<h2><a id="_5477265844133755_569682300497_2104099456909394" name="_5477265844133755_569682300497_2104099456909394"></a>参考文献 </h2>
[1] Rumbaugh J, Jacobson I, Booch G. The Unified Modeling Language Reference Manual. Addison<br />Wesley Longman, Inc., 1999<br />[2] OMG. MDA Guide Version 1.0.1, document no: omg/2003-06-01, 2003<br />[3] 李彤, 孔兵, 王黎霞等. 软件并行开发过程. 北京:科学出版社, 2003<br />[4] http://en.wikipedia.org/wiki/Metamodeling<br />[5] http://en.wikipedia.org/wiki/Model-driven_engineering<br />[6] ISO/IEC 12207, SOFTWARE LIFE CYCLE PROCESSES<br />[7] JSR 222, Java<span style="vertical-align: super;"><span style="font-size: xx-small;">TM</span></span> Architecture for XML Binding (JAXB) 2.0<br />[8] http://www.seamframework.org<br />[9] JSR 299, Web Beans<br />[10] JSR 220, Enterprise JavaBeans<span style="vertical-align: super;"><span style="font-size: xx-small;">TM</span></span> 3.0<br />[11] JSR 252, JavaServer Faces 1.2<br />[12] http://www.jboss.org/jbossrichfaces<br />[13] http://facelets.dev.java.net<br />[14] http://www.hibernate.org<br />[15] http://www.w3.org/XML/Schema<br />[16] http://www.omg.org/technology/documents/formal/spem.htm<br />[17] 基于SPEM的CMM软件过程元模型, 2005 Journal of Software, Vol.16, No.8
<h2><a id="_6802148896332174_481782926157" name="_6802148896332174_481782926157"></a>附录<br /></h2>
1 SPDL XML Schema<br /><br />
<div id="google_footer" class="google_footer">
<p> 状态：<span>草稿</span>    日期：2009 年 4 月 22 日    作者：丁亮</p>
</div>
</div>
<br /></div>
<br /></div>