title: 把rpm包转成deb包的工具
date: '2007-05-08 05:11:00'
updated: '2007-05-08 05:11:00'
tags: [My Linux]
permalink: /articles/2007/05/07/1178543460000.html
---
<font face="腩戾,verdana," helvetica="">apt-get install alien</font><br /> <br /><font face="Verdana">alien -d 把rpm包转成deb包</font><br /> <br /><font face="Verdana">alien -i name-of-the-pakage.rpm直接就能装上rpm</font>