title: 奇葩 Java 代码片段
date: '2011-11-27 22:18:33'
updated: '2011-11-27 22:18:33'
tags: [Snippets, Weird, Fiddlededee, Java]
permalink: /weird-java-snippets
---
<p>整理了几个奇葩 Java 代码片段，休闲娱乐一下 ;-)</p>
<p><img src="https://sn2files.storage.live.com/y1pozxO1kBOGtfIm_9OrBigcFoMORM1lMrFIfrLIeDWPK1sJjsU8S4MsYI-Lr7IvDOJd8cgoYRIxkA/weird-java-snippets.png?psid=1" alt="Weird Java Snippets" width="612" height="741" /></p>