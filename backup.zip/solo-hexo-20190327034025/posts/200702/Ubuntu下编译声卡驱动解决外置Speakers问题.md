title: Ubuntu下编译声卡驱动，解决外置Speakers问题！
date: '2007-02-16 14:40:00'
updated: '2007-02-16 14:40:00'
tags: [My Linux]
permalink: /articles/2007/02/15/1171579200000.html
---
本来在2.6在内核是带alsa的声卡驱动的，装完系统的时候也是有声音的，驱动是1.0.11的。声音是有，不过是本本内置的speakers出来的，外置的一概不出声音，郁闷了。在网上看了看，据说是要更新驱动，今天弄了一晚，只为了升级驱动。。。。<br />到http://www.alsa-project.org上看了看，目前最新的稳定版本是1.0.13，有个在测试中的1.0.14rc2。那就先装1.0.13，正式版比较安全吧，呵呵。<br />下载了driver，lib，utils，解压后从driver开始进行编译<br /># ./configure<br /># make &amp;&amp; make install<br />前两个都正常，到utils的时候在./configure时候过不去了，提示说什么ncurses库缺失。。。。<br />又去更新ncurses：sudo apt-get install ncurses-base。。。。<br />再# make &amp;&amp; make install<br />好像一切正常，reboot！<br />重启后的确是安装成功了，不过外置的扬声器还是没有声音。。。。<br />难道是驱动不够新？？？？<br />再去下载了1.0.14rc2的！<br />安装。。。。<br />reboot。。。。<br />靠！还是不行，郁闷了，现在还在郁闷，到底要How To吖？？？？<br /><br /><br /><span style="color: rgb(0, 204, 255);">最终解决方法：<br />1. 把插头换个插孔，具体自己试试。<br />2. Channel Mode 一定要选6CH！！！！<br />。。。。。就这样可以用了，郁闷死。。。。<br />P.S. 随便说一下，可以用lspci | grep Audio命令看声卡，我的是：<br />00:1b.0 Audio device: Intel Corporation 82801FB/FBM/FR/FW/FRW (ICH6 Family) High Definition Audio Controller (rev 04)<br />不知道下次的驱动会不会解决这个Bug。。。。</span>