title: 我只是想安装一下显卡——Ubuntu6.10下装GeForce Go 6600
date: '2007-02-14 14:15:00'
updated: '2007-02-14 14:15:00'
tags: [My Linux]
permalink: /articles/2007/02/13/1171404900000.html
---
<span style="color: rgb(0, 0, 255);">今天刚装好了Ubantu&nbsp; Linux操作系统，准备正式投入Linux的怀抱。。。。</span><br style="color: rgb(0, 0, 255);" /><span style="color: rgb(0, 0, 255);">不过装显卡驱动从下午一直弄到现在。。。。</span><br style="color: rgb(0, 0, 255);" /><span style="color: rgb(0, 0, 255);">方法参考如下：</span><br />
<p class="line867"><strong><span style="color: rgb(255, 0, 0);">方法一</span>：从网络源安装驱动</strong> <span class="anchor" id="line-6"></span><span class="anchor" id="line-7"></span></p>
<p class="line867"><strong>从下面源里任选一种加入到 /etc/apt/sources.list里面</strong> * <span class="anchor" id="line-8"></span><span class="anchor" id="line-9"></span></p>
<p class="line867"><span class="anchor" id="line-10"></span></p>
<pre>deb http://amaranth.selfip.com edgy lrm</pre>
<span class="anchor" id="line-11"></span>
<ul>
    <li><span class="anchor" id="line-12"></span>
    <pre>deb http://dev.realistanew.com/beryl edgy beryl</pre>
    <span class="anchor" id="line-13"></span>
    <p class="line891"><strong>这个源在10月5日（2006年？）出现部份包丢失的情况，上面那个Amaranth源里已经解决了这个错误</strong> <span class="anchor" id="line-14"></span></p>
    </li>
    <li><span class="anchor" id="line-15"></span>
    <pre>deb http://beryl-mirror.lupine.me.uk/beryl edgy beryl</pre>
    <span class="anchor" id="line-16"></span>10月2日（2006年？），这个源出现找不到&quot;beryl/binary-i386/Packages/&quot;目录下的包的问题。 <span class="anchor" id="line-17"></span></li>
</ul>
<p class="line867"><strong>添加完网络源后，执行以下命令进行驱动程序安装：</strong> <span class="anchor" id="line-18"></span><span class="anchor" id="line-19"></span></p>
<p class="line867"><span class="anchor" id="line-20"></span></p>
<pre>sudo apt-get update<br /><span class="anchor" id="line-21"></span>sudo apt-get install <strong class="highlight">nvidia</strong>-glx<br /><span class="anchor" id="line-22"></span></pre>
<span class="anchor" id="line-23"></span>
<p class="line862">待所有软件包下载并完成安装之后，按Ctrl + Alt + <a class="nonexistent" href="http://wiki.ubuntu.org.cn/BackSpace">BackSpace</a>.重启X。</p>
<p style="color: rgb(0, 0, 255);" class="line862">本来是想用这种的，但是的下载安装包的时候说</p>
<p style="color: rgb(0, 0, 255);" class="line862">下列的软件包有不能满足的依赖关系：<br />&nbsp; nvidia-glx: 依赖: nvidia-kernel-1.0.9631</p>
<p class="line862"><span style="color: rgb(0, 0, 255);">郁闷了。。。。网上的资料没一份说的很清楚是怎么回事的，也所可能是我没找到吧。后来采取如下方法：</span> <span class="anchor" id="line-24"></span><span class="anchor" id="line-25"></span></p>
<p class="line874"><span style="color: rgb(255, 0, 0);">方法二</span>：<span style="font-weight: bold;">从</span><strong style="font-weight: bold;" class="highlight">nVIDIA</strong><span style="font-weight: bold;">官方网站下载驱动包，手动安装驱动程序。</span> <span class="anchor" id="line-26"></span><span class="anchor" id="line-27"></span></p>
<p class="line862">从官方网站上（<a class="http" href="http://www.nzone.com/object/nzone_downloads_rel70betadriver.html"><strong class="highlight">nVIDIA</strong> beta driver</a> ）下选择适合自己配置的驱动包，分为32位和64位的。 <span class="anchor" id="line-28"></span><span class="anchor" id="line-29"></span></p>
<p class="line874">解决安装驱动的包依赖问题 <span class="anchor" id="line-30"></span><span class="anchor" id="line-31"></span></p>
<p class="line867"><span class="anchor" id="line-32"></span></p>
<pre>sudo apt-get install linux-headers-$(uname -r) libc6-dev<br /><span class="anchor" id="line-33"></span></pre>
<span class="anchor" id="line-34"></span>
<ul>
    <li>安装驱动，必需在真正的命令终端操作（按Ctrl+Alt+F1切换），登录，输入以下命令： <span class="anchor" id="line-35"></span></li>
</ul>
<p class="line867"><span class="anchor" id="line-36"></span></p>
<pre>sudo /etc/init.d/gdm stop<br /><span class="anchor" id="line-37"></span>sudo sh <strong class="highlight">NVIDIA</strong>-Linux-x86-1.0-9625-pkg1.run<br /><span class="anchor" id="line-38"></span></pre>
<span class="anchor" id="line-39"></span>
<p class="line874">安装结束后，系统将提示是否启用新的配置文件，选择&ldquo;是yes&rdquo; <span class="anchor" id="line-40"></span><span class="anchor" id="line-41"></span></p>
<p class="line874">在终端里执行以下命令重启GDM。 <span class="anchor" id="line-42"></span><span class="anchor" id="line-43"></span></p>
<p class="line867"><span class="anchor" id="line-44"></span></p>
<pre>sudo /etc/init.d/gdm start<br /><span class="anchor" id="line-45"></span></pre>
<span class="anchor" id="line-46"></span>
<p class="line867"><strong><span class="u">注意：通过这种方法安装驱动，每一次系统内核升级后，都必须重新安装一次显卡驱动。</span></strong>下面这个命令可以查看你的显卡是否已经支持direct rendering <span class="anchor" id="line-47"></span><span class="anchor" id="line-48"></span></p>
<p class="line867"><span class="anchor" id="line-49"></span></p>
<pre>glxinfo | grep direct<br /><span class="anchor" id="line-50"></span></pre>
<span class="anchor" id="line-51"></span>
<p class="line874">如果你的驱动安装正确了，这个命令应该会出现下面这样的提示： <span class="anchor" id="line-52"></span><span class="anchor" id="line-53"></span></p>
<p class="line867"><span class="anchor" id="line-54"></span></p>
<pre>direct rendering: Yes<br /><span class="anchor" id="line-55"></span></pre>
<span class="anchor" id="line-56"></span>
<ul>
    <li style="list-style-type: none;">这个提示说明你的显卡驱动已经OK了。如果得到的是其他提示，试试用<strong class="highlight">nVIDIA</strong>的配置工作重新配置，再重启GDM； <span class="anchor" id="line-57"></span></li>
</ul>
<p class="line867"><span class="anchor" id="line-58"></span></p>
还是手动编译搞定了。。。。不过刚才我又上网看了下，也可以安装一个叫envy的CLI，安装貌似更简单的说，呵呵。。。。<br />
<p style="color: rgb(255, 0, 0);"><strong>方法三（引自下面的链接，感谢作者^_^）</strong></p>
<p style="color: rgb(255, 0, 0);"><span class="postbody"><a href="http://y-point.zhuzhulife.info/index.php?title=NVidia%E6%98%BE%E5%8D%A1%E9%A9%B1%E5%8A%A8%E7%9A%84%E5%AE%89%E8%A3%85%E7%AC%94%E8%AE%B0" target="_blank">http://y-point.zhuzhulife.info/index.php?title=NVidia%E6%98%BE%E5%8D%A1%E9%A9%B1%E5%8A%A8%E7%9A%84%E5%AE%89%E8%A3%85%E7%AC%94%E8%AE%B0</a> <br />  </span></p>
<ul>
    <li> 以下方法参考自 <a href="http://www.albertomilone.com/projects.html" class="external free" title="http://www.albertomilone.com/projects.html" rel="nofollow">http://www.albertomilone.com/projects.html</a> 的 Envy 项目。 <br /> </li>
    <li> 从 <a href="http://www.albertomilone.com/nvidia_scripts1.html" class="external free" title="http://www.albertomilone.com/nvidia_scripts1.html" rel="nofollow">http://www.albertomilone.com/nvidia_scripts1.html</a> 下载最新版 Envy 并安装 </li>
</ul>
<pre>wget -c <a href="http://albertomilone.com/ubuntu/nvidia/scripts/envy_0.8.1-0ubuntu6_all.deb" class="external free" title="http://albertomilone.com/ubuntu/nvidia/scripts/envy_0.8.1-0ubuntu6_all.deb" rel="nofollow">http://albertomilone.com/ubuntu/nvidia/scripts/envy_0.8.1-0ubuntu6_all.deb</a><br />sudo dpkg -i envy_0.8.1-0ubuntu6_all.deb<br /></pre>
<ul>
    <li> 用 CTRL+ALT+F1 进入控制台并登录。  </li>
    <li> 如果控制台没有中文系统的可以用下列命令设置英文提示 </li>
</ul>
<pre>export LANGUAGE=en_US<br /></pre>
<ul>
    <li> 运行Envy，它会提示输入密码 </li>
</ul>
<pre>envy<br /></pre>
<ul>
    <li> 后面的事情就不用说什么了，我是选择了 1 。安装完成起动X，运行 </li>
</ul>
<pre>glxinfo | grep direct<br /></pre>
<p>系统输出 </p>
<pre>direct rendering: Yes<br /></pre>
<ul>
    <li> [安装成功！] </li>
</ul>
<a name=".E5.88.A0.E9.99.A4_nVidia.E6.A0.87.E5.BF.97"></a>
<h2><strong>删除 nVidia标志</strong></h2>
<ul>
    <li> 如果您不想在启动界面之前显示 nVidia 标志,您需要手动编辑您的 Xorg 配置文件. </li>
    <li> 选择屏幕上方的 Applications 应用程序菜单,然后选择 Accessories 附件, Terminal 终端. </li>
</ul>
<p>输入如下命令: </p>
<pre>sudo gedit /etc/X11/xorg.conf<br /></pre>
<p>在Device一节中找到 &quot;nvidia&quot; 所在行，在该行后添加 </p>
<pre>Option          &quot;NoLogo&quot;<br /></pre>
<p>保存文件并退出，重启X </p>