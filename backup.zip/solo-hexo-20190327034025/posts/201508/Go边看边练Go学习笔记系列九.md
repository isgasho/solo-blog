title: Go 边看边练 -《Go 学习笔记》系列（九）
date: '2015-08-04 02:12:05'
updated: '2015-12-29 22:43:07'
tags: [Golang, Go学习笔记, 教程, 雨痕]
permalink: /articles/2015/08/03/1438596722873.html
---
上一篇： [1438311936449] 

----

### ToC

* [Go 边看边练 -《Go 学习笔记》系列（一）- 变量、常量](http://symphony.b3log.org/article/1437497122181)
* [Go 边看边练 -《Go 学习笔记》系列（二）- 类型、字符串](http://symphony.b3log.org/article/1437558810339)
* [Go 边看边练 -《Go 学习笔记》系列（三）- 指针](http://symphony.b3log.org/article/1437719712835)
* [Go 边看边练 -《Go 学习笔记》系列（四）- 控制流1](http://symphony.b3log.org/article/1437984612418)
* [Go 边看边练 -《Go 学习笔记》系列（五）- 控制流2](http://symphony.b3log.org/article/1438070631857)
* [Go 边看边练 -《Go 学习笔记》系列（六）- 函数](http://symphony.b3log.org/article/1438164538421)
* [Go 边看边练 -《Go 学习笔记》系列（七）- 错误处理](http://symphony.b3log.org/article/1438260619759)
* [Go 边看边练 -《Go 学习笔记》系列（八）- 数组、切片](http://symphony.b3log.org/article/1438311936449)
* [Go 边看边练 -《Go 学习笔记》系列（九）- Map、结构体](http://symphony.b3log.org/article/1438596722873)
* [Go 边看边练 -《Go 学习笔记》系列（十）- 方法](http://symphony.b3log.org/article/1438699210452)
* [Go 边看边练 -《Go 学习笔记》系列（十一）- 表达式](http://symphony.b3log.org/article/1438763483577)
* [Go 边看边练 -《Go 学习笔记》系列（十二）- 接口](http://symphony.b3log.org/article/1438845728987)
* [Go 边看边练 -《Go 学习笔记》系列（十三）- Goroutine](http://symphony.b3log.org/article/1438938175118)
* [Go 边看边练 -《Go 学习笔记》系列（十四）- Channel](http://symphony.b3log.org/article/1439194647152)

----

### 4.3 Map

引用类型，哈希表。键必须是支持相等运算符 (==、!=) 类型，比如 `number`、`string`、`pointer`、`array`、`struct`，以及对应的 `interface`。值可以是任意类型，没有限制。

    m := map[int]struct {
    	name string
    	age int
    }{
    	1: {"user1", 10}, // 可省略元素类型。
    	2: {"user2", 20},
    }
    
    println(m[1].name)

预先给 `make` 函数一个合理元素数量参数，有助于提升性能。因为事先申请一大块内存，可避免后续操作时频繁扩张。

	m := make(map[string]int, 1000)

常见操作：

    m := map[string]int{
    	"a": 1,
    }
    
    if v, ok := m["a"]; ok { // 判断 key 是否存在。
    	println(v)
    }
    
    println(m["c"]) // 对于不存在的 key，直接返回 \0，不会出错。
    
    m["b"] = 2 // 新增或修改。
    
    delete(m, "c") // 删除。如果 key 不存在，不会出错。
    
    println(len(m)) // 获取键值对数量。cap 无效。
    
    for k, v := range m { // 迭代，可仅返回 key。随机顺序返回，每次都不相同。
    	println(k, v)
    }

不能保证迭代返回次序，通常是随机结果，具体和版本实现有关。

从 `map` 中取回的是一个 `value` 临时复制品，对其成员的修改是没有任何意义的。

    type user struct{ name string }
    
    m := map[int]user{ // 当 map 因扩张而重新哈希时，各键值项存储位置都会发生改变。 因此，map
    	1: {"user1"}, // 被设计成 not addressable。 类似 m[1].name 这种期望透过原 value
    } // 指针修改成员的行为自然会被禁止。
    
    m[1].name = "Tom" // Error: cannot assign to m[1].name

正确做法是完整替换 `value` 或使用指针。

    u := m[1]
    u.name = "Tom"
    m[1] = u // 替换 value。

    m2 := map[int]*user{
    	1: &user{"user1"},
    }
    
    m2[1].name = "Jack" // 返回的是指针复制品。透过指针修改原对象是允许的。

可以在迭代时安全删除键值。但如果期间有新增操作，那么就不知道会有什么意外了。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/953c1eef3162b8a3aec5b78d0405e667.go?embed=true" width="99%" height="600"></iframe>

### 4.4 Struct

值类型，赋值和传参会复制全部内容。可用 "\_" 定义补位字段，支持指向自身类型的指针成员。

    type Node struct {
    	_ int
    	id int
    	data *byte
    	next *Node
    }
    
    func main() {
    	n1 := Node{
    		id: 1,
    		data: nil,
    	}
        
    	n2 := Node{
    		id: 2,
    		data: nil,
    		next: &n1,
    	}
    }

顺序初始化必须包含全部字段，否则会出错。

    type User struct {
    	name string
    	age int
    }
    
    u1 := User{"Tom", 20}
    u2 := User{"Tom"} // Error: too few values in struct initializer

支持匿名结构，可用作结构成员或定义变量。

    type File struct {
    	name string
    	size int
    	attr struct {
    		perm int
    		owner int
    	}
    }
    
    f := File{
    	name: "test.txt",
    	size: 1025,
    	// attr: {0755, 1}, // Error: missing type in composite literal
    }
    
    f.attr.owner = 1
    f.attr.perm = 0755
    
    var attr = struct {
    	perm int
    	owner int
    }{2, 0755}
    
    f.attr = attr

支持 "=="、"!=" 相等操作符，可用作 `map` 键类型。

    type User struct {
    	id int
    	name string
    }
    
    m := map[User]int{
    	User{1, "Tom"}: 100,
    }

可定义字段标签，用反射读取。标签是类型的组成部分。

    var u1 struct { name string "username" }
    var u2 struct { name string }
    
    u2 = u1 // Error: cannot use u1 (type struct { name string "username" }) as
    			 // type struct { name string } in assignment

空结构 "节省" 内存，比如用来实现 `set` 数据结构，或者实现没有 "状态" 只有方法的 "静态类"。

    var null struct{}
    
    set := make(map[string]struct{})
    set["a"] = null

#### 4.4.1 匿名字段

匿名字段不过是一种语法糖，从根本上说，就是一个与成员类型同名 (不含包名) 的字段。被匿名嵌入的可以是任何类型，当然也包括指针。

    type User struct {
    	name string
    }
    
    type Manager struct {
    	User
    	title string
    }

	m := Manager{
		User: User{"Tom"}, // 匿名字段的显式字段名，和类型名相同。
		title: "Administrator",
	}

可以像普通字段那样访问匿名字段成员，编译器从外向内逐级查找所有层次的匿名字段，直到发现目标或出错。

    type Resource struct {
    	id int
    }
    
    type User struct {
    	Resource
    	name string
    }
    
    type Manager struct {
    	User
    	title string
    }
    
    var m Manager
    m.id = 1
    m.name = "Jack"
    m.title = "Administrator"


外层同名字段会遮蔽嵌入字段成员，相同层次的同名字段也会让编译器无所适从。解决方法是使用显式字段名。

    type Resource struct {
    	id int
    	name string
    }
    
    type Classify struct {
    	id int
    }
    
    type User struct {
    	Resource // Resource.id 与 Classify.id 处于同一层次。
    	Classify
    	name string // 遮蔽 Resource.name。
    }
    
    u := User{
		Resource{1, "people"},
		Classify{100},
		"Jack",
	}
    
    println(u.name) // User.name: Jack
    println(u.Resource.name) // people

	// println(u.id) // Error: ambiguous selector u.id
    println(u.Classify.id) // 100

不能同时嵌入某一类型和其指针类型，因为它们名字相同。

    type Resource struct {
    	id int
    }
    
    type User struct {
    	*Resource
    	// Resource // Error: duplicate field Resource
    	name string
    }
    
    u := User{
    	&Resource{1},
    	"Administrator",
    }
    
    println(u.id)
    println(u.Resource.id)

#### 4.4.2 面向对象

面向对象三大特征里，Go 仅支持封装，尽管匿名字段的内存布局和行为类似继承。没有 `class` 关键字，没有继承、多态等等。

    type User struct {
    	id int
    	name string
    }
    
    type Manager struct {
    	User
    	title string
    }
    
    m := Manager{User{1, "Tom"}, "Administrator"}
    
    // var u User = m // Error: cannot use m (type Manager) as type User in assignment
    							 // 没有继承，自然也不会有多态。
    
    var u User = m.User // 同类型拷⻉贝。

内存布局和 C struct 相同，没有任何附加的 object 信息。

![ ](http://7xjwh5.com1.z0.glb.clouddn.com/FvhXPGczq22tZbJ6E2ogSx7vXD2s) 

可用 `unsafe` 包相关函数输出内存地址信息。

    m : 0x2102271b0, size: 40, align: 8
    m.id : 0x2102271b0, offset: 0
    m.name : 0x2102271b8, offset: 8
    m.title: 0x2102271c8, offset: 24


下一篇： [1438699210452] 

----

* ***本系列是基于***[雨痕](https://github.com/qyuhen)***的***[《Go 学习笔记》（第四版）](https://github.com/qyuhen/book/blob/master/Go%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%20%E7%AC%AC%E5%9B%9B%E7%89%88.pdf)***整理汇编而成，非常感谢雨痕的辛勤付出与分享！***
* 转载请注明：文章转载自：**黑客与画家的社区** [[http://symphony.b3log.org](http://symphony.b3log.org)]
* 如果你觉得本章节做得不错，请在下面打赏一下吧~

----

> 社区小贴士
>
> * 关注标签 [golang] 可以方便查看 Go 相关帖子
> * 关注标签 [Go学习笔记] 可以方便查看本系列
> * 关注作者后如有新帖将会收到通知

<p style='font-size: 12px;'><i>该文章同步自 <a href='http://hacpai.com/article/1438596722873' target='_blank'>黑客派</a></i></p>