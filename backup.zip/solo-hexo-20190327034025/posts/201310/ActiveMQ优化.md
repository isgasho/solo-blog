title: ActiveMQ 优化
date: '2013-10-12 11:13:58'
updated: '2013-10-12 11:14:23'
tags: [Optimization, ActiveMQ]
permalink: /activemq-optmization
---
<div><strong>1. 启用 NIO Transport Connector</strong></div>
<div>
<pre class="brush: xml">&lt;transportConnectors&gt;
   &lt;transportConnector name="nio" uri="nio://localhost:62828"/&gt;
&lt;/transportConnectors&gt;</pre>
</div>
<div>客户端也需要改为 nio。</div>
<div>&nbsp;</div>
<div><strong>2. 目标策略</strong></div>
<div>
<pre class="brush: xml">   &lt;destinationPolicy&gt;
   &lt;policyMap&gt;
    &lt;policyEntries&gt;
     &lt;policyEntry queue="&gt;"
             optimizedDispatch="true"
             producerFlowControl="false"
             memoryLimit="128 mb"&gt;
          &lt;pendingSubscriberPolicy&gt;
            &lt;vmCursor /&gt;
          &lt;/pendingSubscriberPolicy&gt;
     &lt;/policyEntry&gt;
    &lt;/policyEntries&gt;
   &lt;/policyMap&gt;
  &lt;/destinationPolicy&gt;</pre>
</div>