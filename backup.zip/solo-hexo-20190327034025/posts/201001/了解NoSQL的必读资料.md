title: 了解 NoSQL 的必读资料
date: '2010-01-15 11:59:00'
updated: '2010-01-15 11:59:00'
tags: [Architecture Design, Open Source, Database, Data-Structrue/Algorithms]
permalink: /articles/2010/01/14/1263499140000.html
---
<p>&nbsp;</p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img style="width: 78px; height: 78px; float: left; margin-left: 0pt; margin-right: 1em;" src="http://docs.google.com/File?id=ddrm6c35_1202g7f52zgj_b" alt="" />
NoSQL</strong>
 是非关系型数据存储的广义定义。它打破了长久以来关系型数据库与 <a title="ACID" href="http://en.wikipedia.org/wiki/ACID" title="ACID">ACID</a>
 理论大一统的局面。NoSQL 数据存储不需要固定的表结构，通常也不存在<a title="Join (SQL)" href="http://en.wikipedia.org/wiki/Join_%28SQL%29" title="Join (SQL)">连接</a>
操作。在大数据存取上具备关系型数据库无法比拟的性能优势。该术语在 2009 年初得到了广泛认同。<br />
&nbsp;&nbsp;&nbsp;&nbsp; 当今的应用体系结构需要数据存储在<a title="Scalability" href="http://en.wikipedia.org/wiki/Scalability" title="Scalability">横向伸缩性</a>
上能够满足需求。而 NoSQL 存储就是为了实现这个需求。Google 的 <a title="BigTable" href="http://en.wikipedia.org/wiki/BigTable" title="BigTable">BigTable</a>
 与 <a title="Amazon" href="http://en.wikipedia.org/wiki/Amazon" title="Amazon">Amazon</a>
 的 <a title="Dynamo (storage system)" href="http://en.wikipedia.org/wiki/Dynamo_%28storage_system%29" title="Dynamo (storage system)">Dynamo</a>
 是非常成功的商业 NoSQL 实现。一些开源的 NoSQL 体系，如Facebook 的 <a title="Cassandra (database)" href="http://en.wikipedia.org/wiki/Cassandra_%28database%29" title="Cassandra (database)">Cassandra</a>
， Apache 的 <a title="HBase" href="http://en.wikipedia.org/wiki/HBase" title="HBase">HBase</a>
，也得到了广泛认同。<br />
&nbsp;&nbsp;&nbsp;&nbsp; 如果您刚接触 NoSQL，那有必要学习一些背景知识。下列资料是国外一<a id="ah7u" title="前沿技术分析师" href="http://asserttrue.blogspot.com/" title="前沿技术分析师">前沿技术分析师</a>
认为非常有价值的 NoSQL 相关必读资料：<br /></p>
<ol>
<li><a title="Amazon Dynamo 论文" href="http://s3.amazonaws.com/AllThingsDistributed/sosp/amazon-dynamo-sosp2007.pdf" title="Amazon Dynamo 论文">Amazon Dynamo 论文</a>
。几乎所有懂 NoSQL 的人都阅读过它。</li>
<li>Google 的 <a title="Bigtable 论文" href="http://labs.google.com/papers/bigtable.html" title="Bigtable 论文">Bigtable 论文</a>
。 也许您已经耳熟能详。</li>
<li>Werner Vogels 的 <a title="&ldquo;Eventually Consistent&rdquo;" href="http://www.allthingsdistributed.com/2008/12/eventually_consistent.html" title="&ldquo;Eventually Consistent&rdquo;">&ldquo;Eventually Consistent&rdquo;</a>
 （发布于 <a title="ACM Queue" href="http://delivery.acm.org/10.1145/1470000/1466448/p14-vogels.pdf?key1=1466448&amp;key2=8241830621&amp;coll=GUIDE&amp;dl=GUIDE&amp;CFID=65986758&amp;CFTOKEN=76261788" title="ACM Queue"><em>ACM Queue</em>
</a>
）。如果您对&ldquo;<strong>最终一致性</strong>
&rdquo;不是非常清晰，请阅读这篇文章。</li>
<li>Brewer 的 <strong>CAP 理论</strong>
（可伸缩性的基础）在<a title="这里" href="http://www.julianbrowne.com/article/viewer/brewers-cap-theorem" title="这里">这里</a>
可以找到非常好的诠释。也可以看看 2000 7 月 PODC 上 <a title="Brewer的原始幻灯片" href="http://www.cs.berkeley.edu/%7Ebrewer/cs262b-2004/PODC-keynote.pdf" title="Brewer的原始幻灯片">Brewer的原始幻灯片</a>
。</li>
<li><a title="在 2009 年 6 月在 SFO 的 NoSQL 见面会的幻灯片" href="http://blog.oskarsson.nu/2009/06/nosql-debrief.html" title="在 2009 年 6 月在 SFO 的 NoSQL 见面会的幻灯片">在 2009 年 6 月在 SFO 的 NoSQL 见面会的幻灯片</a>
。这些资料可以用经典的、关键的、将影响巨大的、值得纪念的来形容。</li>
<li><a title="SQL Databases Don't Scale" href="http://adam.blog.heroku.com/past/2009/7/6/sql_databases_dont_scale/" title="SQL Databases Don't Scale">SQL Databases Don't Scale</a>
 是一篇简短、基础、直切问题的文章。除非您是一位在<strong>伸缩性问题</strong>
上身经百战的数据库管理员，否则，这篇文章讲述的内容对于您可能是非常关键的。</li>
<li><a title="Jonathan Ellis" href="http://twitter.com/spyced" target="_blank" title="Jonathan Ellis">Jonathan Ellis</a>
 的文章 <a title="NoSQL Ecosystem" href="http://www.rackspacecloud.com/blog/2009/11/09/nosql-ecosystem/" title="NoSQL Ecosystem">NoSQL Ecosystem</a>
 以表格的方式对当今<strong>主流的分布式数据库</strong>
做了比较。类似的比较还有 <a title="Quick Reference to Alternative data storages" href="http://themindstorms.blogspot.com/2009/05/quick-reference-to-alternative-data.html" title="Quick Reference to Alternative data storages">Quick Reference to Alternative data storages</a>
。Ellis 的文章除了表格对比外对于想了解 NoSQL 生态的人来说是非常值得一读的，该文章内涵丰富，短小精悍；而 <a title="Quick Reference to Alternative data storages" href="http://themindstorms.blogspot.com/2009/05/quick-reference-to-alternative-data.html" title="Quick Reference to Alternative data storages">Quick Reference to Alternative data storages</a>
 主要是表格，这些表格对比的内容又比 Ellis 的完整。
</li>
</ol>
<h4><strong>相关国外资源</strong>
</h4>
<p>&nbsp;&nbsp;&nbsp; <a id="d2ma" title="http://nosql-databases.org" href="http://nosql-databases.org/" title="http://nosql-databases.org">http://nosql-databases.org</a>
 &mdash;&mdash; 该站点的标语是：&ldquo;非关系型世界的终结向导！&rdquo;，该站点非常确信自己是：&ldquo;在互联网上拥有 NoSQL 相关链接最多的网站。&rdquo;总之，该网站值得关注。<br />
&nbsp;&nbsp;&nbsp;&nbsp; 另外，作为 NoSQL 极客（geeks），请 follow&nbsp;<a title="@nosqlupdate" href="http://twitter.com/nosqlupdate" title="@nosqlupdate">@nosqlupdate</a>
。另外，请 follow <a title="@al3xandru" href="http://twitter.com/al3xandru" title="@al3xandru">@al3xandru</a>
 （<a title="MyNoSQL blog" href="http://nosql.mypopescu.com/" title="MyNoSQL blog">MyNoSQL blog</a>
 与 <a title="NoSQL Week in Review" href="http://nosql.mypopescu.com/post/272903545/nosql-week-review-part-1" title="NoSQL Week in Review">NoSQL Week in Review</a>
 的创建者）。<a title="NoSQL Week in Review" href="http://nosql.mypopescu.com/post/272903545/nosql-week-review-part-1" title="NoSQL Week in Review">NoSQL Week in Review</a>
 比较新，希望能保持正常更新，因为它确实很棒！<br />
&nbsp;&nbsp;&nbsp;&nbsp; 当然，您还可以看看 Ricky Ho 最近的博文，他总结了一些分布式数据存储技术关键点。他的博文中有两篇非常值得一看的文章：<a title="Query Processing for NoSQL Databases" href="http://horicky.blogspot.com/2009/11/query-processing-for-nosql-db.html" title="Query Processing for NoSQL Databases">Query Processing for NoSQL Databases</a>
，还有 <a title="NoSQL Design Patterns" href="http://horicky.blogspot.com/2009/11/nosql-patterns.html" title="NoSQL Design Patterns">NoSQL Design Patterns</a>
。</p>
<h4><strong>相关国内资源</strong>
</h4>
<ul>
<li><a id="jdy:" title="Tim[后端技术]" href="http://timyang.net/" title="Tim[后端技术]">Tim[后端技术]</a>
：<a id="rioi" title="分布式 Key Value Store 漫谈" href="http://www.slideshare.net/iso1600/key-value-store" title="分布式 Key Value Store 漫谈">分布式 Key Value Store 漫谈</a>
</li>
<li><a id="kp_-" title="CSDN 新闻频道" href="http://news.csdn.net/" title="CSDN 新闻频道">CSDN 新闻频道</a>
：<a id="kmu8" title="豆瓣开源 Key Value 存储系统 BeansDB" href="http://news.csdn.net/a/20091231/216203.html" title="豆瓣开源 Key Value 存储系统 BeansDB">豆瓣开源 Key Value 存储系统 BeansDB</a>
</li>
<li><a id="s55e" title="robbin的自言自语" href="http://robbin.javaeye.com/" title="robbin的自言自语">robbin的自言自语</a>
：<a id="y6n2" title="NoSQL数据库探讨之一" href="http://robbin.javaeye.com/blog/524977" title="NoSQL数据库探讨之一">NoSQL数据库探讨之一</a>
</li>
<li><a id="o6l3" title="J道" href="http://www.jdon.com/" title="J道">J道</a>
 <a id="dim7" title="BanQ" href="http://www.jdon.com/jivejdon/blog/banq" title="BanQ">BanQ</a>
：<a id="f:g4" title="CAP原理和BASE思想" href="http://www.jdon.com/jivejdon/thread/37625" title="CAP原理和BASE思想">CAP 原理和 BASE 思想</a>
</li>
</ul>
<p><br />
来源：<a href="http://asserttrue.blogspot.com/2009/12/nosql-required-reading.html" target="_blank">NoSQL Required Reading</a>
，<a id="f5eu" title="Wikipedia - NoSQL" href="http://en.wikipedia.org/wiki/NoSQL" title="Wikipedia - NoSQL">Wikipedia - NoSQL</a>
<br />
<br />
编者简介：丁亮，CSDN 特约记者，软件设计师。网络ID：88250，Linux、Open Source 热爱者，擅长 <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JavaSE / JavaEE 开发，熟悉 JSF、EJB、Spring、Seam、OSGi 等框架应用的架构与开发，目前<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 正在深入学习 OOAD 与敏捷过程。个人博客：<a id="z-xe" title="简约设计の艺术" href="http://blog.csdn.net/DL88250" title="简约设计の艺术">简约设计の艺术</a>
。<br /></p>