title: Windows 通过命令行安装根证书
date: '2018-05-03 23:38:06'
updated: '2018-05-03 23:38:06'
tags: [Windows, CA, 根证书, 安全]
permalink: /articles/2018/05/03/1525333052172.html
---
### 背景

有的时候我们需要在用户机器上将自制的 CA 证书安装到“受信任的根证书颁发机构”下，这样就能使用该 CA 颁发自签名的证书了，以便后续完成一些安全相关的操作。

### 工具

在命令行安装证书需要用到证书管理器 `certmgr.exe`，这个二进制可执行文件在 Win10 中 _大概_ 这个路径下，`C:\Program Files (x86)\Windows Kits\8.1\bin\x86\certmgr.exe`，建议把这个二进制打在程序的发布包中，或者让程序从网络上拉取到本地。

不带参直接运行的话会弹出一个简单的图形界面：

![certmgrexepng](https://img.hacpai.com/file/2018/05/bd758134c0374ff5a7a4aa22487d1aae_certmgrexe.png)

另外，还有个证书管理器 `certmgr.msc`，看上去功能更多一些，不过这个是纯图形界面的：

![certmgrmscpng](https://img.hacpai.com/file/2018/05/490bf039c59d4b5c9b4d19c9bacb0096_certmgrmsc.png)

### certmgr.exe

可以通过该工具实现证书的管理操作：

```
D:\>certmgr.exe /?
Usage: CertMgr [options][-s [-r <location>][SourceStoreName]
                        [-s [-r <location>][DestinationStoreName]
Options:
 -add               Add certificates/CRLs/CTLs to a storeFile or a system store
 -del               Delete certificates/CRLs/CTLs from a storeFile or
                    a system store
 -put               Put an encoded certificate/CRL/CTL from a storeFile or
                    a system store to a file.  The file will be saved in X.509
                    format. -7 can be used to save the file in PKCS #7 format
 -s                 Indicate the store is a system store
 -r    <location>   The system store location
                        <currentUser|localMachine> Default to 'currentUser'
 -c                 Certificates in the store
 -crl               Certificates revocation lists(CRLs) in the store
 -ctl               Certificates trust lists(CTLs) in the store
 -v                 Verbose display of the certificates/CRLs/CTLs
 -all               All certificates/CRLs/CTLs in the store
 -n    <name>       Common name of the certificate
 -sha1 <thumbPrint> The sha1 hash of the certificate/CRLs/CTLs
 -7                 Save the destination store in PKCS #7 format
 -e    <encode>     Certificate/CRL/CTL encoding type.
                    Default to X509_ASN_ENCODING
 -f    <flag>       CertStore open flags.  Meaningful only if -y is set
 -y    <provider>   CertStore provider name
``` 

我们的目标是将 CA 证书导入到“受信任的根证书颁发机构”下，可以通过如下命令参数实现：`certmgr.exe /c /add ca.crt /s root`

导入之前可以通过 `certmgr.exe /all /s root` 来查询是否已经导入过。

### 结论

* certmgr.exe 需要自己分发到确定的路径下再调用
* 作为用户不要轻易安装来历不明的证书
