title: OpenShift 技术架构概述
date: '2012-10-30 17:47:22'
updated: '2012-10-30 17:47:22'
tags: [OpenShift, PaaS, Open Source, Cloud]
permalink: /openshift-tech-architecture-overview
---
<h1>OpenShift 技术架构概述</h1>
<h2>平台概述</h2>
<p>OpenShift 让用户可以创建、部署、管理云端应用，其云环境具体提供了磁盘空间、CPU 计算资源、内存资源、网络连接以及应用服务器。根据不同应用类型（数据库、编程语言等），OpenShift 会提供不同的文件系统布局（例如 PHP、Python、Ruby、Java）来创建不同的运行环境。此外，OpenShift 也提供了一定程度的 DNS（域别名）。</p>
<p>OpenShift 也为不同应用提供了临时文件存取（/var/tmp），超过 10 天没有被访问的文件将被自动删除。</p>
<p>OpenShift 中包含两个基本的功能单元：</p>
<ul>
<li>Broker，提供了接口</li>
<li>Cartridges，提供了应用框架</li>
</ul>
<h3>Broker</h3>
<p>Broker 是所有应用管理活动的入口。它主要负责管理用户登录、DNS、应用状态以及应用服务编排（服务分发）。用户和 Broker 交互主要是通过 Web 管理控制台、CLI 工具、JBoss 工具或者是 REST API。</p>
<h3>Cartridges</h3>
<p>Cartridges 为应用运行提供了实际所需的功能。比如一些 cartridges 提供编程语言支持（PHP、Python、Java 等），另一些则提供数据库支持（PostgreSQL、MySQL、MongoDB）。</p>
<p><img src="https://t8idhq.dm1.livefilestore.com/y1m4TzGjBI2ltEH3xrnZOSARt-jjAxituB2bwkq47JLmDoL5AvoR1jGdt5D_15HL_MnJPGnMKaV29yQlxswyS1OjcBEWW3VekUEfqkAOlNdkaMnvE7zXHpyyg/OpenShift-1.png?psid=1" alt="" width="660" height="140" /></p>
<h2>系统资源与应用容器</h2>
<p>OpenShift 内是通过 gears、nodes 以及 districts 来管理系统资源与应用容器的。</p>
<ul>
<li>Gears：提供了给 cartridges 运行的容器。一个或多个 cartridges 可在其中运行，gear 为每个 cartridge 提供有限的内存与磁盘空间。<br /><img src="https://t8idhq.dm1.livefilestore.com/y1mJJPdJRbXdrlFJ7zDdDlx7qf9AcxNVJDHE1aYC20M1bHnMAmgSXbfWgh-ds_ljSTh0LsXxq-qqdx4FrGlylclM8JahnhX2GKIjpr9A72y4Ac4WWaQQejRnA/OpenShift-2.png?psid=1" alt="" width="660" height="180" /></li>
<li>Nodes：一台物理机或虚拟机，其中包含多个 gears。因为某些 gear 并不是时时刻刻处于运行中，所以一个 node 通常会处于超配额状态，即放入了超过限额个数的 gears。</li>
<li>Districts：定义了一些 nodes，其中的 gears 可以方便地进行 node 负载均衡。所以即使是某个 gear 负载很高时也不会发生 node 运行超载。<br /><img src="https://t8idhq.dm1.livefilestore.com/y1mpMcRjmYqEAhaJpOSEAFSu1Zu7Z_bNWIGp8EbwLT-ZGwUBpitdA_uKN_jCf98W95jkk5icJU5HPoIK4oiAGUp7-5rWjii2TK8XZzvcM3YYOIemi5Q3FVcjA/OpenShift-3.png?psid=1" alt="" width="660" height="180" /></li>
</ul>
<h2>OpenShift 应用</h2>
<p>一个用户名只能使用一个 namespace，一个 namespace可以创建多个应用。</p>
<p><img src="https://t8idhq.dm1.livefilestore.com/y1mwk7XQZ3sA_ba1STl2FbmGpIzHeKjNvzdkrjPEGgswT_HJGwADteeFyDMS-JJvqmp2CIDqSbBPCPbdHliB2BW43tFoaQGwZq7VvhFsDagH6AAkI1T_1G4rA/OpenShift-4.png?psid=1" alt="" width="660" height="230" /></p>
<p>应用是由一系列部分构成：</p>
<ul>
<li>Namespace</li>
<li>App Name</li>
<li>Aliases</li>
<li>Git Repository</li>
<li>App Dependencies（例如数据库 Cartridges）</li>
</ul>
<h3>伸缩性</h3>
<p>OpenShift 上分为两个应用，可伸缩应用与不可伸缩应用。</p>
<ul>
<li>可伸缩应用：可伸缩应用按需获取系统资源。一个可伸缩应用至少会使用两个 gears，一个用于应用本身，一个用于高可用代理（HAProxy）实现负载均衡。</li>
<li>不可伸缩应用：只能使用一个 gear。</li>
</ul>
<p>Web 请求到达负载均衡代理 HAProxy 后，它将请求转发给 gear 中的应用。当 HAProxy 探测到请求过载时，OpenShift 复制一份已经存在的 Web cartridge 到一个单独的 gear 里，与已有 gears 一起处理请求，提升了两倍请求处理能力。</p>
<p><img src="https://t8idhq.dm1.livefilestore.com/y1mZUuPhXn0va8RM9WZBOWY5hpLMfuO6xh8FvBsQnLTOqUYupMtrInY9VEq_Qec61-UoRABnt-HnPKN8i4KKIJYaKBBsE1MxgVQTJMMnaXcj3nJPaArIU-Ztg/OpenShift-5.png?psid=1" alt="" width="435" height="592" /></p>
<h2>用户交互</h2>
<p><img src="https://t8idhq.dm1.livefilestore.com/y1mbVNk8kt90Qlem5LDYL4uxDd8klxZs9l6EqfFK1F3otJN2jx6pnCP0HbQItw4oPFk4jVXJjuX3wqzSnkTon9t1AooIbGAQ6T29wcXJLlBpili-zvdx8YcvA/OpenShift-6.png?psid=1" alt="" width="588" height="514" /></p>
<p>通过 git push 命令进行部署，也可以使用 Jenkins （cartridge）进行持续集成。</p>
<p><img src="https://t8idhq.dm1.livefilestore.com/y1m3zRDISgCtV8gMuIHSswK1tCt4oWwR2Z6YRn90AKoe49hoCIIsRZB0oueU4o7zg0JPzUpH3Dr237ExhrmZlvPvVwwmwTdp31JklIu0cyYYWo7eHrSZ1ksFQ/OpenShift-7.png?psid=1" alt="" width="632" height="314" /></p>
<h2>参考</h2>
<ul>
<li><a href="https://access.redhat.com/knowledge/docs/en-US/OpenShift/2.0/html/User_Guide/index.html">OpenShift User Guide 2.2.17</a></li>
<li><a href="https://openshift.redhat.com/community/wiki/architecture-overview">OpenShift Community Wiki</a></li>
</ul>