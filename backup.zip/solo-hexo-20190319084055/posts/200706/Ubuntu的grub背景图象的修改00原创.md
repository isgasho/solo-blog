title: Ubuntu的grub背景图象的修改[00原创]
date: '2007-06-05 02:59:00'
updated: '2007-06-05 02:59:00'
tags: [My Linux]
permalink: /articles/2007/06/04/1180954740000.html
---
<div class="cnt"><span></span><span style="color: rgb(0, 0, 0);"><span>sudo apt-get install </span></span>grub<span style="color: rgb(0, 0, 0);"><span>-splashimages</span></span>
<p style="color: rgb(0, 0, 0);"><span><span>#这里把你下载的splash image放到/boot/grub/下，文件名注意用splash.xpm.gz<br /></span></span></p>
<p style="color: rgb(0, 0, 0);"><span><span><span><span>sudo update-</span></span></span></span>grub</p>
<p style="color: rgb(0, 0, 0);">下面是一个PL的image<br /></p>
<p><span><span><span><span><strong><font color="#ffa34f"><a target="_blank" href="http://forum.ubuntu.org.cn/download.php?id=7934">下载</a></font></strong></span></span></span></span></p>
</div>
&nbsp;