title: 在 Ubuntu 7.10 上安装 Compiz Fusion
date: '2007-10-20 06:54:00'
updated: '2007-10-20 06:54:00'
tags: [My Linux]
permalink: /articles/2007/10/19/1192805640000.html
---
<div class="cnt">
<p>现在7.10的官方源里面已经有了，就不用添加了<br /> </p>
<p><br /> 1.更新系统<br /> <code>sudo apt-get update</code></p>
<p><code>sudo apt-get dist-upgrade</code></p>
<p>2.安装 Compiz 和 Compiz Fusion<br /> <code>sudo apt-get install compiz compiz-gnome compiz-fusion-* compizconfig-settings-manager libcompizconfig-backend-gconf</code></p>
<p>3.运行 Compiz Fusion</p>
<p>在会话里加入</p>
<p><code>compiz --replace</code></p>
<p>4.在 &ldquo;系统 -&gt; 首选项 -&gt; CompizConfig Settings Manager &rdquo; 这里设置 Compiz Fusion。</p>
<br />
<p>如果想要使用 Compiz Fusion + emerald</p>
<p><code>sudo apt-get install emerald</code><br /> </p>
<p>在会话里加入</p>
<p><code>compiz --replace -c emerald &amp;</code></p>
</div>
&nbsp;