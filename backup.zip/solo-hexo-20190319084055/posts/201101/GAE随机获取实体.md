title: GAE 随机获取实体
date: '2011-01-11 05:16:02'
updated: '2011-01-11 05:16:02'
tags: [Java, GAE, B3log]
permalink: /get-gae-random-entities.html
---
<p>有时我们需要随机地获取数据记录（实体），比如博客程序中的&ldquo;随机文章&rdquo;的实现。</p>
<p>目前 GAE 并没有 API 可以直接获取随机实体，要实现这样的需求我们只能自己想办法了 :-)</p>
<p>在 stackoverflow 上也有人提过<a href="http://stackoverflow.com/questions/4351715/gql-random-record" target="_blank">该问题</a>，总结如下：</p>
<blockquote>
<ul>
<li>Generate and store a random number on your entities as you create them, then pick a random number and look (via a query) for the closet record(s) to it.</li>
<li>Implement some mechanism to ensure your entity ids are "densely" populated, then fetch within the known range using keys.</li>
<li>Periodically generate random lists of the entities and return entities from those lists.  This may take the form of a stack that entities are popped off of, or as actual lists that are returned.</li>
</ul>
</blockquote>
<p>目前 <a href="http://code.google.com/p/b3log-solo/" target="_blank">B3log Solo</a> 在处理&ldquo;随机阅读&rdquo;上采用的是方法一，即在每个文章实体上添加一个属性保存 0-1 的随机浮点数。</p>
<p>在获取随机文章时生成一个 0-1 的随机数（mid）作为查询条件，以此查询条件作为边界（0 &lt;= mid &lt;=1）来过滤实体保存的随机值属性。</p>
<p>这个方法基本可以达到随机的效果了，为了让随机的效果更动态一点，我们可以考虑经常更新文章实体中的随机浮点值：</p>
<ul>
<li>访问文章时（即在更新文章浏览次数时一并更新该文章的随机浮点值）</li>
<li>后台定时任务（获取一定数量的随机文章然后更新它们的随机浮点值）</li>
<li>用户做文章更新时</li>
</ul>
<p>加上以上处理后，随机的效果比较好了 :-)</p>