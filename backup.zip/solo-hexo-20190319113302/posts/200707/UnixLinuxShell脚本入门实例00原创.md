title: Unix/Linux Shell脚本入门实例[00原创]
date: '2007-07-04 10:26:00'
updated: '2007-07-04 10:26:00'
tags: [Shell Programming]
permalink: /articles/2007/07/03/1183487160000.html
---
这是一个简单了Shell实例。<br />下面是它的要求描述：<br />
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="LEGEND" name="AUTHOR" />
<meta content="20050510;19440000" name="CREATED" />
<meta content="SEI" name="CHANGEDBY" />
<meta content="20050106;15320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
		A:link { color: #0000ff }
	-->
	</style>
<p style="text-indent: 3.7cm; margin-bottom: 0cm;">实验五    <font face="文鼎PL细上海宋Uni, serif">UNIX <span lang="en-GB">Shell </span></font>程序设计</p>
<p style="margin-bottom: 0cm;"><br /> </p>
<ol>
    <li>
    <p style="margin-bottom: 0cm;">实验内容：使用<font face="文鼎PL细上海宋Uni, serif">UNIX 	<span lang="en-GB">S</span>hell</font>程序设计语言，编写<font face="文鼎PL细上海宋Uni, serif">UNIX 	<span lang="en-GB">S</span>hell </font>应用程序。</p>
    </li>
</ol>
<p style="margin-left: 0.32cm; margin-bottom: 0cm;"><br /> </p>
<ol start="2">
    <li>
    <p style="margin-bottom: 0cm;">实验要求：按下列要求编写<font face="文鼎PL细上海宋Uni, serif">Shell</font>脚本，把所学的各种<font face="文鼎PL细上海宋Uni, serif">UNIX</font>命令串联起来。</p>
    </li>
</ol>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">1.</font>运行<font face="宋体, SimSun">Shell</font>脚本，首先显示类似如下的菜单：</p>
<p style="margin-bottom: 0cm;">           <font face="宋体, SimSun">What would you like to do:</font></p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"> <font face="宋体, SimSun">List Directory **********************1</font></p>
<p style="margin-bottom: 0cm;">     <font face="宋体, SimSun">Change Directory*********************2</font></p>
<p style="margin-bottom: 0cm;">     <font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">Edit file****************************3</font></font></p>
<p style="margin-bottom: 0cm;">     <font face="宋体, SimSun">Remove file**************************4</font></p>
<p style="margin-bottom: 0cm;">     <font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">Add messages in a file***************5</font></font></p>
<p style="margin-bottom: 0cm;">     <font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">Search keyword in a specified file***6</font></font></p>
<p style="margin-bottom: 0cm;">     <font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">Exit Menu****************************7</font></font></p>
<p style="text-indent: 2.41cm; margin-bottom: 0cm;"><font face="宋体, SimSun">Enter your choice:</font></p>
<p style="text-indent: 2.41cm; margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">2</font>．输入<font face="宋体, SimSun">1</font>：以长格式列出当前目录内容。</p>
<p style="margin-left: 1.11cm; text-indent: -0.37cm; margin-bottom: 0cm;"> <font face="宋体, SimSun">3</font>．输入<font face="宋体, SimSun">2</font>：改变工作目录到自己指定的目标目录中。（要求改变后可以用选项<font face="宋体, SimSun">1</font>查看该目录中的内容）</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">4</font>．输入<font face="宋体, SimSun">3</font>：提示输入一个文件名（该文件可能不存在），然后调用<font face="宋体, SimSun">vi</font>编辑器进行编辑。</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">5</font>．输入<font face="宋体, SimSun">4</font>：删除一个指定的文件。</p>
<p style="margin-left: 1.3cm; text-indent: -0.56cm; margin-bottom: 0cm;"> <font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">6</font></font>．输入<font face="文鼎PL细上海宋Uni, serif">5: </font>提示输入一个文件名，然后将用户在键盘上命令行方式下输入的任何信息都添加并保存到这个文件中，直到用户输入一个空行后才完成该项操作。</p>
<p style="margin-left: 1.48cm; text-indent: -0.37cm; margin-bottom: 0cm;">  注意：该操作不能是只输入一行后就停止，要能不断输入多行信息；不能调用<font face="文鼎PL细上海宋Uni, serif">vi</font>编辑器来输入。</p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">例如：一个名为&rdquo;<font face="文鼎PL细上海宋Uni, serif">phone&rdquo;</font>的文件，原有内容为（也可以是无内容的新文件）：</p>
<p style="text-indent: 2.75cm; margin-bottom: 0cm;">&ldquo; <font face="文鼎PL细上海宋Uni, serif">This is a phone list&rdquo;</font></p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm;">现在要在其后添加一些电话薄的字段信息，</p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm;">选择&ldquo;<font face="文鼎PL细上海宋Uni, serif">5&rdquo;</font>后，显示：<font face="文鼎PL细上海宋Uni, serif">Input the filename that you want to add messages:</font></p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm;">然后从键盘输入文件名：<font face="文鼎PL细上海宋Uni, serif">phone</font></p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm;">接着提示：输入要添加的信息，例如用户要添加如下信息：</p>
<p style="text-indent: 3.18cm; margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">David  Brown    (7771)   91101111    <font color="#0000ff"><a href="mailto:m@m.com"><font color="#000000"><span style="text-decoration: none;">m@m.com</span></font></a></font>      &hellip;&hellip;&hellip;&hellip;</font></p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Emma  Redd      (6970)   22292222    <font color="#0000ff"><a href="mailto:in@o.com"><font color="#000000"><span style="text-decoration: none;">in@o.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Tom  Swanson    (823)    44474444    <font color="#0000ff"><a href="mailto:ai@e.com"><font color="#000000"><span style="text-decoration: none;">ai@e.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Ming  Li        (0871)   3133333     <font color="#0000ff"><a href="mailto:bb@r.com"><font color="#000000"><span style="text-decoration: none;">bb@r.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="margin-bottom: 0cm;">&hellip;&hellip;&hellip;&hellip;&hellip;<font face="文鼎PL细上海宋Uni, serif">.         &hellip;&hellip;     &hellip;&hellip;..       &hellip;&hellip;&hellip;&hellip;     &hellip;&hellip;&hellip;..</font></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="margin-left: 1.85cm; margin-bottom: 0cm;">输入完成后，当用户输入一个空行即完成该项添加信息的操作<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">,</font></font>并退出该选项。该&rdquo;<font face="文鼎PL细上海宋Uni, serif">phone&rdquo;</font>文件添加后变为：（可以用选项<font face="文鼎PL细上海宋Uni, serif">3</font>查看）</p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="margin-bottom: 0cm;">                         </p>
<p style="text-indent: 5.74cm; margin-bottom: 0cm;"> <font face="文鼎PL细上海宋Uni, serif">This is a phone list   </font> </p>
<p style="text-indent: 2.04cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">David  Brown    (7771)   91101111    <font color="#0000ff"><a href="mailto:m@m.com"><font color="#000000"><span style="text-decoration: none;">m@m.com</span></font></a></font>      &hellip;&hellip;&hellip;&hellip;</font></p>
<p style="text-indent: 2.04cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Emma  Redd      (6970)   22292222    <font color="#0000ff"><a href="mailto:in@o.com"><font color="#000000"><span style="text-decoration: none;">in@o.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="text-indent: 2.04cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Tom  Swanson    (823)    44474444    <font color="#0000ff"><a href="mailto:ai@e.com"><font color="#000000"><span style="text-decoration: none;">ai@e.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="text-indent: 2.04cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif">Ming  Li        (0871)   3133333     <font color="#0000ff"><a href="mailto:bb@r.com"><font color="#000000"><span style="text-decoration: none;">bb@r.com</span></font></a></font>     &hellip;&hellip;&hellip;..</font></p>
<p style="margin-bottom: 0cm;">&hellip;&hellip;&hellip;&hellip;&hellip;<font face="文鼎PL细上海宋Uni, serif">.         &hellip;&hellip;     &hellip;&hellip;..       &hellip;&hellip;&hellip;&hellip;     &hellip;&hellip;&hellip;..</font></p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">7. </font></font>输入<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">6</font></font>：在指定的文件中查找某个关键字<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">(</font></font>该文件，并显示找到的关键字所在的行。</p>
<p style="margin-left: 1.11cm; margin-bottom: 0cm;">要求：查找时忽略大小写，并在每个找到的输出行前显示行号，<strong>要判断输入的名字是否为文件而非目录</strong>，若是文件则进行查找工作，若文件不存在或是目录则显示出错信息。</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">8</font></font>．输入<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">7</font></font>：退出该脚本程序，回到<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">Shell</font></font>提示符下。</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">9</font></font>．在源程序中加入适当的注释。</p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><strong>注意：该菜单要能够反复显示，即各项选完后要能再次返回菜单。</strong></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<ol start="3">
    <li>
    <p style="margin-bottom: 0cm;">实验报告：</p>
    </li>
</ol>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">1</font>、将自己编制并调试好的程序，用到的各种文件放在自己的用户主目录下。</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">2</font>、抄写自己的<font face="宋体, SimSun">Shell</font>源程序（自己加纸写）</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">3</font>、写出设计思想。</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">4</font>、写出上机体会与总结</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm;"><font face="宋体, SimSun">5</font>、回答问题：执行脚本的方式有哪几种，有何区别？</p>
<br /><br /><font size="2"><span style="color: rgb(255, 0, 0);">完成报告如下：</span></font>
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="daniel" name="AUTHOR" />
<meta content="20070703;17484700" name="CREATED" />
<meta content="daniel" name="CHANGEDBY" />
<meta content="20070703;18203900" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style>
<p align="center" style="margin-bottom: 0cm;"><strong>实验五    </strong><font face="文鼎PL细上海宋Uni, serif"><strong>UNIX </strong><span lang="en-GB"><strong>Shell </strong></span></font><strong>程序设计</strong></p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><strong>1. </strong></span></span></font></font><span style="text-decoration: none;"><font size="2"><strong>源代码如下：</strong></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#!/bin/bash</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">C=&quot;0&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do list directory</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">listDirectory()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">ls -l ./</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do change the directory</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">changeDirectory()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the New Directory Path : &quot; CDI</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style=""># check out wether the directory is exist</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ -d $CDI ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	cd $CDI</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">else</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	printf &quot;the Directory is not Exist\n&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do edit a file</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">editFile()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">NFILE=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the File Name to Edit : &quot; NFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">vi $NFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do remove a file</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">removeFile()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">RFILE=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the File Name to Remove : &quot; RFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ -f $RFILE ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	rm $RFILE</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">else</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	printf &quot;the File is not Exist\n&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do input messages</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">addMessages()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">MFILE=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the File Name to Add Messages : &quot; MFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;">      </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style=""># start to add new messanges</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">MMSG=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the Messages : &quot; MMSG</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">while [ &quot;$MMSG&quot; != &quot;&quot; ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">do</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">echo $MMSG &gt;&gt; $MFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">MMSG=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the Messages : &quot; MMSG</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">done</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;End of the file\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do search Keyword</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">searchKeyword()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">SFILE=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the File Name : &quot; SFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style=""># if it is a directory's name</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ -d $SFILE ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	printf &quot;the Name input is a Directory\n&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	return</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style=""># if the file is not exist</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ ! -f $SFILE ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	printf &quot;the File is not Exist\n&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	return</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">KWORD=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Please Input the KeyWord : &quot; KWORD</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ &quot;$KWORD&quot; != &quot;&quot; ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	cat $SFILE | grep -n -i $KWORD</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"># Do display the menu</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">#</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">displayMenu()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;      What Would You Like to Do:        \n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;List Directory ....................... 1\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Change Directory ..................... 2\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Edit File ............................ 3\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Remove File .......................... 4\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Add Messages in a File ............... 5\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Search Keyword in a Specified File ... 6\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">printf &quot;Exit Menu ............................ 7\n&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">getUserInput()</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">{</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Enter Your Choice : &quot; C</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">}</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">while [ $C != &quot;7&quot; ]</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">do</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">        </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">displayMenu</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	getUserInput</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	case $C in</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    1) printf &quot;\n&quot; ; listDirectory;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    2) printf &quot;\n&quot; ; changeDirectory;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    3) printf &quot;\n&quot; ; editFile;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    4) printf &quot;\n&quot; ; removeFile;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    5) printf &quot;\n&quot; ; addMessages;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    6) printf &quot;\n&quot; ; searchKeyword;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    7) printf &quot;\nThank You for Using, bye-bye\n&quot;;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	    *) printf &quot;\bWrong Choice\n&quot;;;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	esac</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">done</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><strong>2. </strong></span></span></font></font><span style="text-decoration: none;"><font size="2"><strong>测试输出：</strong></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">daniel@daniel-laptop:~/Desktop$ sh lab5.sh</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">total 19780</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">-rw-r--r-- 1 daniel daniel       0 2007-07-02 17:31 133888847954 </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">关文武</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r-- 1 daniel daniel    2497 2007-07-03 11:07 lab5.sh</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r-- 1 daniel daniel 8220990 2007-07-03 13:40 nuoveXT-1.6.tar.gz</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r-- 1 daniel daniel 8605556 2007-07-03 13:32 nuoveXT.2.1.tar.bz2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x 3 daniel daniel    4096 2007-07-01 20:22 swt-M20070212-1330-gtk-linux-x86</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r-- 1 daniel daniel 3176199 2007-07-01 18:14 swt-M20070212-1330-gtk-linux-x86.zip</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x 3 daniel daniel    4096 2007-02-12 14:51 swt-M20070212-1330-win32-win32-x86</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">-rwxrwx--- 1 daniel daniel  191871 2007-05-25 00:22 </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">设计模式迷你手册</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">.chm</span></span></font></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">-rw-r--r-- 1 daniel daniel     647 2007-06-28 11:47 </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">音频</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">ID</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">技术流程</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the New Directory Path : /home/daniel</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">total 6324</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rwxr--r--  1 daniel daniel 5090214 2007-05-29 22:08 1.mp3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel  274432 2007-04-18 13:02 BattleLANv0.5.exe</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  8 daniel daniel    4096 2007-06-30 01:21 Beautify</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel  196608 2007-06-11 14:53 DB2 UDB 700 .doc</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  4 daniel daniel    4096 2007-07-03 17:53 Desktop</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  2 daniel daniel    4096 2007-05-03 12:42 Downloads</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel    1430 2007-05-29 17:12 Instantiations.license</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel  172032 2006-11-20 22:32 IPMSG2007.exe</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel    1114 2007-07-01 23:33 ipmsg.log</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel     365 2007-06-29 22:46 jws_app_shortcut_1183128375333.desktop</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  6 daniel daniel   12288 2007-05-03 16:07 LumaQQ</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel     409 2007-06-20 10:23 MyQQID</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  3 mysql  daniel    4096 2007-07-01 15:51 mysql</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel  434176 2007-07-02 00:57 nautilus-debug-log.txt</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-sr-x 11 root   root      4096 2007-06-06 23:39 RealPlayer</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x  4 daniel daniel    4096 2007-06-18 00:30 Software Install Package</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel    3405 2007-07-01 21:58 velocity.log</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">-rw-r--r--  1 daniel daniel      63 2007-06-19 11:34 War3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x 11 daniel daniel    4096 2007-07-02 00:45 WarCraft</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">drwxr-xr-x 10 daniel daniel    4096 2007-06-29 01:20 Work</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">-rw-r--r--  1 daniel daniel  198144 2007-05-02 12:19 </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">系分论文</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">.doc</span></span></font></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">-rw-r--r--  1 daniel daniel      93 2007-05-30 22:43 </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">飞鸽传书</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the File Name to Edit : testfile</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the File Name to Add Messages : testfile</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the Messages : 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the Messages : 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the Messages : 8</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the Messages : 9</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the Messages : </span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">End of the file</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the File Name to Edit : testfile</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Input the File Name : testfile</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Please Input the KeyWord : 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">7:7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">What Would You Like to Do:        </span></span></span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">List Directory ....................... 1</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Change Directory ..................... 2</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Edit File ............................ 3</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Remove File .......................... 4</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Add Messages in a File ............... 5</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Search Keyword in a Specified File ... 6</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Exit Menu ............................ 7</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Enter Your Choice : 7   </span></font></font> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">Thank You for Using, bye-bye</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><strong>3. </strong></span></span></font></font><span style="text-decoration: none;"><font size="2"><strong>设计思路</strong></font></span></p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;"><font size="2"><span style="">需求中的</span></font></span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">1-5</span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">比较简单，这里就不赘述了。主要解释一下</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">6</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">、</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">7</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">点的需求是如何设计与实现的。</span></font></span></p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">6)</span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">需求即对应源代码里的</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">addMessage</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">函数，主要原理是利用重定向操作把用户的输入数据追加到文件末尾，主要代码如下：</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">while [ &quot;$MMSG&quot; != &quot;&quot; ]</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">do</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">echo $MMSG &gt;&gt; $MFILE</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">MMSG=&quot;&quot;</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">      </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">read -p &quot;Input the Messages : &quot; MMSG</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">done</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">7)</span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">该需求对应源代码里的</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">searchKeyword</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">函数，在判断完用户的输入文件名的合法性与文件是否存在之后，使用</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">grep(</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">带参数 </span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">-n</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">回应行号 </span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">-i</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">忽略大小写</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">)</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">进行查找。主要代码如下：</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">KWORD=&quot;&quot;</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">read -p &quot;Please Input the KeyWord : &quot; KWORD</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">if [ &quot;$KWORD&quot; != &quot;&quot; ]</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">then</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB">	cat $SFILE | grep -n -i $KWORD</span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">fi</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;">    </span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">return</span></span></span></font></font></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><strong>4. </strong></span></span></font></font><span style="text-decoration: none;"><font size="2"><strong>上机体会与总结</strong></font></span></p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">1</span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">）在写</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">Shell</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">脚本的时候我们应该注意使用重定向操作符，方便完成对文件的</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">I/O</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">操作</span></font></span></p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">2</span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">）应该学会使用</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">grep, awk</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">之类的文本操作工具，这样当我们处理大量文本操作的时候效率将大大提高  </span></font></span> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style="">3) </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">写</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">shell</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">脚本的时候要注意</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">Shell</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">脚本的语法和</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">C</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">语言的语法的区别，不要搞混了</span></font></span></p>
<p align="left" style="margin-bottom: 0cm; text-decoration: none;"> <br /> </p>
<p align="left" style="margin-bottom: 0cm;"><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><strong>5. </strong></span></span></font></font><span style="text-decoration: none;"><font size="2"><strong>执行</strong></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><strong>Shell</strong></span></font></font></span><span style="text-decoration: none;"><font size="2"><strong>脚本的方式</strong></font></span></p>
<p align="left" style="margin-bottom: 0cm;"><span style="text-decoration: none;"><font size="2"><span style="">执行一个脚本一般有三种方法：</span></font></span><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="text-decoration: none;"><span style=""><br />1) </span></span></span></font></font><span style="text-decoration: none;"><font size="2"><span style="">将该脚本权限设置为可执行</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">(chmod +x filename)</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">，然后直接用脚本的名字执行，这种方法相当于一个普通的命令。</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style=""><br />2) . filename (</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">点空格</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">filename</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">，这样就默认使用</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">sh</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">执行该脚本，并且不生成子</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">shell</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">，是在当前</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">shell</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">下运行</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">,</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">不用设置可执行权限。</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style=""><br />3) sh filename (</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">生成子</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">shell,</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">在该种模式下常用于调试脚本，如</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">sh -x filename</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">，也不用设置可执行权限</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">)</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">。</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style=""><br /></span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">当然还可以用</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style="">exec</span></span></font></font></span><span style="text-decoration: none;"><font size="2"><span style="">来执行，但一般不用，因为可能会有点危险。</span></font><font face="文鼎PL细上海宋Uni, serif"><font size="2"><span lang="en-GB"><span style=""><br /></span></span></font></font></span><br /> </p>