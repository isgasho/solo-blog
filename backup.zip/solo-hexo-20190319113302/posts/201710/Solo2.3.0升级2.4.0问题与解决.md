title: Solo 2.3.0 升级 2.4.0 问题与解决
date: '2017-10-18 18:11:07'
updated: '2017-10-18 18:11:44'
tags: [Solo, 升级, Bug]
permalink: /articles/2017/10/18/1508292644879.html
---
如果你的 Solo 在 2.3.0 升级 2.4.0 后不能正常打开，请参考如下步骤进行问题确认与解决。

1. 停止 Solo 进程
2. 查看 page 表结构是否存在 pageIcon 字段，如果没有请手动添加 pageIcon varchar(255)
3. 查看 option 表数据，是否存在 oId 列为 statistic 开头的 5 行如下数据，如果不存在就插入 5 行（optionCategory 列表全部使用 `statistic`），**数据来自 statistic 表** 
    ![5615adbb93d9451a89f7d447f8c50c92-image.png](https://img.hacpai.com/file/2017/10/5615adbb93d9451a89f7d447f8c50c92-image.png) 
4. 查看 option 表数据 oId 为 version 的行 optionValue 值是否为 2.4.0，如果不是则改为 2.4.0
5. 确认以上步骤，无误的话删除 statistic 表
6. 重新启动 Solo 进程

该问题主要会发生在使用 MySQL 某些版本的 Solo 上，给大家带来的不便之处请大家多多包涵，原谅原谅。