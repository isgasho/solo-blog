title: 开始学习 Go
date: '2010-11-19 08:57:32'
updated: '2014-08-11 17:11:20'
tags: [Life in Programming, golang]
permalink: /articles/2010/11/18/1290099452140.html
---
<p>刚才按照 <a href="http://golang.org/" target="_blank">Go 官方网站</a>的<a href="http://golang.org/doc/install.html" target="_blank">安装文档</a>安好了 Go。顺带写了个 "Hello World" 。</p>
<p>刚才看了 &ldquo;Go 三天教程&rdquo;的<a href="http://golang.org/doc/GoCourseDay1.pdf" target="_blank">第一篇</a>，非常有意思的语言，目前对这门语言的语感可以用&ldquo;简约、洒脱&rdquo;来形容。</p>
<p>顺便浏览了一下 <a href="http://golang.org/pkg/" target="_blank">Go 的官方包（库）</a>，发现其中包含了 <a href="http://golang.org/pkg/html/" target="_blank">html</a>、<a href="http://golang.org/pkg/http/" target="_blank">http</a>、<a href="http://golang.org/pkg/template/" target="_blank">template</a>、<a href="http://golang.org/pkg/rpc/" target="_blank">rpc</a>、<a href="http://golang.org/pkg/json/" target="_blank">json</a>、<a href="http://golang.org/pkg/websocket/" target="_blank">websocket</a>、<a href="http://golang.org/pkg/crypto/" target="_blank">crypto</a>、等等 Web 相关包，做 Web 应用绝对给力，而且很前沿啊（支持 HTML5）。</p>
<p>明天正式开始学习这门新语言 :-)</p>
<p>&nbsp;</p>