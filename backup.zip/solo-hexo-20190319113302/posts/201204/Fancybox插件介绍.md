title: Fancybox 插件介绍
date: '2012-04-29 01:19:14'
updated: '2012-04-29 01:19:14'
tags: [B3log, B3log Announcement]
permalink: /b3log-solo-041-fancybox-plugin
---
<p>B3log Solo 0.4.1 <a href="https://code.google.com/p/b3log-solo/issues/detail?id=388" target="_blank">加入了</a>一个新的插件&mdash;&mdash;Fancybox，用于预览图片：</p>
<p><a title="图片1" href="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMeqSnSRoJpnlmsgDM7NY9xrJ0qc4gh_j3g4CR0fBXIUkswhfsAJVn2UBzfYpNXrgzAPGCEyonZoMg/9_b.jpg?psid=1" rel="group"> <img src="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMeqSnSRoJpnlmsgDM7NY9xrJ0qc4gh_j3g4CR0fBXIUkswhfsAJVn2UBzfYpNXrgzAPGCEyonZoMg/9_b.jpg?psid=1" alt="图片1" width="100" height="67" /></a>&nbsp; &nbsp;&nbsp; <a title="图片2" href="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMcYA2P8rid1IS8bv1oj6gtYk3Hmi9kgAFecaV_6DxL0637rcFOdSzwYLmpT9ZhYk0Zdk2al5kFb_Q/2_b.jpg?psid=1" rel="group"> <img src="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMcYA2P8rid1IS8bv1oj6gtYk3Hmi9kgAFecaV_6DxL0637rcFOdSzwYLmpT9ZhYk0Zdk2al5kFb_Q/2_b.jpg?psid=1" alt="图片2" width="100" height="67" /></a>&nbsp; &nbsp;&nbsp; <a title="图片3" href="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMf_kI7NJaV13Il-6dWIJ8fFHADgvVo2KjbPW2y5ExsQTg5nKv6pmM4cwY9dHzo8kkWyq3h-JDeP1Q/1_b.jpg?psid=1" rel="group"> <img src="https://public.sn2.livefilestore.com/y1p8xI2lRBkUMf_kI7NJaV13Il-6dWIJ8fFHADgvVo2KjbPW2y5ExsQTg5nKv6pmM4cwY9dHzo8kkWyq3h-JDeP1Q/1_b.jpg?psid=1" alt="图片3" width="100" height="67" /></a>&nbsp; &nbsp;&nbsp; <a title="图片4" href="https://public.sn2.livefilestore.com/y1pb9YCy3mA0EdMB6m2c8A2dzqwvYjiRZmAIzZ6RFhbizKx8UBMVhhc3JZ0D2xIVwfzn_b1wzlp3O_We790b00mxw/3_b.jpg?psid=1" rel="group"> <img src="https://public.sn2.livefilestore.com/y1pb9YCy3mA0EdMB6m2c8A2dzqwvYjiRZmAIzZ6RFhbizKx8UBMVhhc3JZ0D2xIVwfzn_b1wzlp3O_We790b00mxw/3_b.jpg?psid=1" alt="图片4" width="100" height="67" /></a>&nbsp; &nbsp;&nbsp; <a title="图片5" href="https://public.sn2.livefilestore.com/y1poRqMTsyhmFqmR4UJxzcCMCK1vnbS72oR-pV2lCg5kk8C7EvRHgwuEPtqSKniPEQMmKpyFwE8IfMB_5IT_trwbw/7_b.jpg?psid=1" rel="group"> <img src="https://public.sn2.livefilestore.com/y1poRqMTsyhmFqmR4UJxzcCMCK1vnbS72oR-pV2lCg5kk8C7EvRHgwuEPtqSKniPEQMmKpyFwE8IfMB_5IT_trwbw/7_b.jpg?psid=1" alt="图片5" width="100" height="67" /></a></p>
<p>已整合到编辑器中，在插入图片是勾选：</p>
<p><img title="Fancybox使用" src="https://public.sn2.livefilestore.com/y1plhz8oqZQJHWU7IRGS0aCypYXdhbJ5B1t5xMvdsmh5xOE7TYSmVXpNR1U0TgInfdsbebDam_svQFFqk8W23tn1g/QQ%E6%88%AA%E5%9B%BE20120428170738.png?psid=1" alt="Fancybox使用" width="481" height="411" /></p>
<p>默认 Fancybox 插件是开启的，可以在&ldquo;插件管理&rdquo;中选择禁用。</p>
<p>前台浏览时，会按需加载插件资源，只有存在预览图片的页面才会加载 Fancybox JS。</p>
<p>所以即使插件开启，也不必担心会影响页面渲染速度。</p>
<p>&nbsp;</p>
<p>大家有任何使用问题，请<a href="https://code.google.com/p/b3log-solo/issues/entry" target="_blank">提 Issue</a>，;-)</p>