title: Apache URL 重写小记
date: '2011-10-11 23:11:49'
updated: '2011-10-11 23:13:52'
tags: [Apache, mod_rewrite, URL rewrite]
permalink: /apache-http-mod_rewrite
---
<p>示例虚拟主机配置：</p>
<p>&lt;VirtualHost *&gt;<br />&nbsp;&nbsp;&nbsp; ServerName me.test.net<br />&nbsp;&nbsp;&nbsp; DocumentRoot /home/admin/build/test-htdocs/htdocs<br /><br />&nbsp;&nbsp;&nbsp; RewriteEngine on<br />&nbsp;&nbsp;&nbsp; <span style="color: #008000;">RewriteRule</span> ^/$ /a/b/index.html [<span style="color: #ff0000;">R</span>,<span style="color: #0000ff;">L</span>]<br />&nbsp;&nbsp;&nbsp; <span style="color: #008000;">RewriteRule</span> ^/([A-Za-z0-9]+)$ http://127.0.0.1/a/b/c?p=$1 [<span style="color: #ff6600;">P</span>,<span style="color: #808000;">E</span>=Host:me.test.net]<br />&lt;/VirtualHost&gt;</p>
<p>配置了一个虚拟主机来进行对二级域名 me.test.net 的请求处理：</p>
<h3>第 1 条重写规则</h3>
<p>访问 me.test.net 的请求将重定向（<span style="color: #ff0000;">R</span>，302）到 http://me.test.net/a/b/index.html，并且<br />如果这条重写规则命中，则不再匹配后面的重写规则（<span style="color: #0000ff;">L</span>）。</p>
<h3>第 2 条重写规则</h3>
<p>访问 me.test.net/xxx 匹配正则（([A-Za-z0-9]+)）的请求将被代理（<span style="color: #ff6600;">P</span>，同时必须已经启用 <a href="http://httpd.apache.org/docs/2.2/mod/mod_proxy.html" target="_blank">mod_proxy</a> 模块）<br />到 http://127.0.0.1/a/b/c?p=xxx，<span style="color: #808000;">E</span> 表示设定环境变量 Host = me.test.net。</p>
<h3>详细内容可参考</h3>
<ul>
<li><a href="http://httpd.apache.org/docs/2.2/mod/mod_rewrite.html#RewriteRule" target="_blank">Apache Module mod_rewrite</a></li>
<li><a href="http://www.phpchina.com/manual/apache/mod/mod_rewrite.html#RewriteRule" target="_blank">Apache模块 mod_rewrite</a></li>
</ul>
<p>其中，以下细节需要注意：</p>
<ul>
<li>[R,L] 重写规则标记分割符','前后不能有空格</li>
<li>[P] 强制代理模块处理时必须是一个有效的 URL，例如 http://hostname，<br />且其中的 hostname 代理模块必须能够处理，上面的例子就是使用了环境变量 Host=me.test.net 进行了补充</li>
</ul>