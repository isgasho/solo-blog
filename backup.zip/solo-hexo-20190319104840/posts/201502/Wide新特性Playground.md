title: Wide 新特性 —— Playground
date: '2015-02-17 19:11:15'
updated: '2015-02-17 19:27:39'
tags: [golang, Wide, B3log Wide, Playground]
permalink: /golang-playground-in-wide
---
Wide 发布了一个新特性——Playground：[https://wide.b3log.org/playground](https://wide.b3log.org/playground)

* 类似 golang 官方的 [http://play.golang.org](http://play.golang.org)
* 有语法高亮、自动完成
* 通过 WebSocket 实时运行输出
* 能够非常方便的通过 iframe 嵌入到其他网站中

<iframe src="https://wide.b3log.org/playground/8b7cc38b4c12e6fde5c4d15a4f2f32e5.go?embed=true" width="100%" height="600"></iframe>