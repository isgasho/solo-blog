title: Liva运行时截图[00原创]
date: '2007-07-04 03:21:00'
updated: '2007-07-04 03:21:00'
tags: [LivaPlayer]
permalink: /articles/2007/07/03/1183461660000.html
---
呵呵，运行界面终于与大家见面了:-)<br /><br /><img src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_Liva%e7%95%8c%e9%9d%a2.png" alt="" /> <br /><br />