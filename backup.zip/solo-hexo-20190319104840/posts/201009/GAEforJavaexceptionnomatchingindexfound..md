title: 'GAE for Java exception: no matching index found.'
date: '2010-09-13 05:58:00'
updated: '2010-09-13 05:58:00'
tags: [GAE]
permalink: /articles/2010/09/12/1284299880000.html
---
<p><img style="float: left;" src="http://code.google.com/intl/en/appengine/images/appengine_lowres.gif" alt="GAE logo" width="142" height="109" /><br />&nbsp; GAE for Java 版现在还不是非常完善，至少目前 appcfg 还没有删除已建索引的命令。&nbsp; 查了一下邮件列表，早在去年就有人<a title="index questions " href="http://groups.google.com/group/google-appengine-java/browse_thread/thread/c8a7888438efeb9/cdbaeb27befcfd75">问</a>&ldquo;GAE for 如何删除已建索引&rdquo;。</p>
<p>&nbsp; 现在这个问题依旧存在，权宜之计是使用 Python SDK 的 appcfg vacuum_indexes 命令进行删除。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>步骤：</p>
<blockquote>
<p>To remove your indexes from your java app using the python SDK</p>
<p>1) download the python sdk （下载 Python SDK）<br /> 2) in your java project create a app.yaml file with the following <br /> contents （在项目根目录创建 app.yaml 文件，内容如下）</p>
<p>application: YOURJAVA_APPID （改为你的应用标识）<br /> version: 1 <br /> runtime: python <br /> api_version: 1</p>
<p>handlers: <br /> - url: .* <br /> &nbsp; script: main.py</p>
<p>3) from within your java app directory run (assuming appcfg.py is in <br /> your path)&nbsp; （在应用根目录下执行如下命令）<br /> &nbsp; &nbsp; &nbsp; &nbsp; appcfg.py vacuum_indexes .</p>
<p>4) follow the prompts to remove each index. （根据提示进行索引删除）</p>
<p>5) delete the app.yaml file （删除 app.yaml）</p>
<p>6) star the issue here <a rel="nofollow" href="http://google.dailiav.com/browse.php?u=31df56bdd3933Oi8vd3d3Lmdvb2dsZS5jb20vdXJsP3NhPUQmcT1odHRwOi8vY29kZS5nb29nbGUuY29tL3AvZ29vZ2xlYXBwZW5naW5lL2lzc3Vlcy9kZXRhaWwlM0ZpZCUzRDE4OTMmdXNnPUFGUWpDTkVXd3JMRWhOc2R2SWZjUURyY19ZamRpQTVmaEE%3D&amp;b=13" target="_blank">http://code.google.com/p/googleappengine/issues/detail?id=1893</a> （在GAE 开发项目中关注该问题）</p>
</blockquote>
<p>这样一来，基本是解决问题了。希望 GAE for Java 早日修复这个问题。</p><p><span style='font: italic normal normal 11px Verdana'>本文是使用 <a href='http://b3log-solo.googlecode.com/'>B3log Solo</a> 从 <a href='http://b3log-88250.appspot.com:80'>简约设计の艺术</a> 进行同步发布的。</span></p>