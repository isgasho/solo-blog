title: Ubuntu下转换M$ Access到mysql
date: '2007-06-27 14:54:00'
updated: '2007-06-27 14:54:00'
tags: [Database]
permalink: /articles/2007/06/26/1182898440000.html
---
<div class="postentry">
<p>在ubuntu下，至少有两个方法可以转换mdb文件到mysql中：<br /> 1. 使用knoda进行转换<br /> 这个是KDE程序，是图形化界面，非常简单。</p>
<blockquote>
<p>sudo aptitude install  knoda libhk-classes-mdb</p>
</blockquote>
<p>这样安装后就支持MS ACCESS和mysql了。可以非常简单的在二者之间进行转换。<br /> 2. 使用mdbtools进行转换</p>
<blockquote>
<p>sudo aptiutde install mdbtools</p>
</blockquote>
<p>安装完后就可以：</p>
<blockquote>
<p>mdb-schema my.mdb mysql<br /> mdb-export -T table</p>
</blockquote>
<p>这个是基于console的，二者不能一次性完整转换，需要在table级别上自己写脚本来进行转换。</p>
</div>
&nbsp;