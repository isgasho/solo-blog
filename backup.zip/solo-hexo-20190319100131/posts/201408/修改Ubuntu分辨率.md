title: 修改 Ubuntu 分辨率
date: '2014-08-27 19:15:02'
updated: '2014-08-27 19:15:02'
tags: [Ubuntu, 分辨率, xrandr]
permalink: /change-ubuntu-display-resolution
---
<p>通常我们可以在 Settings -&gt; Hardware -&gt; Display 中选择适合的分辨率，但有些情况下这里没有列出合适的分辨率，此时我们可以通过命令调整显示分辨率。</p>
<p>1. 先通过 <code>xrandr</code>&nbsp;获取当前的显示设备名：</p>
<p><a href="https://cuz9cq.dm2301.livefilestore.com/y2pKOwVey190AtvyBmJIu95mxDSmtuSby6SSMQkWpkF_EXExoOeC22pztFtzLy5cmu7Z2jMvm434CjIdpTmkCfAu3FEwYsrUasAX5Xwp64u5sk/xrandr1.png?psid=1" class="fancybox" data-fancybox-group="group"><img src="https://cuz9cq.dm2301.livefilestore.com/y2pKOwVey190AtvyBmJIu95mxDSmtuSby6SSMQkWpkF_EXExoOeC22pztFtzLy5cmu7Z2jMvm434CjIdpTmkCfAu3FEwYsrUasAX5Xwp64u5sk/xrandr1.png?psid=1" alt="xrandr" width="343" height="222" /></a></p>
<p>2. 然后通过 <code>cvt</code> 命令获取需要的显示模式编辑行：</p>
<p><a href="https://cuz9cq.dm2301.livefilestore.com/y2p4IlYPIg5VjtQKw-MePh8VfvNhBDtZGRnl5EPFD0cqjGsvGUa4m1ocGzTsWYsBbn73azzQcSvrEalk16gkxi8xpbf2Uh6lJ-OfuhUpYfT0-8/cvt.png?psid=1" class="fancybox" data-fancybox-group="group"><img src="https://cuz9cq.dm2301.livefilestore.com/y2p4IlYPIg5VjtQKw-MePh8VfvNhBDtZGRnl5EPFD0cqjGsvGUa4m1ocGzTsWYsBbn73azzQcSvrEalk16gkxi8xpbf2Uh6lJ-OfuhUpYfT0-8/cvt.png?psid=1" alt="cvt" width="615" height="112" /></a></p>
<p>3. 新建显示模式 <code>xrandr --newmode "1368x768_60.00" 85.25 1368 1440 1576 1784 768 771 781 798 -hsync +vsync</code></p>
<p>4. 添加显示模式 <code>xrandr --addmode VBOX0 "1368x768_60.00"</code></p>
<p>5. 应用显示模式 <code>xrandr --output VBOX0 --mode "1368x768_60.00"</code></p>