title: 88250 的开源 T-shirts
date: '2009-01-26 08:31:00'
updated: '2009-01-26 08:31:00'
tags: [Life in Programming]
permalink: /articles/2009/01/25/1232901060000.html
---
<h1>88250 的开源 T-shirts</h1>
<p>2008 年参与了一些开源社区，衣服拿出来晒一下。。。。<br /><br /><strong><em>1. Duke， <a id="vs6:" title="NetBeans 中国翻译社区" href="http://zh-cn.netbeans.org/community/index.html">NetBeans 中国翻译社区</a></em></strong><br /></p>
<div id="nhvc" style="padding: 1em 0pt; text-align: left;"><img style="width: 838px; height: 625px;" src="http://docs.google.com/File?id=ddrm6c35_153kcwc3qfq_b" alt="" /></div>
<div id="rao0" style="padding: 1em 0pt; text-align: left;"><img style="width: 828px; height: 624px;" src="http://docs.google.com/File?id=ddrm6c35_154g2m6frcm_b" alt="" /></div>
<p><em><strong>2. <a id="kz9s" title="Unix-Center.Net" href="http://www.unix-center.net/">Unix-Center.Net</a> 社区</strong></em></p>
<div id="j2nd" style="padding: 1em 0pt; text-align: left;"><img style="width: 836px; height: 624px;" src="http://docs.google.com/File?id=ddrm6c35_155dbd4dxd7_b" alt="" /></div>
<p><img style="width: 833px; height: 622px;" src="http://docs.google.com/File?id=ddrm6c35_156cqqs4kfx_b" alt="" /><br /><br /><em><strong>3. <a id="p55s" title="Ubuntu" href="http://www.ubuntu.com/">Ubuntu</a> （偶花钱买的 - -）</strong></em></p>
<div id="yrqq" style="padding: 1em 0pt; text-align: left;"><img style="width: 835px; height: 625px;" src="http://docs.google.com/File?id=ddrm6c35_157g97z8zw3_b" alt="" /></div>
<p><em><strong>4. Spring 2.5 文档翻译，<a id="n-cn" title="满江红社区" href="http://wiki.redsaga.com/confluence/display/RSTEAM/Home">满江红社区</a></strong></em></p>
<div id="veev" style="padding: 1em 0pt; text-align: left;"><img style="width: 832px; height: 621px;" src="http://docs.google.com/File?id=ddrm6c35_158db5s59kc_b" alt="" /></div>
<p><em><strong>5. <a id="uuel" title="NetBeans 全球翻译团队" href="http://www.netbeans.org/">NetBeans 全球翻译团队</a></strong></em></p>
<div id="vv6o" style="padding: 1em 0pt; text-align: left;"><img style="width: 834px; height: 626px;" src="http://docs.google.com/File?id=ddrm6c35_159gfpgb8cf_b" alt="" /></div>
<div id="n:vy" style="padding: 1em 0pt; text-align: left;"><img style="width: 834px; height: 623px;" src="http://docs.google.com/File?id=ddrm6c35_160cc25h7g9_b" alt="" /></div>
<p><em><strong>6. <a id="j1r." title="NetBeans 10 周年" href="http://www.netbeans.org/">NetBeans 10 周年</a> （限量版）</strong></em></p>
<div id="bsxf" style="padding: 1em 0pt; text-align: left;"><img style="width: 834px; height: 623px;" src="http://docs.google.com/File?id=ddrm6c35_161cx86m4mt_b" alt="" /></div>
<div id="tvyw" style="padding: 1em 0pt; text-align: left;"><img style="width: 831px; height: 623px;" src="http://docs.google.com/File?id=ddrm6c35_162c7286gdj_b" alt="" /></div>
<p>好了，Show 完了，2008 年的收获 :-)</p>