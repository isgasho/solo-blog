title: Java 7 的新特性一览表
date: '2011-07-28 17:40:35'
updated: '2011-07-28 17:40:35'
tags: [J2SE/JavaSE, JDK 7, Java]
permalink: /java-7-technologies.html
---
<p>官方说是 7月28日 正式发布 Java 7 ，正常的话我们应该在 7月29日 看到这个版本。很快了，就两天时间。</p>
<p>发布之前让我们先来看看 Java 7 都有什么新特性吧。</p>
<p>Java 7 的技术：</p>
<table class="table" border="1" cellspacing="0" cellpadding="0" width="80%">
<tbody>
<tr>
<td class="tdhead" colspan="4"><br /></td>
<td class="tdhead">
<table class="table" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
<tbody>
<tr>
<td><br /></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdleftside" title="Java SE Development Kit" rowspan="8"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#jre-jdk">JDK</a></td>
<td style="border-width: 0px 0px 0px 0px;" rowspan="9" width="3">&nbsp;</td>
<td class="tdhead" title="Java programming language" colspan="2"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/language/index.html"><strong>Java Language</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1" cellpadding="2" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" bgcolor="#BDBEC0"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/language/index.html">Java Language</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdhead" title="Tools and Tool APIs" colspan="2">` <a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html"><strong>Tools &amp;<br /> Tool APIs</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1" cellpadding="2" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" title="Java runtime launcher" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/windows/java.html">java</a></td>
<td class="tdbody" title="Java compiler" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/javac/index.html">javac</a></td>
<td class="tdbody" title="Java documentation generator" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/javadoc/index.html">javadoc</a></td>
<td class="tdbody" title="Java archive tool" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jar/index.html">jar</a></td>
<td class="tdbody" title="Java class file disassembler" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/windows/javap.html">javap</a></td>
<td class="tdbody" title="Java Platform Debugger Architecture" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jpda/index.html">JPDA</a></td>
<td class="tdbody" title="jconsole" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#jconsole">JConsole</a></td>
<td class="tdbody" title="Java VisualVM" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/visualvm/index.html">Java VisualVM</a></td>
<td class="tdbody" title="Java DB" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javadb/index_jdk7.html">Java DB</a></td>
</tr>
<tr>
<td class="tdbody" title="Security tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#security">Security</a></td>
<td class="tdbody" title="Internationalization tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#intl">Int'l</a></td>
<td class="tdbody" title="Remote Method Invocation tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#rmi">RMI</a></td>
<td class="tdbody" title="Interface Definition Language and RMI-IIOP tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#idl">IDL</a></td>
<td class="tdbody" title="Deployment, Plug-in and Web Start tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#deployment">Deploy</a></td>
<td class="tdbody" title="Monitoring and Management tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#monitor">Monitoring</a></td>
<td class="tdbody" title="Troubleshooting tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#troubleshoot">Troubleshoot</a></td>
<td class="tdbody" title="Scripting tools" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/tools/index.html#scripting">Scripting</a></td>
<td class="tdbody" title="Java Virtual Machine Tool Interface" colspan="2" bgcolor="#A3B8CB"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jvmti/index.html">JVM TI</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdleftside" title="Java Runtime Environment" rowspan="6"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#jre-jdk">JRE</a></td>
<td class="tdhead" title="Deployment Technologies"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/jweb/index.html"><strong>RIAs</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1" cellpadding="2" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" style="padding: 6px 0px;" title="Deployment of Java platform, control panel, applications and applets" bgcolor="#ED9B4F"><br /></td>
<td class="tdbody" title="Java Web Start" bgcolor="#ED9B4F"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/javaws/index.html">Java Web Start</a></td>
<td class="tdbody" title="Java Plug-In for browsers" bgcolor="#ED9B4F"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jweb/applet/applet_dev_guide.html">Applet / Java Plug-in</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdhead" title="User Interface programming"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#userinterface"><strong>User Interface<br /> Toolkits</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1" cellpadding="2" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" title="Abstract Window Toolkit" colspan="3" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/awt/index.html">AWT</a></td>
<td class="tdbody" title="Graphical user interface components" colspan="4" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/swing/index.html"> Swing</a></td>
<td class="tdbody" title="2D graphics, text and images" colspan="3" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/2d/index.html">Java 2D</a></td>
</tr>
<tr>
<td class="tdbody" title="Assistive technologies for user interfaces" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/access/index.html">Accessibility</a></td>
<td class="tdbody" title="Drag and drop data transfer" colspan="2" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/dragndrop/index.html"> Drag n Drop</a></td>
<td class="tdbody" title="Input Method Framework" colspan="2" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/imf/index.html"> Input Methods</a></td>
<td class="tdbody" title="Image input/output API" colspan="2" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/imageio/index.html">Image I/O</a></td>
<td class="tdbody" title="Print service API" colspan="2" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jps/index.html">Print Service</a></td>
<td class="tdbody" title="MIDI API" bgcolor="#E76F00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/sound/index.html"> Sound</a></td>
</tr>
</tbody>
</table>
</td>
<td style="border-width: 0px 0px 0px 0px;" rowspan="9" width="3">&nbsp;</td>
<td class="tdrightside" style="border-width: 2px 2px 2px 0px;" title="Java SE API. See API Documentation section for more links." rowspan="4"><a class="atext" href="http://download.oracle.com/javase/7/docs/api/index.html">Java SE<br /> API</a></td>
</tr>
<tr>
<td class="tdhead" title="Integration libraries"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#integration"><strong>Integration<br /> Libraries</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1px" cellpadding="2px" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" style="padding: 6px 0px;" title="CORBA Interface Definition Language API" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/idl/index.html">IDL</a></td>
<td class="tdbody" title="Java Database Connectivity API" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jdbc/index.html">JDBC</a></td>
<td class="tdbody" title="Java Naming and Directory Interface API" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jndi/index.html">JNDI</a></td>
<td class="tdbody" title="Remote Method Invocation API" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/rmi/index.html">RMI</a></td>
<td class="tdbody" title="RMI interfaces over IIOP" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/rmi-iiop/index.html">RMI-IIOP</a></td>
<td class="tdbody" title="Scripting for the Java Platform" colspan="2" bgcolor="#B2BC00"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/scripting/index.html">Scripting</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdhead" title="Base libraries other than java.lang and java.util"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#otherbase"><strong>Other Base<br /> Libraries</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1px" cellpadding="2px" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" title="Java Beans component API" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/beans/index.html">Beans</a></td>
<td class="tdbody" title="Internationalization of applications" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/intl/index.html">Int'l Support</a></td>
<td class="tdbody" title="Input/Output API" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/io/index.html"> Input/Output</a></td>
<td class="tdbody" title="Java Management Extensions" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jmx/index.html">JMX</a></td>
<td class="tdbody" title="Java Native Interface" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jni/index.html">JNI</a></td>
<td class="tdbody" title="Math classes" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/math/index.html">Math</a></td>
</tr>
<tr>
<td class="tdbody" title="Networking API" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/net/index.html">Networking</a></td>
<td class="tdbody" title="Endorsed Standards Override Mechanism" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/standards/index.html">Override Mechanism</a></td>
<td class="tdbody" title="Security API" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/security/index.html">Security</a></td>
<td class="tdbody" title="Object Serialization" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/serialization/index.html">Serialization</a></td>
<td class="tdbody" title="Package extension mechanism" colspan="2" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/extensions/index.html">Extension Mechanism</a></td>
<td class="tdbody" title="Java API for XML Processing" bgcolor="#C69200"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/xml/index.html">XML JAXP</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdhead" title="java.lang and java.util libraries"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/index.html#langutil"><strong>lang and util<br /> Base Libraries</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" cellspacing="1px" cellpadding="2px" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" title="java.lang and java.util packages" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/lang/index.html">lang and util</a></td>
<td class="tdbody" title="Collections framework" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/collections/index.html">Collections</a></td>
<td class="tdbody" title="Concurrency utilities" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/concurrency/index.html">Concurrency Utilities</a></td>
<td class="tdbody" title="Java archive file format" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/jar/index.html"> JAR</a></td>
<td class="tdbody" title="Logging API" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/logging/index.html">Logging</a></td>
<td class="tdbody" title="JVM Monitoring and Management" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/management/index.html">Management</a></td>
</tr>
<tr>
<td class="tdbody" title="Preferences API" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/preferences/index.html">Preferences API</a></td>
<td class="tdbody" title="Reference Objects API" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/api/java/lang/ref/package-summary.html">Ref Objects</a></td>
<td class="tdbody" title="Reflection API" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/reflection/index.html">Reflection</a></td>
<td class="tdbody" title="Regular expressions" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/api/java/util/regex/package-summary.html">Regular Expressions</a></td>
<td class="tdbody" title="Package version identification" colspan="2" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/versioning/index.html">Versioning</a></td>
<td class="tdbody" title="Zip and gzip file formats" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/api/java/util/zip/package-summary.html">Zip</a></td>
<td class="tdbody" title="Instrumentation" bgcolor="#FFC726"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/instrumentation/index.html">Instrumentation</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td class="tdhead" title="Java Virtual Machine" width="117"><a class="ahead" href="http://download.oracle.com/javase/7/docs/technotes/guides/vm/index.html"><strong>Java Virtual<br /> Machine</strong></a></td>
<td style="border-width: 0px 0px 0px 0px;">
<table class="table" border="0" cellspacing="1px" cellpadding="2px" width="100%" bgcolor="#EEEEEE">
<tbody>
<tr>
<td class="tdbody" style="padding: 6px 0px;" title="Client and Server virtual machine" colspan="10" bgcolor="#C5D5A9"><a class="atext" href="http://download.oracle.com/javase/7/docs/technotes/guides/vm/index.html">Java HotSpot Client and Server VM</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<p><a href="http://download.oracle.com/javase/7/docs/technotes/guides/desc_jdk_structure.html">Description of Java Conceptual Diagram</a></p>
<p>新特性一览表：</p>
<p style="text-indent: 0em;"><strong>Swing</strong></p>
<ul>
<li>新增 <a href="http://download.oracle.com/javase/7/docs/api/javax/swing/JLayer.html"><code>JLayer</code></a> 类，是一个灵活而且功能强大的Swing组件修饰器，使用方法：<a href="http://download.oracle.com/javase/tutorial/uiswing/misc/jlayer.html">How to Decorate Components with JLayer</a>.</li>
<li><a href="http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/nimbus.html">Nimbus Look and Feel</a> 外观从 <code>com.sun.java.swing</code> 包移到 <code>javax.swing</code> 包中，详情：<a href="http://download.oracle.com/javase/7/docs/api/javax/swing/plaf/nimbus/package-summary.html"><code>javax.swing.plaf.nimbus</code></a></li>
<li><a href="http://java.sun.com/developer/technicalArticles/GUI/mixing_components/index.html">更轻松的重量级和轻量级组件的混合</a></li>
<li>支持透明窗体以及非矩形窗体的图形界面，请看 <a href="http://download.oracle.com/javase/tutorial/uiswing/misc/trans_shaped_windows.html">How to Create Translucent and Shaped Windows</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/api/javax/swing/JColorChooser.html"><code>JColorChooser</code></a> 类新增 HSV tab.</li>
</ul>
<p style="text-indent: 0em;"><strong>网络</strong></p>
<ul>
<li><code>新增 </code><a href="http://download.oracle.com/javase/7/docs/api/java/net/URLClassLoader.html#close%28%29"><code>URLClassLoader.close</code></a> 方法，请看 <a href="http://download.oracle.com/javase/7/docs/technotes/guides/net/ClassLoader.html">Closing a URLClassLoader</a>.</li>
<li>支持 Sockets Direct Protocol (SDP) 提供高性能网络连接，详情请看 <a href="http://download.oracle.com/javase/tutorial/sdp/sockets/index.html">Understanding the Sockets Direct Protocol</a>.</li>
</ul>
<p style="text-indent: 0em;"><strong>集合</strong></p>
<ul>
<li><code>新增 </code><a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/TransferQueue.html"><code>TransferQueue</code></a> 接口，是 <a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/BlockingQueue.html"><code>BlockingQueue</code></a> 的改进版，实现类为 <a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/LinkedTransferQueue.html"><code>LinkedTransferQueue</code></a></li>
</ul>
<p style="text-indent: 0em;"><strong>RIA/发布</strong></p>
<ul>
<li>拖拽的小程序使用一个默认或者定制的标题进行修饰，详情：<a href="http://download.oracle.com/javase/tutorial/deployment/applet/draggableApplet.html#decoration">Requesting and Customizing Applet Decoration in Draggable Applets</a>.</li>
<li>JNLP 文件做了如下方面的增强，详情请看 <a href="http://download.oracle.com/javase/7/docs/technotes/guides/javaws/developersguide/syntax.html">JNLP File Syntax</a>:           
<ul>
<li>The <code>os</code> attribute in the <code>information</code> and <code>resources</code> elements can now contain specific versions of Windows, such as Windows Vista or Windows 7.</li>
<li>Applications can use the <code>install</code> attribute in the <code>shortcut</code> element to specify their their desire to be installed. Installed   applications are not removed when the Java Web Start cache is cleared,   but can be explicitly removed using the Java Control Panel.</li>
<li>Java Web Start applications can be deployed without specifying the <code>codebase</code> attribute; see <a href="http://download.oracle.com/javase/tutorial/deployment/deploymentInDepth/deployingWithoutCodebase.html">Deploying Without Codebase</a></li>
</ul>
</li>
<li>可直接在 HTML 中嵌入 JNLP 文件：<a href="http://download.oracle.com/javase/tutorial/deployment/deploymentInDepth/embeddingJNLPFileInWebPage.html">Embedding JNLP File in Applet Tag</a>.</li>
<li>可在 JavaScript 代码中检查 Applet 是否已经加载完成：<a href="http://download.oracle.com/javase/tutorial/deployment/applet/appletStatus.html">Handling Initialization Status With Event Handlers</a>.</li>
<li>可在 Applet 从快捷方式启动或者拖出浏览器时对窗口样式和标题进行控制：<a href="http://download.oracle.com/javase/tutorial/deployment/applet/draggableApplet.html#decoration">Requesting and Customizing Applet Decoration</a> in <a href="http://download.oracle.com/javase/tutorial/deployment/applet/draggableApplet.html">Developing Draggable Applets</a>.</li>
</ul>
<p style="text-indent: 0em;"><strong>XML</strong></p>
<ul>
<li>包含 <a href="http://jaxp.java.net/">Java API for XML Processing</a> (JAXP) 1.4.5, 支持 <a href="http://jaxb.java.net/">Java Architecture for XML Binding</a> (JAXB) 2.2.3, 和 <a href="http://jax-ws.java.net/">Java API for XML Web Services</a> (JAX-WS) 2.2.4.</li>
</ul>
<p style="text-indent: 0em;"><strong>java.lang 包</strong></p>
<ul>
<li>消除了在多线程环境下的非层次话类加载时导致的潜在死锁，详情：<a href="http://download.oracle.com/javase/7/docs/technotes/guides/lang/cl-mt.html">Multithreaded Custom Class Loaders in Java SE 7</a>.</li>
</ul>
<p style="text-indent: 0em;"><strong>Java 虚拟机</strong></p>
<ul>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/vm/multiple-language-support.html">支持非 Java 语言</a>:  Java SE 7 引入一个新的 JVM 指令用于简化实现动态类型编程语言</li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/vm/G1.html">Garbage-First Collector</a> 是一个服务器端的垃圾收集器用于替换 Concurrent Mark-Sweep Collector (CMS).</li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/vm/performance-enhancements-7.html">提升了 Java HotSpot 虚拟机的性能</a></li>
</ul>
<p style="text-indent: 0em;"><strong>Java I/O</strong></p>
<p><a href="http://download.oracle.com/javase/7/docs/api/java/nio/file/package-summary.html"><code>java.nio.file</code></a> 包以及相关的包 <a href="http://download.oracle.com/javase/7/docs/api/java/nio/file/attribute/package-summary.html"><code>java.nio.file.attribute</code></a> 提供对文件 I/O 以及访问文件系统的全面支持，请看 <a href="http://download.oracle.com/javase/tutorial/essential/io/fileio.html"> File I/O (featuring NIO.2)</a>.</p>
<ul>
<li>目录 <code><em>&lt;Java home&gt;</em>/sample/nio/chatserver/</code> 包含使用 java.nio.file 包的演示程序</li>
<li>目录 <code><em>&lt;Java home&gt;</em>/demo/nio/zipfs/</code> 包含 NIO.2 NFS 文件系统的演示程序</li>
</ul>
<p style="text-indent: 0em;"><strong>安全性</strong></p>
<ul>
<li>新的内置对多个基于 ECC 算法(ECDSA/ECDH)的支持，详情请看：<a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/p11guide.html#ALG">Sun PKCS#11 Provider's Supported Algorithms</a> in <a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/p11guide.html">Java PKCS#11 Reference Guide</a>.</li>
<li>禁用了一些弱加密算法，详情请看 <a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/certpath/CertPathProgGuide.html#AppD">Appendix D: Disabling Cryptographic Algorithms</a> in <a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/certpath/CertPathProgGuide.html">Java PKI Programmer's Guide</a> and <a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/jsse/JSSERefGuide.html#DisabledAlgorithms">Disabled Cryptographic Algorithms</a> in <a href="http://download.oracle.com/javase/7/docs/technotes/guides/security/jsse/JSSERefGuide.html">Java Secure Socket Extension (JSSE) Reference Guide</a>.</li>
<li>Java 安全套接字扩展中对 SSL/TLS 的增强</li>
</ul>
<p style="text-indent: 0em;"><strong>并发</strong></p>
<ul>
<li>fork/join 框架，基于 <a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/ForkJoinPool.html"><code>ForkJoinPool</code></a> 类，是 <a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/Executor.html"><code>Executor</code></a> 接口的实现，设计它用来进行高效的运行大量任务；使用 work-stealing 技术用来保证大量的 worker 线程工作，特别适合多处理器环境，详情请看 <a href="http://download.oracle.com/javase/tutorial/essential/concurrency/forkjoin.html">Fork/Join</a> <br /> 
<ul>
<li>目录<code><em>&lt;Java home&gt;</em>/sample/forkjoin/</code> 包含了 fork/join 框架的演示程序</li>
</ul>
</li>
<li><a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/ThreadLocalRandom.html"><code>ThreadLocalRandom</code></a> 类class 消除了使用伪随机码线程的竞争，请看 <a href="http://download.oracle.com/javase/tutorial/essential/concurrency/threadlocalrandom.html">Concurrent Random Numbers</a>.</li>
<li><a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/Phaser.html"><code>Phaser</code></a> 类是一个新的同步的屏障，与 <a href="http://download.oracle.com/javase/7/docs/api/java/util/concurrent/CyclicBarrier.html"><code>CyclicBarrier</code></a> 类似.</li>
</ul>
<p style="text-indent: 0em;"><strong>Java 2D</strong></p>
<ul>
<li>一个新的基于 XRender 的 Java 2D 渲染管道支持现在的 X11 桌面，改善了图形性能，请看&nbsp;<a href="http://download.oracle.com/javase/7/docs/technotes/guides/2d/flags.html#xrender">System Properties for Java 2D Technology</a> 中的 <code>xrender</code> .</li>
<li>JDK 可枚举并显示出已安装的 OpenType/CFF 字体，通过 <a href="http://download.oracle.com/javase/7/docs/api/java/awt/GraphicsEnvironment.html#getAvailableFontFamilyNames%28%29"> <code>GraphicsEnvironment.getAvailableFontFamilyNames</code></a> 方法 See <a href="http://download.oracle.com/javase/tutorial/2d/text/fonts.html">Selecting a Font</a>.</li>
<li><a href="http://download.oracle.com/javase/7/docs/api/java/awt/font/TextLayout.html"><code>TextLayout</code></a> 类支持西藏语脚本</li>
<li><code>libfontconfig</code>, 是一个字体配置 api ，see <a href="http://www.fontconfig.org/">Fontconfig</a>.</li>
</ul>
<p style="text-indent: 0em;"><strong>国际化</strong></p>
<ul>
<li>支持 <a href="http://www.unicode.org/versions/Unicode6.0.0">Unicode 6.0.0</a>&nbsp;      
<ul>
<li>目录 <code><em>&lt;Java home&gt;</em>/demo/jfc/Font2DTest/</code> 包含 Unicode 6.0 的演示程序</li>
<li>Java SE 7 可容纳在 ISO 4217 中新的货币，详情请看 <a href="http://download.oracle.com/javase/7/docs/api/java/util/Currency.html"><code>Currency</code></a> 类.</li>
</ul>
</li>
</ul>
<p style="text-indent: 0em;"><strong>Java 编程语言特性</strong></p>
<ul>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/binary-literals.html">二进制数字表达方式</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/underscores-literals.html">使用下划线对数字进行分隔表达，例如 1_322_222</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/strings-switch.html">switch 语句支持字符串变量</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/type-inference-generic-instance-creation.html">泛型实例创建的类型推断</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/non-reifiable-varargs.html">使用可变参数时，提升编译器的警告和错误信息</a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/try-with-resources.html">try-with-resources 语句<br /></a></li>
<li><a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/catch-multiple.html">同时捕获多个异常处理</a></li>
</ul>
<p style="text-indent: 0em;"><strong>JDBC 4.1</strong></p>
<ul>
<li>支持使用 <a href="http://download.oracle.com/javase/7/docs/technotes/guides/language/try-with-resources.html"><code>try</code>-with-resources</a> 语句进行自动的资源释放，包括连接、语句和结果集</li>
<li>支持 RowSet 1.1</li>
</ul>
<p>&nbsp;</p>
<p>明细：http://download.oracle.com/javase/7/docs/</p>
<p>转自：http://www.oschina.net/news/20119/new-features-of-java-7</p>