title: EverBox（同步网盘）邀请
date: '2010-12-31 18:09:03'
updated: '2010-12-31 18:09:03'
tags: [Fiddlededee, EverBox]
permalink: /everbox-invite.html
---
<p><img style="margin-left: 10px; margin-right: 10px; float: left;" src="http://everbox.com/images/logo.jpg" alt="EverBox Logo" width="215" height="66" />EverBox 是一款由盛大创新院推出的网盘产品，提供数据存储和同步服务。EverBox 提供了 10GB 超大免费存储空间，支持文件同步、文件分享、在线浏览照片、在线听音乐等功能，并支持数据同步客户端。<strong>需要邀请的朋友可以改我留言 :-)</strong></p>
<p>&nbsp;</p>
<p>主要功能：</p>
<p><strong>支持数据同步客户端</strong>：安装  EverBox后，您所需的文件都将自动同步到设备上，可以随时、随地的使用手边的任意一款设备访问文件了。目前提供了 Windows  客户端程序，支持 Windows XP，Windows Vista 和 Windows 7。在以后的版本中，EverBox  将会陆续推出其他客户端程序，如： Android，iPhone，iPad，Mac，Linux 等。</p>
<p><strong>容灾备份服务</strong>：EverBox 会自动的、实时的备份文件数据到 EverBox 安全服务器，因此，当您本地的设备坏损或丢失时，不必担心由于数据丢失造成的损失，恢复数据易如反掌！</p>
<p><strong>在线音乐播放</strong>：EverBox 支持在线音乐播放功能，几乎支持所有常用的音频格式，使用简单、便捷，无需操作即可连续播放 EverBox 当前目录中的歌曲，很适于一边使用电脑一边听歌时使用。</p>
<p><strong>在线浏览图片</strong>：EverBox 支持在线浏览图片功能，几乎支持所有常用的图片格式，操作简单、便捷，并支持自动播放 EverBox 当前目录中的图片文件。</p>
<h3>EverBox 功能特性</h3>
<ol>
<li>
<p class="q">10GB 超大免费空间</p>
<div class="a">
<p>成功注册 EverBox 即可获得 2GB 免费空间，完成指定任务可升级空间到 10GB！EverBox 在随后的版本中将会有更多的奖励措施，赠送活跃用户更多空间，敬请期待！</p>
<p style="text-align: center;"><img src="http://www.everbox.com/images/features/feature_pic_1.jpg" alt="" /></p>
</div>
</li>
<li>
<p class="q">支持数据同步客户端</p>
<div class="a">
<p>您是不是经常遇到以下的情况？&ldquo;我喜欢在外出时用 iPhone 听歌，但是我需要从 PC 下载歌曲再用数据线将 MP3 导到  iPhone&rdquo;；&ldquo;我经常出差，但是程序和文件都在笨重的 PC 上，而我只带着笔记本&rdquo;；&ldquo;我到 XX 会议做演讲，但是保存 PPT 的 U  盘坏掉了&rdquo;。</p>
<p>现在有了 EverBox，这些问题将迎刃而解！只需安装 EverBox，您所需的文件都将自动同步到设备上，您就可以随时、随地的使用手边的任意一款设备访问文件了。当然，使用浏览器一样可以访问到您需要的文件。</p>
<p style="text-align: center;"><img src="http://www.everbox.com/images/features/feature_pic_2.jpg" alt="" /></p>
</div>
</li>
<li>
<p class="q">容灾备份服务</p>
<div class="a">
<p>硬盘损坏？数据无法访问？笔记本电脑被盗？完了，重要的数据丢失了！</p>
<p>不用担心，有了 EverBox，这一切都不会再是问题。EverBox 会自动的、实时的备份文件数据到 EverBox 安全服务器，因此，当您本地的设备坏损或丢失时，不必担心由于数据丢失造成的损失，恢复数据易如反掌！</p>
<p style="text-align: center;"><img src="http://www.everbox.com/images/features/feature_pic_3.jpg" alt="" /></p>
</div>
</li>
<li>
<p class="q">在线音乐播放</p>
<div class="a">
<p>EverBox 支持在线音乐播放功能，几乎支持所有常用的音频格式，使用简单、便捷，无需操作即可连续播放 EverBox 当前目录中的歌曲，很适于一边使用电脑一边听歌时使用。</p>
<p style="text-align: center;"><img src="http://www.everbox.com/images/features/feature_pic_4.jpg" alt="" /></p>
</div>
</li>
<li>
<p class="q">在线浏览图片</p>
<div class="a">
<p>EverBox 支持在线浏览图片功能，几乎支持所有常用的图片格式，操作简单、便捷，并支持自动播放 EverBox 当前目录中的图片文件。</p>
<p style="text-align: center;"><img src="http://www.everbox.com/images/features/feature_pic_5.jpg" alt="" /></p>
<p style="text-align: center;">&nbsp;</p>
</div>
</li>
</ol>