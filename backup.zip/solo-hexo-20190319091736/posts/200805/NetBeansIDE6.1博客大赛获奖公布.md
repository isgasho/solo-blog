title: NetBeans IDE 6.1 博客大赛获奖公布！
date: '2008-05-16 06:13:00'
updated: '2008-05-16 06:13:00'
tags: [NetBeans]
permalink: /articles/2008/05/15/1210860780000.html
---
<table cellspacing="0" cellpadding="0" border="0" style="text-align: left; width: 100%;">
    <tbody>
        <tr>
            <td>
            <h4>The NetBeans Blogging Contest has come to a close.</h4>
            We would like to thank everyone who participated! We had nearly <a href="http://www.netbeans.org/competition/blog-contest-posts.html">300 entries</a>. The top 100 entrants will receive a NetBeans T-shirt. The top 10 entrants will receive a $500 American Express gift certificate. All winners will be contacted via email in the next two weeks (by May 23) to confirm mailing address.        </td>
            <td style="vertical-align: top;">
            <h1><img align="right" src="http://www.netbeans.org/images/competition/61blog-contest-logo-trans.gif" alt="NetBeans Blogging Contest" style="width: 330px; height: 183px;" /><br />       </h1>
            </td>
        </tr>
    </tbody>
</table>
<h2>Winners of $500 American Express Gift Certificates</h2>
<table cellspacing="10">
    <tbody>
        <tr>
            <td class="tblheader">Name</td>
            <td class="tblheader">Language</td>
            <td class="tblheader">Blog Entry</td>
        </tr>
        <tr>
            <td class="tbltd0">Matthew Nuzum<br /></td>
            <td class="tbltd0">English</td>
            <td class="tbltd0"><a href="http://www.bearfruit.org/blog/2008/04/01/netbeans-6-1-spanks-eclipse-and-challenges-visual-studio">Netbeans 6.1 spanks Eclipse and challenges Visual Studio</a></td>
        </tr>
        <tr>
            <td class="tbltd1">Patrick Julien<br /></td>
            <td class="tbltd1">English</td>
            <td class="tbltd1"><a href="http://codepimpsdotorg.blogspot.com/2008/03/netbeans-61-best-just-got-better.html">NetBeans 6.1: The Best just got Better</a></td>
        </tr>
        <tr>
            <td class="tbltd0" style="background-color: rgb(255, 153, 204);">Ding Liang<br /></td>
            <td class="tbltd0" style="color: rgb(255, 0, 0); background-color: rgb(255, 153, 204);">Chinese</td>
            <td class="tbltd0" style="color: rgb(255, 0, 0); background-color: rgb(255, 153, 204);"><a href="http://blog.csdn.net/DL88250">About NetBeans</a></td>
        </tr>
        <tr>
            <td class="tbltd1">Diego Silva<br /></td>
            <td class="tbltd1">Spanish</td>
            <td class="tbltd1"><a href="http://diesil-java.blogspot.com/2008/04/javascript-en-netbeans-61.html">JavaScript en NetBeans 6.1</a></td>
        </tr>
        <tr>
            <td class="tbltd0">Wagner Roberto dos Santos<br /></td>
            <td class="tbltd0">Portuguese</td>
            <td class="tbltd0"><a href="http://netfeijao.blogspot.com/search/label/NetBeans">O que podemos esperar do NetBeans 6.1 ?</a></td>
        </tr>
        <tr>
            <td class="tbltd1">Pat Coleman</td>
            <td class="tbltd1">English</td>
            <td class="tbltd1"><a href="http://padsterprogramming.blogspot.com/2008/04/beans.html">Can NetBeans create a code-less P2P app?</a></td>
        </tr>
        <tr>
            <td class="tbltd0">James Eliyezar<br /></td>
            <td class="tbltd0">English</td>
            <td class="tbltd0"><a href="http://jamesselvakumar.wordpress.com/2008/04/07/subversion-and-netbeans-a-quick-start-guide/">Subversion and NetBeans - A quick start guide</a></td>
        </tr>
        <tr>
            <td class="tbltd1">Junji Takakura</td>
            <td class="tbltd1">Japanese</td>
            <td class="tbltd1"><a href="http://snakemanshow.blogspot.com/2008/04/netbeans-61-rc-php.html">NetBeans 6.1 RC to use PHP</a></td>
        </tr>
        <tr>
            <td class="tbltd0">Jacek Laskowski<br /></td>
            <td class="tbltd0">Polish</td>
            <td class="tbltd0"><a href="http://jlaskowski.blogspot.com/2008/04/nowoci-netbeans-ide-61-spring-framework.html">NetBeans IDE 6.1 - Spring Framework Support</a></td>
        </tr>
        <tr>
            <td class="tbltd1">Joshua van Aalst</td>
            <td class="tbltd1">English</td>
            <td class="tbltd1"><a href="http://joshuavanaalst.com/blog/2008/04/14/netbeans-61-a-delight-to-use/">NetBeans 6.1 A Delight To Use</a></td>
        </tr>
    </tbody>
</table>
<h4>We would like the judges who diligently read the blog entries: </h4>
Alexis Moussine-Pouchkine, Andrii Rodionov, Dima Lipin, Felipe Vieira Silva, Janice Campbell, Kenji Tachibana, Ludo Champenois, Magda Goldyn, Maxym Mykhalchuk, Tetsu Tanimoto, and Will Zhang. <br />
<h3>Contest Information</h3>
<a href="http://www.netbeans.org/competition/blog-contest-rules.html">Contest Rules</a><br /> <a href="http://www.netbeans.org/competition/blog-contest-faqs.html">Frequently Asked Questions</a><br /> <a href="http://www.netbeans.org/competition/blog-contest-posts.html">See All (non-Spam) Entries</a>