title: 朴素贝叶斯中文文本分类器的研究与实现（2）[88250、zy、Sindy原创]
date: '2008-03-28 14:14:00'
updated: '2008-03-28 14:14:00'
tags: [Text Categorization, Mathematics]
permalink: /articles/2008/03/27/1206656040000.html
---
<p><font face="Microsoft YaHei">转载请保留作者信息：</font></p>
<p><font face="Microsoft YaHei">作者：</font><font face="Microsoft YaHei">88250</font></p>
<p><font face="Microsoft YaHei">Blog</font><font face="Microsoft YaHei">：</font><font face="Microsoft YaHei"><a href="http://blog.csdn.net/DL88250"><font color="#2300dc">http:/blog.csdn.net/DL88250</font></a></font></p>
<p><font face="Microsoft YaHei">MSN &amp; E-mail &amp; QQ</font><font face="Microsoft YaHei">：</font><font face="Microsoft YaHei">DL88250@gmail.com</font></p>
<p><font face="Microsoft YaHei">作者：zy</font></p>
<p dragover="true"><font face="Microsoft YaHei">Blog：</font><a href="http://blog.csdn.net/zyofprogrammer"><font><font face="Microsoft YaHei"><font color="#2300dc">http:/blog.csdn.net/zyofprogrammer</font></font></font></a></p>
<p>作者：Sindy<span style="text-decoration: underline;"><br /></span></p>
<p>E-Mail：sindybanana@gmail.com</p>
<p><span style="text-decoration: underline;"></span></p>
<h2><font face="Microsoft YaHei">续<a href="http://blog.csdn.net/DL88250/archive/2008/02/20/2108164.aspx">上篇</a></font></h2>
上次说到了<font size="4">效率</font>的问题，现在已经解决了，还修复了不少的Bugs :-) 不过，查阅了一些文献后，发现了一个新的<font size="4"><span style="font-weight: bold;">理论问题</span>。<br /><br /></font>
<h1>理论问题</h1>
朴素贝叶斯文本分类模型分为两种：<br />
<ul>
    <li>  文档型  </li>
    <li>  词频型</li>
</ul>
都是使用下式计算进行分类：
<ul>  c<sub>NB</sub>=arg Max( P(c<sub>j</sub>) * &prod;<sub>1</sub><sup>C</sup>   P(x<sub>i</sub>|c<sub>j</sub>) ) <br />  其中，P(c<sub>j</sub>)为类别j的先验概率，P(x<sub>i</sub>|c<sub>j</sub>)为特征量  x<sub>i</sub>在类别c<sub>j</sub>的类条件概率</ul>
    上次的分类模型属于文档型的，正确率约为50%左右，理论上朴素贝叶斯分类的正确率可以达到80%以上。文档型的正确率很低，主要原因是<font size="3">训练库</font>的以分文本质量低下。目前我们已经在着手自己收集训练数据了，提高训练库的质量。<br /><br />
    <h3>先验概率计算</h3>
    先验概率计算方式有两种：
    <ul>
        <li>文档型</li>
        不考虑词频在各分类下的出现次数，仅考虑各分类下文档的数目。如下式计算：<br />  P(c<sub>j</sub>)=N(C=c<sub>j</sub>)<strong>/</strong>N <br />  其中，N(C=c<sub>j</sub>)表示类别c<sub>j</sub>中的训练文本数量；  N表示训练文本集总数量。
        <li>词频型</li>
        考虑单词在各分类文档中出现的频次，如下式计算：<br />  P(c<sub>j</sub>)=<sup>V</sup>&sum;<sub>k=1</sub>TF(X=x<sub>k</sub>,   C=c<sub>j</sub>)<strong>/</strong><sup>W</sup>&sum;<sub>m=1</sub><sup>V</sup>&sum;  <sub>k=1</sub>TF(X=x<sub>k</sub>, C=c<sub>m</sub>) <br />  其中，V表示特征词表中总单词（属性）数，TF(X=x<sub>i</sub>, C=c<sub>j</sub>)   表示属性x<sub>i</sub>在类c<sub>j</sub>中出现次数之和，W表示总类别数目。  </ul>
        <p>  <strong>注意</strong>：类条件概率的计算方式必须与先验概率的计算方式匹配，如果先验概率是用文档型  计算的，那么类条件概率也必须使用文档型计算方式，反之亦然。  </p>
        <br />
        <h3>类条件概率</h3>
        类条件概率的计算有两种方式：
        <ul>
            <li>文档型</li>
            不考虑单词在文档中的出现频次，仅考虑单词在文档中是否出现。 0表示未出现，1表示出现。  如下式计算：<br />  P(x<sub>j</sub>|c<sub>j</sub>)=( N(X=x<sub>i</sub>, C=c<sub>j  </sub>)+1 ) <strong>/</strong> ( N(C=c<sub>j</sub>)+V )  <br />  其中，N(X=x<sub>i</sub>, C=c<sub>j</sub>）表示类别c<sub>j</sub>中包含属性x<sub>  i</sub>的训练文本数量；N(C=c<sub>j</sub>)表示类别c<sub>j</sub>中的训练文本数量；V表示类别的总数。
            <li>词频型</li>
            考虑单词在文档中出现的频次，如下式计算：<br />  P(x<sub>j</sub>|c<sub>j</sub>)=( TF(X=x<sub>i</sub>, C=c<sub>j</sub>)+1)  <strong>/</strong> ( V+<sup>V</sup>&sum;<sub>k=1</sub>TF(X=x<sub>k</sub>, C=c<sub>j</sub>) ) <br />  其中，V表示特征词表中总单词（属性）数，TF(X=x<sub>i</sub>, C=c<sub>j</sub>)   表示属性x<sub>i</sub>在类c<sub>j</sub>中出现次数之和。  </ul>
            <p>  <strong>注意</strong>：  </p>
            <ul>
                <li>类条件概率的计算方式必须与先验概率的计算方式匹配，如果先验概率是用文档型  计算的，那么类条件概率也必须使用文档型计算方式，反之亦然  </li>
                <li>  为避免类条件概率结果为0，采用了拉普拉斯概率估计  </li>
            </ul>
            <h1>关于训练库的预处理<br /></h1>
            <p>为了提高分类的效率和准确率，必须对训练库进行预处理。主要预处理步骤如下：  </p>
            <ol>
                <li>读取某一分类下的所有训练文本</li>
                <li>对这些文本进行分词处理</li>
                <li>通过词性、词长过滤无用词</li>
                <li>将剩下的词作为这一分类的特征结果并保存成文本</li>
            </ol>
            目前实现的训练库预处理器主要是针对<font size="2" style="font-weight: bold;">词频分类模型</font>的。
            <h1>当前技术上的问题</h1>
            现在词频型的分类也做好了，不过有个<font size="2" style="font-weight: bold;">技术上的问题</font>还在解决，就是Java的中文分词组件。原来用的是极易中文分词组件，虽然分词效果还不错，但是没有词性标注。zy在研究中科院那个<font face="Microsoft YaHei"><a href="http://www.i3s.ac.cn/test.htm">ICTCLAS</a></font>分词组件，<font face="Microsoft YaHei"><a href="http://www.i3s.ac.cn/test.htm">ICTCLAS</a></font>3.0的试用申请发给作者3天了，没回信－ －!。1.0版本的在搞JNI调用，也很麻烦。。。。<br /><br />下一篇文章将对我们的朴素贝叶斯分类器进行<font size="4">评估</font>，请大家耐心等待 :-)