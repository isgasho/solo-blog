title: maven-jdocbook-plugin 使用
date: '2014-04-03 20:00:32'
updated: '2014-04-03 20:00:32'
tags: [maven-jdocbook-plugin, DocBook, Maven]
permalink: /maven-jdocbook-plugin
---
<p><a href="http://www.docbook.org/" target="_blank">DocBook</a> 是一个文档工具，Spring、Hibernate 等开源项目都是用它来编写、生成多格式文档的。这里主要介绍在 maven 环境中使用&nbsp;maven-jdocbook-plugin 插件来使用 DocBook。</p>
<p>&nbsp;</p>
<p>POM 中加入 jdocbook 插件：</p>
<pre class="brush: xml; gutter: false; toolbar: false; auto-links: false">&lt;plugin&gt;
    &lt;groupId&gt;org.jboss.maven.plugins&lt;/groupId&gt;
    &lt;artifactId&gt;maven-jdocbook-plugin&lt;/artifactId&gt;
    &lt;version&gt;2.3.8&lt;/version&gt;
    &lt;extensions&gt;true&lt;/extensions&gt;
    &lt;configuration&gt;
        &lt;masterTranslation&gt;zh-CN&lt;/masterTranslation&gt;
        &lt;formats&gt;
            &lt;format&gt;
                &lt;formatName&gt;html&lt;/formatName&gt;
            &lt;/format&gt;
        &lt;/formats&gt;
    &lt;/configuration&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.jboss&lt;/groupId&gt;
            &lt;artifactId&gt;jbossorg-docbook-xslt&lt;/artifactId&gt;
            &lt;version&gt;1.1.1&lt;/version&gt;
            &lt;/dependency&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.jboss&lt;/groupId&gt;
            &lt;artifactId&gt;jbossorg-jdocbook-style&lt;/artifactId&gt;
            &lt;version&gt;1.1.1&lt;/version&gt;
            &lt;type&gt;jdocbook-style&lt;/type&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;

    &lt;executions&gt;
        &lt;execution&gt;
            &lt;id&gt;SDK_Manual_zh_CN&lt;/id&gt;
            &lt;phase&gt;package&lt;/phase&gt;
            &lt;goals&gt;
                &lt;goal&gt;resources&lt;/goal&gt;
                &lt;goal&gt;generate&lt;/goal&gt;
            &lt;/goals&gt;

            &lt;configuration&gt;
                &lt;sourceDocumentName&gt;index.xml&lt;/sourceDocumentName&gt;
                &lt;sourceDirectory&gt;${basedir}/src/main/docs&lt;/sourceDirectory&gt;
                &lt;imageResource&gt;
                    &lt;directory&gt;${basedir}/src/main/docs/images&lt;/directory&gt;
                &lt;/imageResource&gt;
                &lt;cssResource&gt;
                    &lt;directory&gt;${basedir}/src/main/docs/css&lt;/directory&gt;
                &lt;/cssResource&gt;

                &lt;formats&gt;
                    &lt;format&gt;
                        &lt;formatName&gt;html&lt;/formatName&gt;
                        &lt;stylesheetResource&gt;classpath:/xslt/org/jboss/xhtml.xsl&lt;/stylesheetResource&gt;
                        &lt;finalName&gt;index.html&lt;/finalName&gt;
                    &lt;/format&gt;
                    &lt;format&gt;
                        &lt;formatName&gt;html_single&lt;/formatName&gt;
                        &lt;stylesheetResource&gt;classpath:/xslt/org/jboss/xhtml-single.xsl&lt;/stylesheetResource&gt;
                        &lt;finalName&gt;index.html&lt;/finalName&gt;
                    &lt;/format&gt;
                &lt;/formats&gt;

                &lt;options&gt;
                    &lt;xincludeSupported&gt;true&lt;/xincludeSupported&gt;
                &lt;/options&gt;
            &lt;/configuration&gt;
        &lt;/execution&gt;
    &lt;/executions&gt;
&lt;/plugin&gt;</pre>
<p>还需要加入 JBoos 的 mvn 库：</p>
<pre class="brush: xml; gutter: false; toolbar: false; auto-links: false">&lt;repositories&gt;
    &lt;repository&gt;
        &lt;id&gt;jboss-public-repository-group&lt;/id&gt;
        &lt;name&gt;JBoss Public Repository Group&lt;/name&gt;
        &lt;url&gt;http://repository.jboss.org/nexus/content/groups/public/&lt;/url&gt;
    &lt;/repository&gt;
&lt;/repositories&gt;</pre>
<p>目录结构：</p>
<p><a title="目录结构" href="https://pyqdbw.dm2302.livefilestore.com/y2p1MpINCmrzVLlvjf6p8o1ZwxXXKvDtrJbOdqFMpz5Hwr08vSWTxR57tHzk-fp6j68eVJ4T33FseHLLoDiGvuB6NaFKjcU9F50vDXaVde2rH8/docbook.png?psid=1" class="fancybox" data-fancybox-group="group"><img title="目录结构" src="https://pyqdbw.dm2302.livefilestore.com/y2p1MpINCmrzVLlvjf6p8o1ZwxXXKvDtrJbOdqFMpz5Hwr08vSWTxR57tHzk-fp6j68eVJ4T33FseHLLoDiGvuB6NaFKjcU9F50vDXaVde2rH8/docbook.png?psid=1" alt="目录结构" width="240" height="362" /></a></p>
<p>&nbsp;</p>
<p>本文主要是参考&nbsp;<a href="http://www.blogjava.net/kuuyee/archive/2009/07/27/288613.html" target="_blank">用maven-jdocbook-plugin简单配置docbook5.0环境</a>&nbsp;所写，并修复了其中一些配置有误的地方。</p>