title: Wordman 1.0.0 发布！
date: '2014-06-07 05:52:34'
updated: '2015-05-31 17:35:02'
tags: [B3log Announcement, B3log Wordman, 沃德曼, B3log]
permalink: /b3log-wordman-1.0.0-released
---
<h3><span>简介</span></h3>
<p>沃德曼（Wordman）是一个移动端的背单词应用，使用 <a href="http://cordova.apache.org" target="_blank">Cordova</a> 开发，目前发布了 1.0.0 的 Android 版本，欢迎大家<a href="http://pan.baidu.com/s/1sjtw5Rn" target="_blank">下载试用</a>。</p>
<h3><span>特性</span></h3>
<p>简约模式能够达到意想不到的成效，Less is More！</p>
<ul class="task-list">
<li>计划：不多不少，持之以恒</li>
<li>科学：艾宾浩斯记忆，渐进式增强</li>
</ul>
<p>沃德曼 + 坚毅的你 = 词典人，HOHO~</p>
<h3>功能</h3>
<ul>
<li>内置多个常用词库</li>
<li>开始选定一个词库学习时设置每天学习的词数，后续就按照该词数进行该词库的学习/复习</li>
<li>学习每一个单词时拼写一遍，正确的话到下一个词</li>
<li>艾宾浩斯记忆：第 1 天、第 2 天、第 4 天、第 7 天和第 15 天提醒，拼写后到下一个词，过完这课后重复错词，直到没有错词才进入下一课复习</li>
<li>生词本：记不住的词随时回顾</li>
</ul>
<h3>项目</h3>
<p><a href="https://github.com/b3log/wordman" target="_blank">https://github.com/b3log/wordman</a></p>