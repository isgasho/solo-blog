title: GitHub Windows 安装器
date: '2017-03-26 19:16:56'
updated: '2017-05-17 18:13:26'
tags: [Git, Windows, 安装]
permalink: /articles/2017/03/26/1490498197453.html
---
GitHub 已经提供了[完整安装包](https://desktop.github.com)，所以这个项目可以退休了 :smile: 

----

GitHub Windows 安装器，简称 GWI。项目地址：[https://github.com/b3log/github-windows-installer](https://github.com/b3log/github-windows-installer)

## 项目背景

GitHub Windows 是在线安装的，需要连接亚马逊云。因为你懂的原因，使得安装 GitHub Windows 成了一个问题 :sob: 

## 解决方案

本库是一个 GitHub Windows 安装器的 golang 实现，在 _网络条件好的地方_ 运行就可以制作安装包啦！

网络条件好的地方：国外服务器。比如阿里云**按量付费**的 ECS，选硅谷节点最低配置。

## 使用步骤

1. 在国外服务器上部署 gwi（[下载](https://pan.baidu.com/s/1o7BzBC2)或自行构建）
2. 运行 gwi，将在当前工作目录生成 github-windows.zip 安装包 
3. 下载安装包到本地后运行 GitHub.application
4. 安装完成！

## 原理

1. 下载应用元数据文件
2. 下载包描述文件
3. 解析所需包/资源文件下载路径
4. 并发下载

具体请看代码 :smirk:
