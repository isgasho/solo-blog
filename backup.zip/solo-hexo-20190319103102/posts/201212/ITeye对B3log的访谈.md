title: ITeye 对 B3log 的访谈
date: '2012-12-18 17:45:25'
updated: '2012-12-18 17:45:25'
tags: [B3log, Life in Programming]
permalink: /iteye-b3log
---
<p>这是 ITeye 对 B3log 团队的访谈。</p>
<h2>1. B3log Solo是什么？项目的由来？名称的寓意？</h2>
<p><strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo/"><span>B3log Solo</span></a></strong>&nbsp;是一个开源的 Java 博客程序，目前可以运行在 GAE、BAE、OpenShift 等云环境上，也可以运行在标准 Servlet 容器上。</p>
<p>项目来自于一个想整合博客与论坛的<strong id="internal-source-marker_0.276279206154868"><a href="http://88250.b3log.org/articles/2009/12/09/1260370800000.html"><span>想法</span></a></strong>，通过博客与社区论坛之间内容（文章、评论）的双向同步达到整合的目标，同时也不丢失个人博客的独立性。</p>
<p>2010 年，GAE 开始支持 Java，并且提供了宽裕的免费配额，作为个人博客已经足够用了，所以 B3log Solo 第一个支持的云平台就是 GAE，后来逐渐添加了本地容器、BAE 等运行环境支持。</p>
<p>B3log Solo 这个名字分为两部分：B3log 相当于一个产品前缀，是博客、论坛的缩写（BBS + Blog =&gt; B3log）；Solo（独奏）是这个博客产品的名字，好比乐手各自所拿的乐器，使用它来演奏不同的声音，最后会合成<strong id="internal-source-marker_0.276279206154868"><a href="http://symphony.b3log.org/"><span>交响乐</span></a></strong>（与社区论坛整合）。</p>
<p>查看<strong id="internal-source-marker_0.276279206154868"><a href="http://symphony.b3log.org/about"><span>《B3log 构思&mdash;&mdash;一个正在逐渐清晰、实践的创意》</span></a></strong>了解更多细节吧 ;-p</p>
<h2>2. B3log Solo基于哪些技术？你们的开发环境是什么？</h2>
<p>B3log Solo 是基于 <strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-latke"><span>B3log Latke</span></a></strong>&nbsp;这个轻薄 Servlet 框架开发的，框架中屏蔽了 GAE、BAE 等 PaaS 云环境与本地 Servlet 容器的差异，使得应用可以在不修改博客实现代码的前提下进行部署移植。前端基于 jQuery 进行开发，编写了一些通用的 jQuery 插件。整个前端具备代码自动合并、压缩，静态资源分离的功能。</p>
<p>项目是使用 Maven2+ 构建的，开发团队里有同学使用 NetBeans IDE 进行开发，也有同学使用 Eclipse。</p>
<h2>3. B3log Solo的性能如何？具体做了哪些优化？</h2>
<p>对于个人博客这个量级来说，我觉得 B3log Solo 的性能已经非常不错了 ;-p</p>
<p>一般情况下，个人博客的更新（写）频率不会非常高，总是读取要大于更新的，所以使用缓存可以有效降低读取响应时间。</p>
<p>B3log Solo 主要在页面与数据两个层次进行缓存：</p>
<ul>
<li>页面缓存：缓存最终输出到浏览器的 HTML</li>
<li>数据缓存：按查询条件缓存查询过的数据实体</li>
</ul>
<p>另外，Solo 重点对 GAE 配额使用进行了优化（参考<strong id="internal-source-marker_0.276279206154868"><a href="http://88250.b3log.org/gae-quota-optimization"><span>《GAE 配额优化》</span></a></strong>），尽量使用 GAE 提供的免费配额。</p>
<h2>4. B3log Solo目前有多少皮肤和插件？如何为B3log Solo开发皮肤、插件？</h2>
<p>目前发布包中自带 9 套皮肤、3 个插件，第三方皮肤、插件未统计。第三方皮肤应该还算多，插件倒是比较少，但相信慢慢会丰富起来的。</p>
<ul>
<li><strong id="internal-source-marker_0.276279206154868"><a href="https://docs.google.com/document/pub?id=15H7Q3EBo-44v61Xp_epiYY7vK_gPJLkQaT7T1gkE64w"><span>插件开发文档</span></a></strong>（Google Docs）</li>
<li><strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo/wiki/Develop_steps"><span>皮肤开发文档</span></a></strong></li>
</ul>
<h2>5. B3log Solo目前的应用情况？</h2>
<p>主要应用场景集中在个人博客这个范畴，也有部分用于团队博客、资讯博客、产品宣传。</p>
<p>累计提交过文章到社区服务器的用户快有 200 人了，相信以后会有越来越多的用户使用 B3log Solo，分享内容到社区。</p>
<p>另外，部署 GAE 版的同学也可以<strong id="internal-source-marker_0.276279206154868"><a href="http://88250.b3log.org/apply-b3log-domain.html"><span>申请 b3log.org 二级域名</span></a></strong>，使得国内能够方便访问您部署好的博客。</p>
<h2>6. 有哪些开发者参与了B3log Solo的开发？你们之间是如何协作的？</h2>
<p>B3log 团队目前一共有 5 人，可以在 <strong id="internal-source-marker_0.276279206154868"><a href="http://www.b3log.org/"><span>B3log Index</span></a></strong>&nbsp;最下面的时间线以及<strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo/wiki/About_us"><span>团队介绍 Wiki</span></a></strong> 里找到我们。</p>
<p>大多数时候，我们通过 QQ 群进行沟通；开发方面通过 GitHub Issues 进行任务管理；在线语音进行半年计划等。</p>
<h2>7. 其他开发者如何参与该项目？</h2>
<p>可以通过如下几种途径参与开发：</p>
<ul>
<li>第三方皮肤开发：开发好皮肤后联系 <strong id="internal-source-marker_0.276279206154868"><a href="http://vanessa.b3log.org/"><span>Vanessa</span></a></strong>，她会协助你把皮肤提交到<strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo-third-skins"><span>官方库</span></a></strong>中，以便分享给更多的人。</li>
<li>补丁开发：直接通过 GitHub Pull 提交，审核通过后该补丁会合并到提交的版本中。</li>
<li>加入 B3log 团队：<strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo/wiki/Join_us"><span>这里</span></a></strong>有详细的加入指南。</li>
</ul>
<p>当然，也可以加入 QQ 群 13139268 参与讨论；<strong id="internal-source-marker_0.276279206154868"><a href="https://github.com/b3log/b3log-solo/issues/new"><span>提交缺陷/特性请求</span></a></strong>等方式参与到项目中来 :-)</p>
<h2>8. 你怎样看待国内的开源环境？</h2>
<p>国内程序员的生存压力比较大，整体的开源气氛比较冷淡。相比国外大学，研究机构或者顶级公司机构引导开源项目为多数，国内的开源项目大多数还是靠个体开发者本身的经验进行推动和发展，项目的完整性、质量和持续性都有一定的欠缺。</p>
<p>但也正因为国内的开源比较欠缺，大家聚在一起开发会感觉更平等些（能参与 apache 基金会这类级别开源项目的非常少）。就在这样一个相对轻松的环境下，大家更有机会实现自己的想法，平等的交流，更好的互补学习和拓宽视野，获得一些独特的成就感。当然，也非常期待国内多一些企业来引领开源，成立开源组织，教堂与集市共存。</p>
<h2>9. B3log 未来的发展计划？</h2>
<ul>
<li>Solo 将支持更多的云环境，方便用户享用更多的免费云资源</li>
<li>完善 B3log Latke 框架，完善相关文档</li>
<li>提供更好的插件体系，良好应用生态链</li>
<li>开发团队成员 Y 可能会使用 scala 实现 Solo，便捷自定义功能</li>
<li>从社区方面加强独立博客之间的交互</li>
<li>社区开放 APIs</li>
</ul>
<h2>团队成员介绍</h2>
<p>丁亮：Base 昆明，怀揣理想的码农，有时候很 2。项目创始人，负责B3log系产品计划与实现。</p>
<p><img src="https://plrtwg.dm1.livefilestore.com/y1pPuZ7UveXF6vNkpU2e-ZRszzTmpIvqF_JNN41oi6jTn-jI78h9CCGUGXgWMXF1jZB8Ft-oYAB2_wD-hGPhd5_QZezr_9VS8At/d.png?psid=1" alt="D" width="172" height="177" /></p>
<p>李丽媛：Base 昆明，热爱前端，易怒易悲之人。项目副创始人，负责前端实现。</p>
<p><img src="https://plrtwg.dm1.livefilestore.com/y1pTTji12pTg8WcvuT1PIz88Vebz1KLpF2yR9VKM5_kSTyCw-10DjTxCJh8S1tuQkGjfSz6EsspBH6yXuu_eV5uoQ_B9KlWwAoF/v.png?psid=1" alt="V" width="175" height="160" /><br /> <br />姚立嶒：Base上海，努力地帮大家写点代码的家伙。为 Latke 框架和技术路线贡献了很多。</p>
<p><img src="https://plrtwg.dm1.livefilestore.com/y1pekH6Otn8FX6hO3Chx03iZNDDs7EI3spRWO1NrLDkbjIih6HYCL8iwNBRjaGZY6_LYXvR4vtFQx0TMaBobopVTVK5QNkpn9gf/y.png?psid=1" alt="Y" width="145" height="171" /></p>
<p><br />王东旭：Base成都，有坚持有想法的帅小伙。负责博客、社区功能实现。</p>
<p><img src="https://plrtwg.dm1.livefilestore.com/y1pTTji12pTg8WQky-LvFobY0rr0sxOJEhrGBhZzd8NZC-nZQrIdcp3Ujw7niz_kuvpFuDUtqgW6Be_jWUIrCfjVApV2UkkWUGv/dx.png?psid=1" alt="DX" width="200" height="159" /><br /> <br />江泽洲：Base杭州，热爱生活，相信积累。负责Wiki文档，产品推广。</p>
<p><img src="https://plrtwg.dm1.livefilestore.com/y1p-ba77mD399CbPN8hRYvNgxL6XVj5zvr7cAxqum3kjYxmVfkS207E_-B2CfR356eakDwMjt0R3Ll2fRRl2_NJmmBYmy9sNGnT/j.png?psid=1" alt="J" width="200" height="169" /></p>
<p>&nbsp;</p>
<p>发布的原文<a href="http://www.iteye.com/magazines/106" target="_blank">点这里</a></p>