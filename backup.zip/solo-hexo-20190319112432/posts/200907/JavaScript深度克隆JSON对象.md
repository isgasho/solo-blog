title: JavaScript 深度克隆 JSON 对象
date: '2009-07-24 08:35:00'
updated: '2009-07-24 08:35:00'
tags: [JavaScript]
permalink: /articles/2009/07/23/1248366900000.html
---
<p><pre name='code' class='brush:java;' cols="50" rows="15" name="code" class="javascript">function clone(jsonObj) {
    var buf;
    if (jsonObj instanceof Array) {
        buf = [];
        var i = jsonObj.length;
        while (i--) {
            buf[i] = clone(jsonObj[i]);
        }
        return buf;
    }else if (jsonObj instanceof Object){
        buf = {};
        for (var k in jsonObj) {
            buf[k] = clone(jsonObj[k]);
        }
        return buf;
    }else{
        return jsonObj;
    }
}</pre>
 </p>