title: Linux下小巧好用的截图程序
date: '2007-05-10 02:35:00'
updated: '2007-05-10 02:35:00'
tags: [My Linux]
permalink: /articles/2007/05/09/1178706900000.html
---
小巧好用的截图程序<span style="text-decoration: underline;"><span style="font-weight: bold;"></span></span> &mdash;&mdash; gsnapshot<br /><a href="http://download1.csdn.net/down3/20070509/09103502838.gsnapshot">点击下载</a>