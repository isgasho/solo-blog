title: 理解 Eureka 的 P2P 通讯
date: '2017-06-30 00:49:46'
updated: '2017-06-30 00:49:46'
tags: [eureka, 微服务, 客户端]
permalink: /articles/2017/06/29/1498726165535.html
---

Eureka 客户端会和在同一个可用区（Zone）的服务端进行通讯，如果通讯失败或者服务端没有和客户端在一个可用区，则客户端将进行失效转移：对其他可用区的服务端发起通讯。

服务端接收到客户端信息后，会进行一些列[操作](https://github.com/Netflix/eureka/wiki/Understanding-eureka-client-server-communication)将信息同步给其他服务端节点。如果某步操作失败，信息将在下一次心跳时同步给其他服务端节点。

当一个 Eureka 服务端节点启动后，它将向其他服务端节点获取所有实例的注册信息。服务端获取到实例列表后将根据信息创建续约（renew）相关数据并准备接收来自客户端的续约请求。如果在某个时刻客户端续约失败（15 分钟内低于 85%），服务端将停止实例过期防止该实例注册信息丢失。

在 Netflix 内部，上述过程称作**自我保护**模式，是 Eureka 客户端和服务端通讯时发生断网的一个保护机制。在这个场景下，服务端将尝试保存住已有的注册信息。此时客户端获取的实例列表中有可能有的实例已经不能正常服务了，客户端需要自己保证 Eureka 服务端返回的实例在不存在或不响应情况下是弹性的，最好的处理方式就是对该实例的调用设置较短超时并尝试其他服务器。

当服务端没法从其他节点获取注册信息时，它将等待 5 分钟让客户端注册自己。服务端会尽可能地提供完整信息给客户端，所以可能会导致调用流量集中在某些实例上。

Eureka 服务端-服务端之间的通讯也使用客户端-服务端通讯同样的机制，参数调整可参考 [configurations](https://github.com/Netflix/eureka/blob/master/eureka-core/src/main/java/com/netflix/eureka/EurekaServerConfig.java)。

**服务端节点之间断网会发生什么？**

* 节点之间心跳会失败，检查到后进入自我保护模式防止注册列表丢失
* 在孤立服务节点上可能会有注册事件，部分客户端可能获取到新的注册实例，部分客户端获取不到
* 网络连通后将恢复到正常状态，新注册信息将被同步到所有服务节点

最后需要强调的是，在断网期间，服务端会尽可能保持可用，但不同的客户端可能会看到不同的数据。

译自：[Understanding Eureka Peer to Peer Communication](https://github.com/Netflix/eureka/wiki/Understanding-Eureka-Peer-to-Peer-Communication)

