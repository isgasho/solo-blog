title: Maven 引入 tools.jar
date: '2010-06-18 09:10:00'
updated: '2010-06-18 09:10:00'
tags: [Maven 2]
permalink: /articles/2010/06/17/1276794600000.html
---
<p>tools.jar 在 Sun 的 JDK lib 目录下，包含了一些非常有用的工具，例如 <a href="http://java.sun.com/javase/6/docs/jdk/api/javac/tree/index.html">Compiler Tree API</a>
。</p>
<p>&nbsp;</p>
<p>Maven 建立的项目可以做如下配置：</p>
<p>&nbsp;</p>
<p>&nbsp;&nbsp; <pre name='code' class='brush:java;' cols="50" rows="15" name="code" class="xhtml">&lt;profiles&gt;
        &lt;profile&gt;
            &lt;id&gt;default-tools.jar&lt;/id&gt;
            &lt;activation&gt;
                &lt;property&gt;
                    &lt;name&gt;java.vendor&lt;/name&gt;
                    &lt;value&gt;Sun Microsystems Inc.&lt;/value&gt;
                &lt;/property&gt;
            &lt;/activation&gt;
            &lt;dependencies&gt;
                &lt;dependency&gt;
                    &lt;groupId&gt;com.sun&lt;/groupId&gt;
                    &lt;artifactId&gt;tools&lt;/artifactId&gt;
                    &lt;version&gt;1.6.0&lt;/version&gt;
                    &lt;scope&gt;system&lt;/scope&gt;
                    &lt;systemPath&gt;${java.home}/../lib/tools.jar&lt;/systemPath&gt;
                &lt;/dependency&gt;
            &lt;/dependencies&gt;
        &lt;/profile&gt;
    &lt;/profiles&gt;</pre></p>
<p>&nbsp;</p>
<p>&nbsp;</p>