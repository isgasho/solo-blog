title: 为什么又要造一个叫 Latke 的轮子
date: '2014-06-27 21:38:46'
updated: '2018-12-15 10:28:21'
tags: [JSON, ORM, Java, B3logLatke]
permalink: /why-latke-exists
---
<p>本文最新版本已经迁移到<a href="https://hacpai.com/article/1403847528022" target="_blank">这里</a>。</p>