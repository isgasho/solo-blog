title: 通过支付宝捐赠 B3log 项目
date: '2011-09-18 01:23:22'
updated: '2011-09-18 01:23:22'
tags: [B3log Announcement, B3log, Open Source, Life in Programming]
permalink: /donate-b3log
---
<p>如果你觉得 B3log 还行，可以通过支付宝<a href="https://mai.alipay.com/p.htm?id=2011091700592247" target="_blank"><span style="color: green;">捐赠 B3log Solo 项目</span></a>哦。</p>
<p>捐赠款将用作 b3log.org 域名与团队建设上，目前团建暂定为 B3 文化衫。</p>
<p>长期维护一个开源项目的确是不容易的。在有一个小团队都为这个项目努力的时候，更应该坚持下去。</p>
<p>期待更多的童鞋<a href="http://code.google.com/p/b3log-solo/wiki/join_us" target="_blank">加入 B3log 团队</a>，一起推进中国开源软件的发展，方便他人。</p>