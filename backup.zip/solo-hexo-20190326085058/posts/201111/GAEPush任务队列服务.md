title: GAE Push 任务队列服务
date: '2011-11-17 16:55:43'
updated: '2011-11-17 16:55:43'
tags: [Data-Structrue/Algorithms, Queue, GAE, Java]
permalink: /gae-task-push-queue
---
<p>任务队列主要用于异步处理，本文主要介绍 GAE Push 任务队列服务的关键配置。</p>
<h2>Push 队列</h2>
<p>Push 队列即&ldquo;推队列&rdquo;。当应用调用任务队列 API 添加任务后，任务队列服务将&ldquo;推&rdquo;任务进行执行。</p>
<p>比如我们在 queue.xml 中的配置如下：</p>
<pre class="brush: xml">&lt;queue-entries&gt;
    &lt;queue&gt;
        &lt;name&gt;request-stat-queue&lt;/name&gt;
        &lt;rate&gt;20/m&lt;/rate&gt;
        &lt;bucket-size&gt;60&lt;/bucket-size&gt;
        &lt;retry-parameters&gt;
            &lt;task-retry-limit&gt;7&lt;/task-retry-limit&gt;
        &lt;/retry-parameters&gt;
    &lt;/queue&gt;
&lt;/queue-entries&gt;</pre>
<p>表示以每分钟 20 个任务的速率从任务队列中获取任务，放入&ldquo;缓存&rdquo;中等待执行；每个任务执行最多重试 7 次。</p>
<p>而 bucket-size 表示最多可以&ldquo;缓存&rdquo; 60 个待执行的任务。这里引入一个流量控制的算法：<a href="http://en.wikipedia.org/wiki/Token_bucket" target="_blank">Token Bucket</a>（令牌桶）。</p>
<h3>令牌桶算法</h3>
<p>令牌桶算法主要是用于流量控制。在 GAE Push 队列中用于控制&ldquo;推&rdquo;任务的速率（从任务队列中获取任务放入&ldquo;缓存&rdquo;的速率），队列中的任务相当于令牌，而&ldquo;缓存&rdquo;就是令牌桶。</p>
<p>结合上面的配置例子描述如下：</p>
<ul>
<li>任务（令牌）以每分钟 20 个的速率放入桶中</li>
<li>桶最多能放入 60 个任务，多于的任务将保留在队列中下次处理</li>
<li>任务调度器每次从桶中取走 n 个任务<sup>1</sup>进行执行</li>
</ul>
<p>1. 调度器取的任务数是 GAE 自行计算的，<a href="https://code.google.com/appengine/docs/java/config/queue.html#Defining_Push_Queues_and_Processing_Rates" target="_blank">任务队列文档</a>上描述是&ldquo;如果桶中有令牌，会一直从桶中取令牌，直到桶空为止&rdquo;。</p>
<h3>任务执行</h3>
<p>当队列中排有任务时，队列服务将自动&ldquo;依次&rdquo;执行任务：</p>
<ol>
<li>队列中任务次序<br />按照 FIFO（先进先出）执行队列中的任务，新加入队列的任务将被置于队尾。</li>
<li>任务积压<br />如果队列中有积压的任务的话，调度器将找出处理延迟最小的任务进行执行。也就是说可能会跳过队首任务。</li>
<li>执行结果<br />如果任务执行处理后返回 HTTP 状态码 200-299，则认为该任务处理成功；否则失败。</li>
</ol>
<h3>参考</h3>
<ul>
<li><a href="https://code.google.com/appengine/docs/java/taskqueue/">Google App Engine Java - The Task Queue Java API</a></li>
<li><a href="https://code.google.com/appengine/docs/java/config/queue.html" target="_blank">Google App Engine Java - Java Task Queue Configuration</a></li>
<li><a href="http://en.wikipedia.org/wiki/Token_bucket" target="_blank">Token bucket Algorithm</a></li>
</ul>