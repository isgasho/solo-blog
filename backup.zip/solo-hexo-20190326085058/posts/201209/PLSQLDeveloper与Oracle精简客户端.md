title: PL/SQL Developer 与 Oracle 精简客户端
date: '2012-09-14 18:16:47'
updated: '2012-09-14 18:16:47'
tags: [Oracle, PL/SQL, Database]
permalink: /plsql_developer_oracle_min_client
---
<p>本文介绍如何安装 PL/SQL Developer 9 与 Oracle 精简客户端。</p>
<p>&nbsp;</p>
<p>1. <a href="http://pan.baidu.com/share/link?shareid=32843&amp;uk=3255126224">下载 PL/SQL Dev</a></p>
<p>2. <a href="http://pan.baidu.com/share/link?shareid=32844&amp;uk=3255126224">下载 Oracle 精简客户端</a></p>
<p>3. 安装 PL/SQL Dev 以及汉化包</p>
<p>4. 解压 Oracle 精简客户端，比如解压目录为 <strong><span style="color: #ff6600;">D:\oracle10g</span></strong></p>
<p>5. 配置 Oracle 连接。D:\oracle10g\tnsnames.ora，D:\oracle10g\NETWORK\ADMIN\tnsnames.ora</p>
<p>6. 配置系统环境变量</p>
<p>&nbsp;&nbsp; 1. ORACLE_HOME</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 值：<strong><span style="color: #ff6600;">D:\oracle10g</span></strong><br />&nbsp;&nbsp;&nbsp;2. TNS_ADMIN<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 值：<strong><span style="color: #ff6600;">D:\oracle10g</span></strong><br />&nbsp;&nbsp;&nbsp;3. NLS_LANG<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 值：SIMPLIFIED CHINESE_CHINA.ZHS16GBK</p>
<p>7. 配置 PL/SQL Dev</p>
<p>工具 -&gt; 首选项，Oracle 主目录名：<strong><span style="color: #ff6600;">D:\\oracle10g</span></strong><span style="color: #ff6600;"><span style="color: #000000;">，OCI 库：<strong><span style="color: #ff6600;">D:\\oracle10g\\oci.dll</span></strong></span></span></p>
<p><span style="color: #000000;"></span></p>