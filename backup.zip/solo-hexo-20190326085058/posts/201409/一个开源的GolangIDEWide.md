title: 一个开源的 Golang IDE - Wide
date: '2014-09-11 08:13:05'
updated: '2014-09-11 08:15:19'
tags: [Life in Programming, golang, Wide, B3log]
permalink: /hello-wide
---
<h3>Wide 的由来</h3>
<ul>
<li>团队的 IDE：
<ul>
<li>安全可靠：项目源代码实时保存在服务器上，开发者的机器崩溃不会丢失任何源代码</li>
<li>统一环境：服务器统一配置开发环境，开发者本机无需任何额外配置</li>
<li>开箱即用：5 分钟搭建服务器；开发者打开浏览器即可开发、调试</li>
<li>版本控制：每个开发者拥有自己的源代码仓库，随时可和主干保持同步</li>
</ul>
</li>
<li>基于 Web 的 IDE：
<ul>
<li>客户端只需要浏览器</li>
<li>跨平台，甚至在移动设备上</li>
<li>For the geeks</li>
</ul>
</li>
<li>目前较为流行的 Go IDE 都有一些缺陷或遗憾：
<ul>
<li>文本编辑器类（vim/emacs/sublime/Atom 等）：对于新手门槛太高，搭建复杂</li>
<li>插件类（goclipse 等）：需要原 IDE 支持，不够专业</li>
<li>LiteIDE：界面不够 modern :p</li>
<li>没有团队开发体验</li>
</ul>
</li>
<li>Go IDE 很少，用 Go 本身开发的 IDE 更是没有，这是一个很好的尝试</li>
</ul>
<h3>特性列表</h3>
<ul>
<li>代码高亮、折叠：Go/HTML/JavaScript/Markdown 等</li>
<li>自动完成：Go/HTML 等</li>
<li>编译检查：编辑器提示编译错误</li>
<li>格式化：Go/HTML/JSON 等</li>
<li>运行：支持同时运行多个程序，方便联调</li>
<li>调试：基于 gdb 的调试系统</li>
<li>多用户：团队开发，方便协作</li>
<li>代码导航：跳转到声明，查找使用，文件搜索等</li>
<li>Shell：连接到服务器执行命令</li>
<li>Web 开发：前端（HTML/JS/CSS）开发支持</li>
<li>go tool：go get/install/fmt 等</li>
<li>Git 整合：常用 git 命令可视化操作</li>
</ul>
<p>目前项目处于初始阶段，欢迎大家来捧场 :)</p>
<p><a href="https://github.com/b3log/wide" target="_blank">https://github.com/b3log/wide</a></p>