title: 使用 GitBook 写文档
date: '2014-09-19 05:42:37'
updated: '2015-12-10 21:57:01'
tags: [Markdown, GitBook, Git]
permalink: /write-doc-via-gitbook
---
<p>最近发现很多技术书籍都放在&nbsp;<a href="https://www.gitbook.io" target="_blank">GitBook</a>&nbsp;上提供给人们阅读，刚好 <a href="https://github.com/b3log/wide" target="_blank">Wide</a> 也需要写文档，索性就尝试使用 GitBook 来做。</p>
<h3>GitBook 简介</h3>
<p>GitBook 是一个通过 Git 和 Markdown 来撰写书籍的工具，最终可以生成 3 种格式：</p>
<ul>
<li><em>静态站点</em>：包含了交互功能（例如搜索、书签）的站点</li>
<li><em>PDF</em>：PDF 格式的文件</li>
<li><em>eBook</em>：ePub 格式的电子书文件</li>
</ul>
<p>GitBook 是免费且开源的，项目地址：<a href="https://github.com/GitbookIO/gitbook" target="_blank">https://github.com/GitbookIO/gitbook</a></p>
<h4>Git 方式</h4>
<p>GitBook 使用 Git 进行写作内容管理。</p>
<ul>
<li>从用户的角度看，这样能够方便地进行多人协作（连程序源代码都能管好，书籍自然不在话下），还不用学习额外概念或用法</li>
<li>从设计实现的角度看，这样能够合理利用已有工具（不重复造轮）满足产品需求，甚至扩展性更好（Git 相关服务能够利用的太多了）</li>
</ul>
<p>正所谓：&ldquo;人法地，地法天，天法道，道法自然&rdquo;啊。</p>
<h4>Markdown</h4>
<p>GitBook 不只是利用了 Git，目前非常流行的 Markdown 也被运用其中。</p>
<p>使用 Markdown 最大的好处就是简单：</p>
<ul>
<li>语法简单，并且能够形象地表达出意图（例如无序列表使用 * ，强调使用 ** ，一个 # 表示 H1、两个 # 表示 H2）</li>
<li>不干扰写作者：语法标记在视觉上对写作者的负面影响不大（不像 HTML 满屏的 &lt;&gt;）</li>
</ul>
<p>总之，Markdown 就是能够让写作者更专注于内容创作。</p>
<p>不过 GitBook 不只是简单地使用 Markdown，使用 Markdown 编写的内容只是源格式，最终的目标格式可以为 PDF、ePub 等。</p>
<h3>静态站点</h3>
<p>在本地编写完内容后我们需要将内容提交到 GitBook 上进行书籍的构建。GitBook 会将书籍构建为 4 种格式（JSON、ePub、PDF、Website）。 其中我们最常用的应该是静态站点，这样能够方便传播。</p>
<h3>客户端编辑器</h3>
<p>可以使用 GitBook 的官方编辑器来进行写作、发布等管理，非常方便：</p>
<p><a href="https://pyqdbw-dm2305.files.1drv.com/y2pE7bJdw-yYhYWUgk9ThbGWCQ6-w9nTrOfAPT4fS5yQ60Ppz2EpVQ4d5GmNbS-MOZpyZCk9KkKPcYhlV7SElOXqB9aiBcLEjce65yzG7F4oAg/gitbook.png?psid=1" class="fancybox" data-fancybox-group="group"><img src="https://pyqdbw-dm2305.files.1drv.com/y2pE7bJdw-yYhYWUgk9ThbGWCQ6-w9nTrOfAPT4fS5yQ60Ppz2EpVQ4d5GmNbS-MOZpyZCk9KkKPcYhlV7SElOXqB9aiBcLEjce65yzG7F4oAg/gitbook.png?psid=1" alt="GitBook Editor" width="600" height="311" /></a></p>
<h3>其他</h3>
<p>GitBook 还有很多功能，例如：</p>
<ul>
<li>自定义静态站点域名</li>
<li>多语言支持</li>
<li>书籍私有</li>
<li>自定义封面（弄个漂亮的书皮吧）</li>
<li>交互式练习、提问（这个用于写问答类书籍或习题类书籍会很有用）</li>
</ul>
<h3>题外话</h3>
<p>GitHub、GitBook、GitXXX 都很流行啊，为什么呢？</p>
<p>Git 已经不只是一个版本控制系统了，它的分布式协作方式正在潜移默化地影响着很多程序的设计，最终影响了很多在线服务的提供方式。这样一种<em>私有-公有</em>可控的网络信息架构是非常值得我们学习并实践的，这样架构的各类产品将越来越多。</p>