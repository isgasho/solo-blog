title: 腾讯对外发布微博开放平台 API
date: '2010-12-17 17:07:44'
updated: '2010-12-17 17:07:44'
tags: [Network Engineering, Tencent]
permalink: /tencent-open-micro-blogging-api.html
---
<p>腾讯微博开放平台API开放啦，使用腾讯微博开放平台提供的API创建自己的应用，需要首先填写个人资料，通过联系邮箱验证，获取开发者资格，就能 创建自己的应用。腾讯微博开放平台，是基于腾讯微博系统，为广大开发者和用户提供的开放数据分享与传播平台。广大开发者和用户登录平台后，就可以使用平台     提供的开放API接口，创建应用从微博系统获取信息，或将新的信息传播到整个微博系统中，丰富多样的API接口和应用，加上你的智慧，将创造出无穷的应用和乐趣。</p>
<div><strong><span style="color: #000000;"><span style="font-size: medium;">平台使用说明：</span></span></strong></div>
<p>腾讯微博开放平台，是基于腾讯微博系统，为广大开发者和用户提供的开放数据分享与传播平台。广大开发者和用户登录平台后，就可以使用平台提供的开放    API接口，创建应用从微博系统获取信息，或将新的信息传播到整个微博系统中，丰富多样的API接口和应用，加上你的智慧，将创造出无穷的应用和乐趣！</p>
<p><a href="http://open.t.qq.com/resource.php?i=0,1" target="_blank">平台介绍</a> &mdash; 在微博开放平台能获取到的资源及优势</p>
<p><a href="http://open.t.qq.com/resource.php?i=0,2" target="_blank">应用开发说明</a> &mdash; 说明如何成为一个开发者并创建应用</p>
<p><a href="http://open.t.qq.com/resource.php?i=0,3" target="_blank">应用审核流程</a> &mdash; 审核应用的来源字段能获得的好处，以及如何审核</p>
<p><a href="http://open.t.qq.com/resource.php?i=0,5" target="_blank">开发者协议</a> &mdash; 在此查看腾讯微博开放平台开发者服务协议</p>
<h3>如何开发微博应用？<span style="color: #ff0000;"><a href="http://open.t.qq.com/develop.php" target="_blank">（马上成为开发者）</a></span></h3>
<p>你只需要按照如下步骤操作：</p>
<p>第一步：填写你的开发者信息；</p>
<p>第二步：联系邮箱通过验证；（电子邮箱将作为我们联系你的重要方式，请提供常用邮箱地址）</p>
<p>第三步：填写要创建的应用信息。</p>
<p>就能马上获取到微博App Key和App Secret，调用微博API，进行应用开发。 <a href="http://open.t.qq.com/resource.php?i=0,2" target="_blank"><strong>查看详细说明</strong></a></p>
<p>----</p>
<p>代表着中国最先进的互联网技术的腾讯终于走出了开放的第一步 :-)</p>
<p>转自：http://www.oschina.net/news/13863/tencent-open-micro-blogging-api</p>