title: 长城——Beyond
date: '2010-11-25 17:20:24'
updated: '2010-11-25 17:20:24'
tags: [Music]
permalink: /articles/2010/11/25/1290648024319.html
---
<p>作词: 刘卓辉&nbsp;&nbsp;&nbsp; 作曲: 黄家驹<br /><br />遥远的东方辽阔的边疆</p>
<p>还有远古的破墙</p>
<p>前世的沧桑后世的风光</p>
<p>万里千山牢牢接壤</p>
<p><span style="color: #ff0000;">围着</span>老去的国度</p>
<p><span style="color: #ff0000;">围着</span>事实的真相</p>
<p><span style="color: #ff0000;">围着</span>浩瀚的岁月</p>
<p><span style="color: #ff0000;">围着</span>欲望与理想<br /><br />神秘的村庄神秘的中央</p>
<p>还有昨天的战场</p>
<p>皇帝的新衣热血的缨枪</p>
<p>谁却甘心流连塞上<br /><br /><span style="color: #ff0000;">围着</span>欲望与理想叫嚷<br /><br />蒙着耳朵</p>
<p>那里那天不再听到在呼号的人</p>
<p>woo～</p>
<p>蒙着眼睛</p>
<p>再见往昔景仰的那样一道疤痕</p>
<p>woo～</p>
<p>留在地壳头上<br /><br />hmm&hellip;&hellip;yeah～</p>
<p>woo～<br /><br />无冕的身躯忘我的思想</p>
<p>还有显赫的破墙</p>
<p>谁也冲不开谁也抛不低</p>
<p>谁要一生流离浪荡</p>
<p>----</p>
<p>和谐。</p>