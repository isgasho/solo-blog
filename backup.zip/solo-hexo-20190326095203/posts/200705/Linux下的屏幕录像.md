title: Linux下的屏幕录像
date: '2007-05-03 03:10:00'
updated: '2007-05-03 03:10:00'
tags: [My Linux]
permalink: /articles/2007/05/02/1178104200000.html
---
<p class="zh_p"><br /></p>
<p class="zh_p">介绍一下这个<span style="color: rgb(255, 0, 0);">2M</span>多小巧而免费的<a target="_blank" hreflang="en" href="http://xvidcap.sourceforge.net/">xvidcap</a>，当前最高版本为1.15，它可以将屏幕操作录制为：avi、mpeg、asf、flv、dv、m1v、m2v和mov视频文件格式，请到这个地址下载：</p>
<p class="zh_p"><a href="http://sourceforge.net/projects/xvidcap/">http://sourceforge.net/projects/xvidcap/</a><br /></p>
<p class="zh_p">我用的是Ubuntu Feisty Fawn，下载了Deb包，安装后到/usr/share/applications/下找到Xvidcap在桌面配置文件，然后Copy到桌面上就可以用了:-)<br /></p>