title: Write in C
date: '2008-03-25 11:45:00'
updated: '2008-03-25 11:45:00'
tags: [C/C++, Fiddlededee]
permalink: /articles/2008/03/24/1206387900000.html
---
<div>(sung to The Beatles &quot;Let it Be&quot;)<br />用C写吧<br />（一首仿Beatles歌《Let's it Be》）<br />English version by Omri Weisman, 中文版 by xcxin</div>
<div>When I find my code in tons of trouble, <br />Friends and colleagues come to me, <br />Speaking words of wisdom: <br />&quot;Write in C.&quot;<br />每当我发现我的代码中充斥着错误，<br />朋友和同伴们就来到我身边，<br />带着富有智慧的说辞：<br />&ldquo;用C写吧。&rdquo;</div>
<div><br />As the deadline fast approaches, <br />And bugs are all that I can see, <br />Somewhere, someone whispers&quot; <br />&quot;Write in C.&quot;<br />项目交付期一天天逼近，<br />但是我仍能发现太多Bugs，<br />某个地方有个人悄悄对我说：<br />&ldquo;用C写吧。&rdquo;</div>
<div><br />Write in C, write in C, <br />Write in C, write in C. <br />LISP is dead and buried, <br />Write in C.<br />用C写吧，用C写吧，<br />用C写吧，用C写吧，<br />LISP早就被历史埋葬！<br />用C写吧。</div>
<div>I used to write a lot of FORTRAN, <br />for science it worked flawlessly. <br />Try using it for graphics! <br />Write in C.<br />我曾经写过大量的Fortran程序，<br />科研应用一直很OK，<br />但是试试图形的东东？<br />用C写吧。</div>
<div><br />If you've just spent nearly 30 hours <br />Debugging some assembly, <br />Soon you will be glad to <br />Write in C.<br />如果你已经花费掉30小时，<br />全部都在你的汇编中捉虫，<br />不久你会发现，<br />用C写吧。</div>
<div><br />Write in C, write in C, <br />Write In C, yeah, write in C. <br />Only wimps use BASIC. <br />Write in C.<br />用C写吧，用C写吧，<br />用C写吧，yeah，用C写吧。<br />只有白痴才用BASIC。<br />用C写吧</div>
<div><br />Write in C, write in C, <br />Write in C, oh, write in C. <br />Pascal won't quite cut it. <br />Write in C.<br />用C写吧，用C写吧，<br />用C写吧，oh，用C写吧<br />Pascal永远也别想替代C，<br />用C写吧！</div>
<div><br />Guitar Solo（吉他序曲）</div>
<div><br />Write in C, write in C, <br />Write in C, yeah, write in C. <br />Don't even mention COBOL. <br />Write in C.<br />用C写吧，用C写吧<br />用C写吧，yeah，用C写吧<br />管COBOL干什么！？<br />用C写吧。</div>
<div><br />And when the screen is fuzzy, <br />And the edior is bugging me. <br />I'm sick of ones and zeroes. <br />Write in C.<br />想想屏幕一片混乱，<br />想想编辑器里太多Bugs，<br />我就会感到不舒服，<br />用C写吧。</div>
<div><br />A thousand people people swear that T.P. <br />Seven is the one for me. <br />I hate the word PROCEDURE, <br />Write in C.<br />太多的人们那，诅咒T.P.（注1)<br />我就是其中之一，<br />我憎恨PROCEDURE，<br />用C写吧。</div>
<div><br />Write in C, write in C, <br />Write in C, yeah, write in C. <br />PL1 is 80's, <br />Write in C.<br />用C写吧。，用C写吧。<br />用C写吧。，yeah，用C写吧。<br />PL1是80年代的老货，<br />用C写吧。。</div>
<div><br />Write in C, write in C, <br />Write in C, yeah, write in C. <br />The government loves ADA, <br />Write in C.<br />用C写吧，用C写吧。<br />用C写吧，yeah，用C写吧。<br />政府只喜欢漂亮的ADA（注2），<br />用C写吧。</div>
<div>&nbsp;</div>
<div>注1 ：T.P.指代Turbo Pascal。Borland公司传奇般的编译器。也是世界上第一个不用更换软盘就可以闪电般完成编译的第一个Pascal编译器。不过其烦琐的语法以及难看的begin...end一直为人们所诟病。<br />注2： ADA是指代的Ada语言，Ada是法国一位年轻漂亮的姑娘的名字。据说她曾经为巴贝其的&ldquo;分析机&rdquo;编写过程序，因此被誉为人类历史上第一位程序员。<br /><br />歌曲下载：http://download.csdn.net/source/393547<br />类似的歌曲还有这首讲JavaEE5的：http://blog.csdn.net/DL88250/archive/2008/02/14/2095540.aspx</div>