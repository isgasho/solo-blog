title: LivaPlayer主界面预览[00原创]
date: '2007-06-23 03:06:00'
updated: '2007-06-23 03:06:00'
tags: [LivaPlayer]
permalink: /articles/2007/06/22/1182510360000.html
---
界面基本绘制好了，如下：<br /><br /><img src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_LivaPlayer%20Preview.bmp" alt="" /> <br /><br />不过EQ（均衡器）的功能暂时不准备加入，等到8月初第一个正式版发布了之后在做。<br />目前的工作主要集中在做歌词显示面板。