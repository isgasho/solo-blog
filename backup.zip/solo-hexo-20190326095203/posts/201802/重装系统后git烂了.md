title: 重装系统后 git 烂了
date: '2018-02-25 03:25:02'
updated: '2018-02-25 03:25:02'
tags: [Windows, 'null', Git]
permalink: /articles/2018/02/24/1519471473213.html
---

```
C:\Users\Administrator>git
fatal: open /dev/null or dup failed: No such file or directory
```

Windows 上也有 /dev/null？？？？Google 一圈后发现确实有，是用一个系统服务模拟的：

```
C:\Users\Administrator>sc query null

SERVICE_NAME: null
        TYPE               : 1  KERNEL_DRIVER
        STATE              : 1  STOPPED
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0
```

手动启动该服务报错：

```
C:\Users\Administrator>sc start null

[SC] StartService 失败 577:

Windows 无法验证此文件的数字签名。某软件或硬件最近有所更改，可能安装了签名错误或损毁的文件，或者安装的文件可能是来路不明的恶意软件。
```

`C:\Windows\System32\drivers\null.sys` 从其他系统上拷贝一个过来覆盖，再启动 null 服务就正常了：

```
C:\Users\Administrator>sc start null

SERVICE_NAME: null
        TYPE               : 1  KERNEL_DRIVER
        STATE              : 4  RUNNING
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0
        PID                : 0
        FLAGS              : 
```

如果你一下子找不到可用的 null.sys，可以试试我[这个]((https://img.hacpai.com/file/2018/02/null.sys)（for Windows10 64位）。

PS 这就是用盗版系统的下场。