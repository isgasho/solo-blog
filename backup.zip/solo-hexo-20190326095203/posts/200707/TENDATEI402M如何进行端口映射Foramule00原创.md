title: TENDA TEI402M如何进行端口映射(For amule)[00原创]
date: '2007-07-24 05:47:00'
updated: '2007-07-24 05:47:00'
tags: [Network Engineering, My Linux]
permalink: /articles/2007/07/23/1185198420000.html
---
呵呵，回到家了，终于可以用驴子和BT了！<br />家里现在3台电脑，用一个路由(TenDa tei402m)接入ADSL，用BT要做NAT映射，用驴子也要。。。。<br />下面说说驴子的映射配置：<br /><br />先进入192.168.0.1路由设置，然后进入 &ldquo;虚拟服务器 &rdquo;选项 ， 页面中有 &ldquo;启用&rdquo;&ldquo; 常用端口&rdquo; 后面的空格填写你emule使用的客户端口（在骡子选项&mdash;&mdash;连接中可以查到），然后是192.168.0.空格，这个应该是路由分配给你的ip地址，在电脑里查一下，后面选择端口类型。添加就可以了。例如，骡子的默认tcp端口是4662，udp是4672，你的ip是192.168.0.2，那页面上的设置就应该是 启用&mdash;&mdash; 常用端口 &mdash;&mdash;4662&mdash;&mdash; 192.168.0.2&mdash;&mdash; tcp 然后点击添加，添加以后选择刚添加的端口，点击下面的允许，然后照样子启用 &mdash;&mdash;常用端口 &mdash;&mdash;4672 &mdash;&mdash;192.168.0.2&mdash;&mdash; udp &mdash;&mdash;添加 &mdash;&mdash; 允许。然后就ok了。 不是很麻烦。<br /><br />呵呵，我的amule终于可以高速下载了！