title: Kenai.com 将与 java.net 合并
date: '2010-02-09 14:56:00'
updated: '2010-02-09 14:56:00'
tags: [NetBeans, Open Source]
permalink: /articles/2010/02/08/1265669760000.html
---
<p>Kenai.com在上周宣布将于4月2日之后关闭的信息之后，2月5号Kenai的管理员Ted Farrel又在首页上发布了重要的信息。
<br />
<br />
首先，Ted 
Farrel做了检讨，他认为，在Oracle和SUN合并之后，没有和管理层很好地沟通关于Kenai的发展计划，为此他将尽力地弥补自己的过失。
<br />
<br />
其次，他说明，关闭kenai只是为了减少重复建设，因此，kenai.com的技术架构将被转移到java.net，这意味着，现在
kenai.com上的项目可以不必转移到其他的项目管理站点上去了，只要开发者愿意，他们的项目将被无缝地转移到java.net。目前，将
java.net改造为Kenai基础架构的工作正在进行中。Ted 
Farrel建议开发者可以先留在Kenai.com，这个月（2010年2月）晚些时候，他将通知开发者相关事项。
<br />
<br />
Kenai是SUN推动建立的项目协作和管理站点，具有很多独特的功能，并且已经被集成在著名的开发工具NetBeans中。由于和IDE直接集
成，Kenai已经在Java的开发者中得到了认可。很多著名的开源项目都驻留在Kenai.com上，比如用来开发Google 
AppEngine的NetBeans插件。Kenai.com宣布关闭之后，在开源界引起了很大的震动，有报道指出，Oracle关闭Kenai的原因
是想将其用于内部工作，并准备让自己的客户付费使用Kenai。很多人指责Oracle正在做出一项非常错误的决定，违背了在收购SUN时做出的承诺。
Kenai.com上的开发者也发出了拯救Kenai的号召。
<br />
<br />
值得庆幸的是，这种声音似乎起到了作用，现在，开发者可以继续使用Kenai提供的技术了，在不远的将来，只需要将域名指向java.net就可
以了;同时，我们也应该在NetBeans下一版中看到这一变化。
      </p>
<p>&nbsp;</p>
<p>转自：http://www.javaeye.com/news/13351</p>