title: Spring Framework 2.5 Reference中文翻译计划(phaseI)
date: '2008-04-01 08:39:00'
updated: '2008-04-01 08:39:00'
tags: [Open Source, Spring Framework]
permalink: /articles/2008/03/31/1206981540000.html
---
<h3><strong><u>Spring Framework 2.5 Reference翻译计划(phaseI)</u></strong></h3>
<p>Spring 开发参考手册由Spring 中文论坛<span class="nobr"><a rel="nofollow" title="Visit page outside Confluence" href="http://spring.jactiongroup.net/">http://spring.jactiongroup.net<sup><img width="7" height="7" border="0" align="absmiddle" alt="" src="http://wiki.redsaga.com/confluence/images/icons/linkext7.gif" class="rendericon" /></sup></a></span>发 起、组织，Spring 开发手册长期以来经过Spring翻译小组的公共努力，已经成功推出了两个版本，为Spring这样优秀的开源技术在中文世界的推广做出了积极的贡献。 Spring1.1开发参考手册1.1版本，在推出后下载量两周内就达到了2万以上。在线版本更是为众多的spring开发者提供了便捷的开发服务。</p>
<p>随着Spring Framework的飞速发展，以更全面的企业服务和便利的开发优势，Spring2.0+成为了更多程序员J2EE开发的首选框架。为了让更多的朋友能快 速掌握Spring2.0+的开发优势和了解优秀的构架思想，Spring论坛协同满江红开放技术研究组织(Hibernate开发手册翻译团队) <span class="nobr"><a rel="nofollow" title="Visit page outside Confluence" href="http://wiki.redsaga.com/">http://wiki.redsaga.com<sup><img width="7" height="7" border="0" align="absmiddle" alt="" src="http://wiki.redsaga.com/confluence/images/icons/linkext7.gif" class="rendericon" /></sup></a></span>， 共同发起Spring2.5.x Reference的翻译项目。相信凝聚Spring、Hibernate两个项目组文档翻译的丰富经验，我们能为Spring爱好者们共同打造出一份优 秀的Spring开发手册，同时，我们希望更多的朋友参与这个项目，为爱好Spring，爱好开源的人们奉献出微薄之力。</p>
<h2><a name="Spring2.5-项目计划:"></a>项目计划:</h2>
<h3><a name="Spring2.5-概述:"></a>概述:</h3>
<p>1、时间安排方面，在确保质量的前提下整个翻译工作在8周内完成，一期安排在4周内完成翻译（将有一个预览版本发布），随后4周进行一审和二审（不断发布迭代版本），校对工作完成后发布正式版本。一般任务按照章节进行分配，大的章节将被拆为不同的小节。</p>
<p>2、参与者以自愿方式在网上加入翻译工作，参与者在申请时必须留下明确的联系方式（电话/手机）以方便Leader进行联系，并注明期望得到的 wiki/cvs的用户名和希望认领的章节。工作分配由Leader安排，原则上按照先到先得的方式。具体的安排在wiki上公布。参与者将被加入不公开 的邮件列表中。吸取以往翻译的教训，为保证Leader的管理时间，原则上不安排Leader的翻译工作，或安排较少的章节。</p>
<p>3、在翻译开始后，翻译者必须每周的周三、周六两天晚上10点前在Wiki上通报翻译进度，对未在规定时间通报进度者负责人将直接与其联系询问情 况，连续两次无理由未通报进度者将被认为已经脱离联系，为不影响整体进度，原工作将安排另外人员接手。Wiki仅做交流通报使用，参与者通过CVS交换文 档，每位参与者完成翻译后在本地编译通过后提交CVS。</p>
<p>4、Leader将维护翻译术语表，翻译者可将翻译时遇到的术语提交在Wiki上，负责人将进行整理和总结，添加至术语表中。参与翻译与校对工作的参与者请尽力确保整篇文档各个部分的术语翻译一致。</p>
<p>5、文档将按原Spring Reference英文文档的协议发布，全体参与者一致同意放弃除署名权外的所有权利。在前言中将按章节列出所有参与者，参与翻译，但因个人原因退出者将被列在致谢名单中。</p>
<p>6、所有参与者将可以获得此次活动的纪念专题纪念品一件！</p>
<h3><a name="Spring2.5-项目计划时间："></a>项目计划时间：</h3>
<p>2008年3月01日~2008年4月30日</p>
<h3><a name="Spring2.5-项目负责人(Lead)："></a>项目负责人(Lead)：</h3>
<p>&nbsp;丁雪丰 (Digital Sonic) @ 上海</p>
<h3><a name="Spring2.5-报名:&amp;nbsp;"></a>报名: &nbsp;</h3>
<p>发送email到&nbsp; [ dxf_digitalsonic-redsaga at yahoo.com.cn ]<br /> 请注明您的姓名、网名，用于联系的邮件地址，所在城市，电话（重要！）。（第一次参与翻译者将可能被要求进行测试）<br /> 此次更新暂定为内部项目，先接受内部报名，但也欢迎网友报名。</p>
<br />
<h2 style="color: rgb(255, 0, 0);">到目前为止，</h2>
<h2>Spring Framework 2.5 Reference翻译参与人员列表(按报名先后排列)</h2>
<table class="confluenceTable">
    <tbody>
        <tr>
            <th class="confluenceTh"> 网名 </th>
            <th class="confluenceTh"> 姓名 </th>
            <th class="confluenceTh">&nbsp;</th>
            <th class="confluenceTh"> 网名 </th>
            <th class="confluenceTh"> 姓名 </th>
        </tr>
        <tr>
            <td class="confluenceTd"> Yanger </td>
            <td class="confluenceTd"> 杨戈 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> caoxg </td>
            <td class="confluenceTd"> 曹晓钢&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> DigitalSonic </td>
            <td class="confluenceTd"> 丁雪丰 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> Marco Chen </td>
            <td class="confluenceTd"> 陈邦宏&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> downpour </td>
            <td class="confluenceTd"> 陆舟 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> joyheros </td>
            <td class="confluenceTd"> 邓超&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> jzk </td>
            <td class="confluenceTd"> 蒋臻恺 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> whimet </td>
            <td class="confluenceTd"> 李彦辉 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> melthaw </td>
            <td class="confluenceTd"> 张辰雪 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> crazycy </td>
            <td class="confluenceTd"> 崔毅&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> pesome </td>
            <td class="confluenceTd"> 张俊 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> zhanglong&nbsp; </td>
            <td class="confluenceTd"> 张龙 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> ginge </td>
            <td class="confluenceTd"> 植晶晶 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> Kxllen </td>
            <td class="confluenceTd"> 徐坤 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> Jin </td>
            <td class="confluenceTd"> 金星星 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> Java笨狗 </td>
            <td class="confluenceTd"> 陶欢腾 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> Joo </td>
            <td class="confluenceTd"> 栗磊 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> YuLimin&nbsp; </td>
            <td class="confluenceTd"> 俞黎敏 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> Echo </td>
            <td class="confluenceTd"> 杨春花 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> yeshucheng </td>
            <td class="confluenceTd"> 万国辉 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 华仔 </td>
            <td class="confluenceTd"> 张静华 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> Denis </td>
            <td class="confluenceTd"> 王寅钢 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> hanson2010 </td>
            <td class="confluenceTd"> 胡海生 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 88250 </td>
            <td class="confluenceTd"> 丁亮&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> max </td>
            <td class="confluenceTd"> 孙浩 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
    </tbody>
</table>
<br />
<h2><span style="margin: 0px; padding: 0px; text-decoration: none;" class="pagetitle">                                         工作安排及进度概况(Spring 2.5)</span></h2>
<table class="confluenceTable">
    <tbody>
        <tr>
            <th class="confluenceTh"> 章节 </th>
            <th class="confluenceTh"> 翻译 </th>
            <th class="confluenceTh"> 一审 </th>
            <th class="confluenceTh"> 二审 </th>
            <th class="confluenceTh"> 进度 </th>
            <th class="confluenceTh"> 进度更新时间 </th>
        </tr>
        <tr>
            <td class="confluenceTd"> TOC (index.xml / 42 / 11KB)&nbsp; </td>
            <td class="confluenceTd"> caoxg </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> Preface (preface.xml / new / 3KB)&nbsp; </td>
            <td class="confluenceTd"> caoxg </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 1.Introduction (overview.xml / 30 / 13KB)&nbsp; </td>
            <td class="confluenceTd"> caoxg </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 2.What's new in Spring 2.0 and 2.5? (new-in-2.xml / 66 / 39KB)&nbsp; </td>
            <td class="confluenceTd"> caoxg </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> I. Core Technologies&nbsp;&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3. The IoC container (beans.xml / 585 / 304KB)&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3.1. Introduction <br clear="all" /> 3.2. Basics - containers and beans </td>
            <td class="confluenceTd"> macrochen </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-26 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3.3. Dependencies </td>
            <td class="confluenceTd"> macrochen </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-26 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3.4. Bean scopes&nbsp; <br clear="all" /> 3.5. Customizing the nature of a bean </td>
            <td class="confluenceTd"> kxllen </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-80% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3.6. Abstract and child bean definitions <br clear="all" /> 3.7. Container extension points <br clear="all" /> 3.8. The ApplicationContext <br clear="all" /> 3.9. Glue code and the evil singleton </td>
            <td class="confluenceTd"> kxllen </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-20% </td>
            <td class="confluenceTd"> 2008-03-19 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 3.10. Deploying a Spring ApplicationContext as a J2EE RAR file <br clear="all" /> 3.11. Annotation-based configuration <br clear="all" /> 3.12. Classpath scanning for managed components <br clear="all" /> 3.13. Registering a LoadTimeWeaver&nbsp; </td>
            <td class="confluenceTd"> &nbsp;88250 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-10% <br clear="all" /> </td>
            <td class="confluenceTd"> 2008-03-31 <br clear="all" /> </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 4. Resources (resources.xml / 58 / 37KB) </td>
            <td class="confluenceTd"> zhanglong </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-80% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 5. Validation, Data-binding, the BeanWrapper, and PropertyEditors (validation.xml / 28 / 41KB) </td>
            <td class="confluenceTd"> zhanglong </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-70% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 6. Aspect Oriented Programming with Spring (aop.xml / 519 / 169KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 6.1. Introduction <br clear="all" /> 6.2. @AspectJ support <br clear="all" /> 6.3. Schema-based AOP support </td>
            <td class="confluenceTd"> joyheros </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-50% </td>
            <td class="confluenceTd"> 2008-03-31 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 6.4. Choosing which AOP declaration style to use <br clear="all" /> 6.5. Mixing aspect types </td>
            <td class="confluenceTd"> Joo </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> &nbsp;翻译-70% </td>
            <td class="confluenceTd"> &nbsp;2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 6.6. Proxying mechanisms <br clear="all" /> 6.7. Programmatic creation of @AspectJ Proxies <br clear="all" /> 6.8. Using AspectJ with Spring applications <br clear="all" /> 6.9. Further Resources&nbsp;&nbsp; </td>
            <td class="confluenceTd"> Joo </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> &nbsp;翻译-70% </td>
            <td class="confluenceTd"> &nbsp;2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 7. Spring AOP APIs (aop-api.xml / 48&nbsp;/ 89KB) </td>
            <td class="confluenceTd"> Joo </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-20 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 8. Testing (testing.xml / 71 / 106KB) </td>
            <td class="confluenceTd"> zhanglong </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-70% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> II. Middle Tier Data Access </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 9. Transaction management (transaction.xml / 132 / 112KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 9.1. Introduction <br clear="all" /> 9.2. Motivations <br clear="all" /> 9.3. Key abstractions <br clear="all" /> 9.4. Resource synchronization with transactions <br clear="all" /> 9.5. Declarative transaction management </td>
            <td class="confluenceTd"> jzk </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> &nbsp;2008-03-23 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 9.6. Programmatic transaction management <br clear="all" /> 9.7. Choosing between programmatic and declarative transaction management <br clear="all" /> 9.8. Application server-specific integration <br clear="all" /> 9.9. Solutions to common problems <br clear="all" /> 9.10. Further Resources&nbsp;&nbsp; </td>
            <td class="confluenceTd"> jzk </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 10. DAO support (dao.xml / 15 / 6KB) </td>
            <td class="confluenceTd"> jzk </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 11. Data access using JDBC (jdbc.xml / 160 / 115KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 11.1. Introduction <br clear="all" /> 11.2. Using the JDBC Core classes to control basic JDBC processing and error handling <br clear="all" /> 11.3. Controlling database connections </td>
            <td class="confluenceTd"> downpour&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> &nbsp;2008-03-16 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 11.4. JDBC batch operations <br clear="all" /> 11.5. Simplifying JDBC operations with the SimpleJdbc classes </td>
            <td class="confluenceTd"> downpour&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 11.6. Modeling JDBC operations as Java objects <br clear="all" /> 11.7. Common issues with parameter and data value handling </td>
            <td class="confluenceTd"> downpour&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 12. Object Relational Mapping (ORM) data access (orm.xml / 244 / 133KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 12.1. Introduction <br clear="all" /> 12.2. Hibernate </td>
            <td class="confluenceTd"> max </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 12.3. JDO <br clear="all" /> 12.4. Oracle TopLink <br clear="all" /> 12.5. iBATIS SQL Maps </td>
            <td class="confluenceTd"> 华仔&nbsp; </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-50%&nbsp; </td>
            <td class="confluenceTd"> 2008-03-29&nbsp; </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 12.6. JPA <br clear="all" /> 12.7. Transaction Management <br clear="all" /> 12.8. JpaDialect </td>
            <td class="confluenceTd"> Echo </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 2008-03-13 </td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> III. The Web </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 13. Web MVC framework (mvc.xml / 451 / 179KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 13.1. Introduction <br clear="all" /> 13.2. The DispatcherServlet <br clear="all" /> 13.3. Controllers <br clear="all" /> 13.4. Handler mappings </td>
            <td class="confluenceTd"> whimet </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-40% </td>
            <td class="confluenceTd"> 2008-03-26 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 13.5. Views and resolving them <br clear="all" /> 13.6. Using locales <br clear="all" /> 13.7. Using themes <br clear="all" /> 13.8. Spring's multipart (fileupload) support </td>
            <td class="confluenceTd"> whimet </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-40% </td>
            <td class="confluenceTd"> 2008-03-26 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 13.9. Using Spring's form tag library <br clear="all" /> 13.10. Handling exceptions </td>
            <td class="confluenceTd"> hanson2010 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-30 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 13.11. Convention over configuration <br clear="all" /> 13.12. Annotation-based controller configuration <br clear="all" /> 13.13. Further Resources <br clear="all" /> Sidebar. Spring WebFlow (swf-sidebar.xml / 2 / 1KB) </td>
            <td class="confluenceTd"> hanson2010 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-10% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 14. Integrating view technologies (views.xml / 84 / 78KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 14.1. Introduction <br clear="all" /> 14.2. JSP &amp; JSTL <br clear="all" /> 14.3. Tiles <br clear="all" /> 14.4. Velocity &amp; FreeMarker </td>
            <td class="confluenceTd"> Java笨狗 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-22 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 14.5. XSLT <br clear="all" /> 14.6. Document views (PDF/Excel) <br clear="all" /> 14.7. JasperReports </td>
            <td class="confluenceTd"> Java笨狗 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 2008-03-10 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 15. Integrating with other web frameworks (webintegration.xml / 20 / 51KB) <br clear="all" /> 16. Portlet MVC Framework&nbsp;(portlet.xml / 9 / 60KB) </td>
            <td class="confluenceTd"> 华仔 </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-70%&nbsp; </td>
            <td class="confluenceTd"> 2008-03-22 </td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> IV. Integration </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 17. Remoting and web services using Spring (remoting.xml / 119&nbsp;/&nbsp;56KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 17.1. Introduction <br clear="all" /> 17.2. Exposing services using RMI <br clear="all" /> 17.3. Using Hessian or Burlap to remotely call services via HTTP <br clear="all" /> 17.4. Exposing services using HTTP invokers </td>
            <td class="confluenceTd"> pesome </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-80% </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 17.5. Web Services <br clear="all" /> 17.6. JMS <br clear="all" /> 17.7. Auto-detection is not implemented for remote interfaces <br clear="all" /> 17.8. Considerations when choosing a technology </td>
            <td class="confluenceTd"> pesome </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 18. Enterprise Java Bean (EJB) integration (ejb.xml / 16 / 22KB) </td>
            <td class="confluenceTd"> yeshucheng </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-50% </td>
            <td class="confluenceTd"> 2008-03-30 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 19. JMS (jms.xml / 56 / 63KB) </td>
            <td class="confluenceTd"> crazycy </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-23 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 20. JMX (jmx.xml / 157 / 75KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 20.1. Introduction <br clear="all" /> 20.2. Exporting your beans to JMX <br clear="all" /> 20.3. Controlling the management interface of your beans </td>
            <td class="confluenceTd"> ginge </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-19 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 20.4. Controlling the ObjectNames for your beans <br clear="all" /> 20.5. JSR-160 Connectors <br clear="all" /> 20.6. Accessing MBeans via Proxies <br clear="all" /> 20.7. Notifications <br clear="all" /> 20.8. Further Resources </td>
            <td class="confluenceTd"> ginge </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-20 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 21. JCA CCI (cci.xml / 41 / 51KB) </td>
            <td class="confluenceTd"> YuLimin </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-0% </td>
            <td class="confluenceTd"> 2008-03-12 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 22. Email (mail.xml / 42 / 19KB) </td>
            <td class="confluenceTd"> downpour </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-16 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 23. Scheduling and Thread Pooling (scheduling.xml / 49&nbsp;/ 22KB) </td>
            <td class="confluenceTd"> downpour </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-16 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 24. Dynamic language support (dynamic-languages.xml / 81 / 53KB) </td>
            <td class="confluenceTd"> melthaw </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-23 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 24.1. Introduction <br clear="all" /> 24.2. A first example <br clear="all" /> 24.3. Defining beans that are backed by dynamic languages </td>
            <td class="confluenceTd"> melthaw </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-23 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 24.4. Scenarios <br clear="all" /> 24.5. Bits and bobs <br clear="all" /> 24.6. Further Resources </td>
            <td class="confluenceTd"> melthaw </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-23 </td>
        </tr>
        <tr>
            <td class="confluenceTd"> 25. Annotations and Source Level Metadata Support (metadata.xml&nbsp;/ 20 / 24KB) </td>
            <td class="confluenceTd"> Joo </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-100% </td>
            <td class="confluenceTd"> 2008-03-18 </td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> V. Sample applications </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 26. Showcase applications (showcases.xml / new / 1KB) </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> <br clear="all" /> </td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
        <tr>
            <td class="confluenceTd"> 26.1. Introduction <br clear="all" /> 26.2. Spring MVC Controllers implemented in a dynamic language <br clear="all" /> (showcases\dynamvc\doc.xml / new / 4KB) <br clear="all" /> 26.3. Implementing DAOs using SimpleJdbcTemplate and @Repository <br clear="all" /> (showcases\java5-dao\doc.xml / new / 4KB) </td>
            <td class="confluenceTd"> Denis </td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd"> 翻译-80%&nbsp; </td>
            <td class="confluenceTd"> 2008-03-29 </td>
        </tr>
        <tr>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
            <td class="confluenceTd">&nbsp;</td>
        </tr>
    </tbody>
</table>
<br /><br />呵呵，照这个进度的话我相信4月底一定可以完成了！！！！