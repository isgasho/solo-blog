title: eclipse中的serialVersionUID警告[00原创]
date: '2007-08-07 15:38:00'
updated: '2007-08-07 15:38:00'
tags: [Eclipse]
permalink: /articles/2007/08/06/1186443480000.html
---
eclipse中经常提示：<br /><br /><font color="#ff0000">The serializable class AddUserForm does not declare a static final serialVersionUID field of type long</font> <br /><br />查了一下，如下说：<br /><br />serialVersionUID 用来表明类的不同版本间的兼容性.如果你修改了此类, 要修改此值. 否则以前用老版本的类序列化的类恢复时会出错.<br />　　可以利用JDK的bin目录下的serialver.exe工具产生这个serialVersionUID<br />　　对于Test.class,执行命令： serialver Test<br />　 　为了在反序列化时，确保类版本的兼容性，最好在每个要序列化的类中加入private static final long serialVersionUID这个属性，具体数值自己定义。这样，即使某个类在与之对应的对象已经序列化出去后做了修改，该对象依然可以被正确反序列 化。否则，如果不显示定义该属性，这个属性值将由JVM根据类的相关信息计算，而修改后的类的计算结果与修改前的类的计算结果往往不同，从而造成对象的反 序列化因为类版本不兼容而失败。<br />　　不显示定义这个属性值的另一个坏处是，不利于程序在不同的JVM之间的移植。因为不同的编译器实现的该属性值的计算策略可能不同，从而造成虽然类没有改变，但是因为JVM不同，依然会有因类版本不兼容而无法正确反序列化的现象出现。<br /><br />可以用Ctrl+1进行自动修正:-)