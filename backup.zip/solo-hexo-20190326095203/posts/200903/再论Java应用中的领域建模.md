title: 再论 Java 应用中的“领域建模”
date: '2009-03-24 01:39:00'
updated: '2015-02-17 19:23:42'
tags: [JBoss Seam, Software Engineering, Java Persistence API, J2EE/JavaEE, Architecture
    Design, EJB 3.x]
permalink: /articles/2009/03/23/1237801140000.html
---
<h1><a id="_Java_8586819757090429_2534334" name="_Java_8586819757090429_2534334"></a> 再论 Java 应用中的&ldquo;领域建模&rdquo;</h1>
<p>&nbsp;</p>
<p style="font-family: Verdana;">转载请保留作者信息：</p>
<p style="font-family: Verdana;">作者：88250</p>
<p style="font-family: Verdana;">Blog：<a href="http://blog.csdn.net/DL88250"><span style="color: #2300dc;">http:/blog.csdn.net/DL88250 <br /> </span> </a></p>
<p style="font-family: Verdana;"><span style="font-family: Verdana;">MSN &amp; Gmail &amp; QQ：DL88250@gmail.com </span></p>
<p style="font-family: Verdana;">&nbsp;</p>
<p style="font-family: Verdana;">&nbsp;</p>
<div id="WritelyTableOfContents" class="writely-toc"><ol class="writely-toc-none">
<li><a href="#_Java_8586819757090429_2534334" target="_self">再论 Java 应用中的&ldquo;领域建模&rdquo;</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="#1_4989230424423763_48548911551" target="_self">相关术语与概念</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="#1_1_POJO_Plain_Old_Java_Object" target="_self">POJO（Plain Old Java Object）</a></li>
<li><a href="#1_2_Domain_Model_8521481592546" target="_self">领域模型（Domain Model）</a></li>
<li><a href="#1_4_Style_6844703077777617_167" target="_self">各种风格（Style）的领域模型</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="#3_1_Anemic_Domain_Model_718666" target="_self">贫血的领域模型（Anemic Domain Model）</a></li>
<li><a href="#1_3_2_Rich_Domain_Model_032032_8507447456431984" target="_self">富领域模型（Rich Domain Model）</a></li>
</ol></li>
</ol></li>
<li><a href="#2_9860244643874926_69775184362" target="_self">&ldquo;公认&rdquo;的问题</a><ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="#2_1_EJB_3_8413102627609017_543_1669382981823745" target="_self">EJB 3 ＆ JPA</a></li>
<li><a href="#2_Domain_Logic_v_s_Business_Lo" target="_self">Domain Logic vs Business Logic</a></li>
</ol></li>
<li><a href="#5_04324820484365799_7262811230" target="_self">结论</a></li>
<li><a href="#4_7478917358259445_58122038122_6494631905789775" target="_self">参考列表</a></li>
</ol></li>
</ol></div>
<p><br /> <br /> 最近又重新整理了一下项目中领域模型建模的思路。记得范凯（<a id="qwki" title="robbin" href="http://robbin.javaeye.com/">robbin</a> ） 在 2005 年时候总结的四种风格的&ldquo;领域模型&rdquo;及其一些变种相信大家的耳熟能详了。以现在的观点来看，不管其划分是否合理，是否适合任何项目，讨论都是有意义的。从 2004 年到 2008 年来领域模型的话题一直都是各个技术论坛、邮件列表必讨论的话题之一，这里我只是想就&lsquo;领域模型建模&rsquo;这个问题发表一下我的观点，相信讨论还会继续下去，这才是本质&mdash;&mdash;演化。这里的观点都是基于 Java 环境上的应用展开的，其他语言环境另当别论。</p>
<h2><a id="1_4989230424423763_48548911551" name="1_4989230424423763_48548911551"></a> 相关术语与概念 </h2>
<p>首先，让我们澄清一些相关术语与概念。很多时候发现大家讨论问题前都没有一个共同的基本假设作为前提，导致了问题越讨论越混乱，引入的其他问题越来越多。这里，我先对本文涉及的几个非常基本的概念做个统一的假设。</p>
<h3><a id="1_1_POJO_Plain_Old_Java_Object" name="1_1_POJO_Plain_Old_Java_Object"></a> POJO（<a id="j278" title="Plain Old Java Object" href="http://www.martinfowler.com/bliki/POJO.html">Plain Old Java Object</a> ） </h3>
<p>POJO 是一个简单的、常规的 Java 对象，它包含业务逻辑处理或持久化逻辑等，但不是 JavaBean、EntityBean 等，不具有任何特殊角色并且不继承/不实现任何其它 Java 框架的类或接口（java.io.Serializable 除外）。例如下面这个类就是一个 POJO，注意业务逻辑方法：<br /> <span style="font-family: Courier New;"><span style="font-size: xx-small;"><br /> <br /> /**<br /> &nbsp;* A POJO user description.<br /> &nbsp;* @author <a href="mailto:DL88250@gmail.com">88250</a> <br /> &nbsp;* @version 1.0.0.0, Jan 15, 2009<br /> &nbsp;*/<br /> public class User implements Serializable {<br /> <br /> &nbsp;&nbsp;&nbsp; /**<br /> &nbsp;&nbsp;&nbsp;&nbsp; * user name.<br /> &nbsp;&nbsp;&nbsp;&nbsp; */<br /> &nbsp;&nbsp;&nbsp; private String name;<br /> <br /> &nbsp;&nbsp;&nbsp; /**<br /> &nbsp;&nbsp;&nbsp;&nbsp; * Default constructor.<br /> &nbsp;&nbsp;&nbsp;&nbsp; */<br /> &nbsp;&nbsp;&nbsp; public User() {<br /> &nbsp;&nbsp;&nbsp; }<br /> <br /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp; /**</span> <br style="color: #0b5394;" /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp;&nbsp; * User login business logic.</span> <br style="color: #0b5394;" /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp;&nbsp; */</span> <br style="color: #0b5394;" /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp; public void login() {</span> <br style="color: #0b5394;" /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // ....</span> <br style="color: #0b5394;" /> <span style="color: #0b5394;">&nbsp;&nbsp;&nbsp; }</span> <br /> <br /> &nbsp;&nbsp;&nbsp; /**<br /> &nbsp;&nbsp;&nbsp;&nbsp; * Gets the name of this user.<br /> &nbsp;&nbsp;&nbsp;&nbsp; * @return the value of <code>name</code> <br /> &nbsp;&nbsp;&nbsp;&nbsp; */<br /> &nbsp;&nbsp;&nbsp; public String getName() {<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; return name;<br /> &nbsp;&nbsp;&nbsp; }<br /> <br /> &nbsp;&nbsp;&nbsp; /**<br /> &nbsp;&nbsp;&nbsp;&nbsp; * Sets the name of this user.<br /> &nbsp;&nbsp;&nbsp;&nbsp; * @param name new value of <code>name</code> <br /> &nbsp;&nbsp;&nbsp;&nbsp; */<br /> &nbsp;&nbsp;&nbsp; public void setName(String name) {<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; this.name = name;<br /> &nbsp;&nbsp;&nbsp; }<br /> }</span> <br /> <br /> </span> 从 OO 的角度看，这是一个纯粹的 Java 类，它拥有状态与行为，这也就构成了这个 User 类的职责。可惜现在 POJO 这个词简直是滥用啊，大家都认为只要描述的是一个领域<span style="color: #0b5394;">实体，一个纯数据类就是 POJO 了<span style="color: #000000;">。</span> </span></p>
<h3><a id="1_2_Domain_Model_8521481592546" name="1_2_Domain_Model_8521481592546"></a> 领域模型（<a id="eaz0" title="Domain Model" href="http://martinfowler.com/eaaCatalog/domainModel.html">Domain Model</a> ） </h3>
<p>根据 Martin 大叔的解释，领域模型就是统一了<strong><span style="color: #cc0000;">行为</span> </strong> 与<strong><span style="color: #38761d;">数据</span> </strong> 的<span style="color: #741b47;">对象模型</span> 。从 OO 的角度上看是没有任何难点与疑问的，但是开始对具体项目着手进行 OO 设计的时候问题就很多了，后面将阐述一些在实施领域模型建模时&ldquo;公认&rdquo;的问题。再来看看 Wikipedia 上关于<a id="zppr" title="领域模型的定义" href="http://en.wikipedia.org/wiki/Domain_model">领域模型的解释</a> ，其中涉及到了&ldquo;领域层（<a id="exsx" title="Domain Layer" href="http://en.wikipedia.org/wiki/Domain_layer">Domain Layer</a> ） &rdquo;这个概念，并且说明了<span style="color: #674ea7;"> DDD 中的领域模型是领域层的一个部分</span> 。如下图：</p>
<p>&nbsp;</p>
<p><img style="width: 648px; height: 469.469px;" src="https://pyqdbw-dm2305.files.1drv.com/y2pE2v1_U2G3ghy9FbBRCup9vhnPo1xSPmjNMoGQrPxZgL_tzw8sLOXP71DmkLaEJdDlctorsPDZAGdk7snzYbjrlkHxH-el35beZeYJJ3edGbh8ZXI51FUylLOTGraFfj_MVZaoop-d6yhA2FCe9VQgw/domain.png?psid=1" alt="domain" width="573" height="470" /></p>
<p>&nbsp;</p>
<p>根据 Wikipedia 上的解释，领域层与<a id="y.dc" title="业务层" href="http://en.wikipedia.org/wiki/Business_layer">业务层</a> 是同一个概念，这样划分的确是纯粹的 DDD。不过，这与 JavaEE 规范中的分层理念有一点冲突，与 EJB 3 编程模型有着明显的冲突。</p>
<h3><a id="1_4_Style_6844703077777617_167" name="1_4_Style_6844703077777617_167"></a> 各种风格（Style）的领域模型&nbsp; </h3>
<p>这里的&ldquo;风格&rdquo;是按照 Martin 的观点进行阐述的。在<strong><a id="cjrt" title="以往的讨论" href="http://www.javaeye.com/topic/17579">以往的讨论</a> </strong> 中，有四种可行的模型：</p>
<ul>
<li>失血模型</li>
<li>贫血模型</li>
<li>充血模型</li>
<li>胀血模型</li>
</ul>
<p><br /> 这四种模型基本是 <a id="qwki" title="robbin" href="http://robbin.javaeye.com/">robbin</a> 、<a id="fxkk" title="JavaEye" href="http://www.javaeye.com">JavaEye</a> 社区思考、讨论的结果。但我认为还是按照 Martin 的提出的模型进行讨论比较简洁，有两种可行的模型：</p>
<ul>
<li>贫血的领域模型（Anemic Domain Model）</li>
<li>富领域模型（Rich Domain Model）</li>
</ul>
<h4><a id="3_1_Anemic_Domain_Model_718666" name="3_1_Anemic_Domain_Model_718666"></a> 贫血的领域模型（<a id="dsme" title="Anemic Domain Model" href="http://www.martinfowler.com/bliki/AnemicDomainModel.html">Anemic Domain Model</a> ）</h4>
<p>贫血的领域模型就是在领域对象中<strong><span style="color: #ff0000;">只</span> </strong> 包含了 accessors 方法，默认的构造器，不包含任何逻辑处理。而逻辑处理放置于 xxxManager 中，使用事务脚本（<a id="g_sn" title="Transaction Script" href="http://martinfowler.com/eaaCatalog/transactionScript.html">Transaction Script</a> ，<a id="v2e4" title="PoEAA" href="http://martinfowler.com/books.html#eaa">PoEAA</a> ）进行操作。</p>
<p>&nbsp;</p>
<h4><a id="1_3_2_Rich_Domain_Model_032032_8507447456431984" name="1_3_2_Rich_Domain_Model_032032_8507447456431984"></a> 富领域模型（<a id="nyqd" title="Rich Domain Model" href="http://martinfowler.com/bliki/AnemicDomainModel.html">Rich Domain Model</a> ） </h4>
<p>富领域模型就是 DDD 中所描述的模型，完全的 <strong>OO Concerns</strong> 。</p>
<h2><a id="2_9860244643874926_69775184362" name="2_9860244643874926_69775184362"></a> &ldquo;公认&rdquo;的问题&nbsp;</h2>
<h3><a id="2_1_EJB_3_8413102627609017_543_1669382981823745" name="2_1_EJB_3_8413102627609017_543_1669382981823745"></a> EJB 3 ＆ JPA </h3>
<p>众所周知，EJB 3 + JPA 的编程模型是典型的贫血模型，也是 JavaEE 所推广的<strong><em>最佳实践</em> </strong> ，唯一正统的编程模型。 在这个模型中，EJBs 扮演了业务逻辑处理的角色，在分层设计中处于服务层 / 业务层。而 JPA entities 则扮演了典型的<strong>纯稚数据类</strong> ，其行为完全由 EJBs 负责。这些也许与早先的 SSH 这样一个<strong><span style="color: #b45f06;">无状态</span> </strong> 框架组合那么深入人心密切相关吧。目前来说，Seam 框架 / WebBeans 规范是解决客户端与服务端状态问题的较好实现与规范。另外，Seam 中的 Entity 也是可以作为 Component 而 inject / outject 的，所以 Seam <span style="color: #990000;">有在尝试</span> 提供一个 DDD 的框架给开发者。</p>
<h3><a id="2_Domain_Logic_v_s_Business_Lo" name="2_Domain_Logic_v_s_Business_Lo"></a> Domain Logic vs Business Logic</h3>
<p>如果你是一个 DDD 的纯粹拥护者，不存在区分领域逻辑与业务逻辑，统称为领域逻辑。下面这个划分领域逻辑与服务逻辑是针对类 EJB 3 + JPA 纯粹用户者的。<br /> Domain 业务逻辑（Domain Logic）与 Service 业务逻辑（Business Logic）划分的原则:</p>
<ol>
<li>根据是否依赖持久化逻辑划分<br /> 领域模型只包含不<span style="color: #ff0000;">依赖于持久化</span> 的领域逻辑，而那些依赖持久化的领域逻辑应该被分离到 Service 层</li>
<li>使用 Rod Johnson 的"case by case"原则 <br /> 可重用度高的，和 domain object <span style="color: #ff0000;">状态密切关联</span> 的放在 domain 中，可重用度低的，和 domain object 状态没有密切关联的放在 Service 中</li>
</ol>
<p>这样，貌似是解决了 Java 应用中使用&ldquo;正统&rdquo;方式（JavaEE 规范）实现领域驱动开发。但是，这样不觉得过于复杂和画蛇添足吗？<br /> <br /> <a id="4_Java_4529669216109383_700722_4885585786669472" name="4_Java_4529669216109383_700722_4885585786669472"></a></p>
<h2><a id="5_04324820484365799_7262811230" name="5_04324820484365799_7262811230"></a> 结论 </h2>
<p>领域模型驱动的设计（DDD）是需要开发团队在特定行业中<strong>积累</strong> 到一定的时候才能真正做到的，这涉及到了企业（客户）的核心价值实现与业务实现<span style="color: #cc0000;">重用</span> ，如果不是本着这个<strong>最终目的</strong> ，Java 下的 DDD 慎用。在建模你的 Java 项目时，一定要对项目的 Scope 做好分析，认真做好技术选型。一般来说，贫血模型（Anemic Domain Model）是最容易设计和实现的，也足够满足一般 Java Web 项目了。而领域模型（Rich Domain Model）是用在复杂 JavaEE 项目上的（例如实施 SOA 时），切勿杀鸡用牛刀 :-)</p>
<h2><a id="4_7478917358259445_58122038122_6494631905789775" name="4_7478917358259445_58122038122_6494631905789775"></a> 参考列表 </h2>
<p>下面的文章是精华中的精华，有兴趣、时间的朋友一定不要错过 :-)</p>
<ul>
<li><a id="f8lx" title="Anemic Domain Model" href="http://martinfowler.com/bliki/AnemicDomainModel.html">Anemic Domain Model</a></li>
<li><a href="http://www.javaeye.com/topic/11712">总结一下最近关于domain object以及相关的讨论</a></li>
<li><a href="http://www.javaeye.com/topic/283668">一个简单例子：贫血模型or领域模型</a></li>
<li><a href="http://robbin.javaeye.com/blog/283416">对领域模型实现的总结性观点</a></li>
<li><a href="http://www.javaeye.com/topic/281289">领域模型的价值与困境</a></li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>