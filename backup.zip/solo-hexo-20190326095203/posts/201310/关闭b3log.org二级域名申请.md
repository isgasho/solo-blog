title: 关闭 b3log.org 二级域名申请
date: '2013-10-25 05:03:12'
updated: '2013-10-25 05:03:12'
tags: [Life in Programming, B3log Solo, B3log Announcement]
permalink: /close-apply-b3log-subdomain
---
<p>从 b3log.org 提供<a href="http://88250.b3log.org/apply-b3log-domain.html">二级域名免费申请</a>到现在已经 3 年多的时间了，非常感谢大家一直以来的支持。</p>
<p>今天，B3log 团队将关闭二级域名申请（在用的用户依然可以正常使用），原因有很多（例如&nbsp;<a href="https://github.com/b3log/b3log-solo/issues/319" target="_blank">#319</a>），希望大家理解。</p>
<p>&nbsp;</p>
<p>另外，在 B3log Solo 0.6.5 发布后的下一个版本将有重大改变，非常欢迎大家来<a href="https://github.com/b3log/b3log-solo/issues/new" target="_blank">提交特性需求</a> :-p</p>
<p>&nbsp;</p>