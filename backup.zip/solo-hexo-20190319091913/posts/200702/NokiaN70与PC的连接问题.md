title: Nokia N70与PC的连接问题
date: '2007-02-12 05:36:00'
updated: '2007-02-12 05:36:00'
tags: [Solo]
permalink: /articles/2007/02/11/1171200960000.html
---
<p>今天郁闷了我一上午，Nokia N70手机与电脑连接不上。。。。</p>
<p>后来终于搞定了，在控制面板里删除所有与Nokia N70相关的东西，重装PC Suite。</p>
<p>这个连接问题是因为升级PC Suite造成的，真不知道Nokia的软件怎么做的。。。。&nbsp;</p>