title: GAE 配额优化
date: '2011-11-13 05:36:15'
updated: '2011-11-13 05:36:15'
tags: [GAE, Optimization, Java]
permalink: /gae-quota-optimization
---
<p>自从 GAE 毕业后，新的计费模型开始了实行。</p>
<p>新版的计费模型主要瓶颈在于数据库操作次数，特别是读操作（Datastore Read Operations）以及&ldquo;密集&rdquo;操作（Datastore Small Operations）。</p>
<h2>配额</h2>
<p>在官方文档 <a href="http://code.google.com/appengine/docs/quotas.html#Datastore" target="_blank"> Limits </a> 中对于数据操作的描述如下：</p>
<table border="1">
<tbody>
<tr><th>High-Level Operation</th><th>Low-Level Operations Required</th></tr>
<tr>
<td>Entity Get (per entity)</td>
<td>1 Read</td>
</tr>
<tr>
<td>New Entity Put (per entity, regardless of entity size)</td>
<td>2 Writes + 2 Writes per indexed property value + 1 Write per composite index value</td>
</tr>
<tr>
<td>Existing Entity Put (per entity)</td>
<td>1 Write + 4 Writes per modified indexed property value + 2 Writes per modified composite index value</td>
</tr>
<tr>
<td>Entity Delete (per entity)</td>
<td>2 Writes + 2 Writes per indexed property value + 1 Write per composite index value</td>
</tr>
<tr>
<td>Query</td>
<td>1 Read + 1 Read per entity returned</td>
</tr>
<tr>
<td>Query (keys only)</td>
<td>1 Read + 1 Small per entity returned</td>
</tr>
<tr>
<td>Key allocation (per key)</td>
<td>1 Small</td>
</tr>
</tbody>
</table>
<p>* Hight-Level 对应的其实是 <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/package-summary.html" target="_blank"> Low-level APIs </a> 调用</p>
<p>目前的免费配额情况：</p>
<table border="1">
<tbody>
<tr>
<td>Datastore Write Operations</td>
<td>0.05 Million Ops</td>
</tr>
<tr>
<td>Datastore Read Operations</td>
<td>0.05 Million Ops</td>
</tr>
<tr>
<td>Datastore Small Operations</td>
<td>0.05 Million Ops</td>
</tr>
</tbody>
</table>
<p>从中我们可以得知，正真的瓶颈是 Read 操作，因为一天只能有 5 万次调用。</p>
<p>特别是条件查询，假设返回结果集大小为 N，则实际是进行了 1 Read + N 次 Read 操作（1 Read + N per entity returned）。</p>
<h3>读操作</h3>
<p><a name="b3log-solo-index-example"></a>例如 <a href="http://b3log-solo.googlecode.com" target="_blank">B3log Solo</a> 首页渲染，文章列表部分用的是一个条件查询：</p>
<pre class="brush: java">final Query query = new Query().setCurrentPageNum(currentPageNum).
                    setPageSize(pageSize).
                    addFilter(Article.ARTICLE_IS_PUBLISHED,
                              FilterOperator.EQUAL, PUBLISHED).
                    addSort(Article.ARTICLE_PUT_TOP, SortDirection.DESCENDING);</pre>
<p>查询页号为 currentPageNum 的、页最多显示 pageSize 条记录、文章必须是已发布的、按置顶排序的文章列表。</p>
<p>假设满足条件的文章为 15 篇，则这次查询一共调用 16 次 Read 操作。</p>
<h3>分页</h3>
<p>分页需求是大多数应用的基础需求之一，分页所必须的参数是：</p>
<ul>
<li>页大小</li>
<li>总记录数</li>
</ul>
<p>然后我们可以计算出这两个参数计算出总页数（pageCount = ceil(sum/pageSize)），以便进行分页控制。</p>
<p>其中总记录数就是符合查询条件的结果集大小。GAE 上我们可以使用 <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/PreparedQuery.html#countEntities%28com.google.appengine.api.datastore.FetchOptions%29" target="_blank">count API</a>。</p>
<p>但是，count API 有个严重损耗配额的问题，count 执行相当于使用 keys 进行查询遍历。</p>
<p>假设满足查询条件的总记录数为 N，那么一次 count 调用相当于执行了 1 Read + N Small 次操作。</p>
<p>而通常情况下，N 会比较大。比如前面<a href="#b3log-solo-index-example">文章列表查询的例子</a>中，如果我有 1,000 篇发布了的文章，那么一次 count 调用相当于使用了 1 Read + 1000 Small 操作配额。</p>
<p>也就是说，在不考虑缓存的情况下，访问有 1,000 篇文章博客的首页至少需要花费 2% 的 Small 配额，50 次请求今天的免费配额就玩完了。</p>
<h2>优化策略</h2>
<p>在 <a href="http://88250.b3log.org/gae-java-performance-optimization.html" target="_blank"> 《GAE Java 应用性能优化》 </a> 一文中提到了缓存 HTML 页面以及缓存数据查询结果，这是比较通用的做法。而应用本身也需要考虑优化设计：</p>
<h3>维护条件查询的总记录计数</h3>
<p>还是以前面<a href="#b3log-solo-index-example">文章列表查询的例子</a>来看，如果应用维护了已发布文章的总数，那也就不必调用 count 接口了，而只需要查询这个总数（1 Read）。</p>
<h3>隐式分页</h3>
<p>也可以换个思路，对于查询量大的地方使用隐式分页，也就是不计算完整的分页结果，而只是提供&ldquo;下一页&rdquo;/&ldquo;上一页&rdquo;的请求入口。</p>
<h2>结论</h2>
<p>新的计费模型让一些没有足够优化的 GAE 应用瞬间倒下，即使是在实现上进行了足够优化的应用，也必须在功能上进行一定的精简，否则要想完全使用免费配额也是不可能的。</p>
<p>在应用设计之初就应该考虑尽量少的依赖数据 API（例如 count），能在应用中维护的数据就应该维护住，虽然这可能比较繁琐，但这也为将来的优化提供了数据支撑。</p>
<p>另外，我觉得我们也应该为使用 GAE 而付费 ;-)</p>