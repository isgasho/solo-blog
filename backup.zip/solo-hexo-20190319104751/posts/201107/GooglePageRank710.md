title: Google PageRank，7/10？
date: '2011-07-04 05:11:47'
updated: '2011-07-04 05:11:47'
tags: [Google, Life in Programming]
permalink: /articles/2011/07/03/1309698707512.html
---
<p>偶尔发现<a href="http://88250.b3log.org/" target="_blank">我的博客</a> Google PageRank（Google PR）的评分比较高（7/10），不知道是 Google 的失误还是长期持续努力的结果。</p>
<p>Google PageRank 的详细描述：<a href="http://en.wikipedia.org/wiki/PageRank" target="_blank">http://en.wikipedia.org/wiki/PageRank</a></p>
<p><img src="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/PageRanks-Example.svg/400px-PageRanks-Example.svg.png" alt="Google PR example" width="400" height="322" /></p>
<p>P.S.</p>
<ul>
<li>前不久 Google 刚进行了 PR 算法调整，等稳定一段时间再看看还有没有 7</li>
<li>查询是通过 <a href="http://www.prchecker.info/check_page_rank.php">http://www.prchecker.info/check_page_rank.php</a> 进行的</li>
</ul>