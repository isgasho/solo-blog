title: CPU温度检测的工具
date: '2007-05-01 07:37:00'
updated: '2007-05-01 07:37:00'
tags: [Windows]
permalink: /articles/2007/04/30/1177947420000.html
---
看看你的CPU温度能到几度...能不能达到<br /> 1.没温度<br /> 2.暖手<br /> 3.有点热<br /> 4.烧开水<br /> 5.烧烤<br /> <br /> <img border="0" src="http://bbs.sei.ynu.edu.cn/images/attachicons/zip.gif" class="absmiddle" alt="" /><a href="http://bbs.sei.ynu.edu.cn/member.php?action=credits&amp;view=getattach" target="_blank">附件</a>:  <a href="http://bbs.sei.ynu.edu.cn/attachment.php?aid=46341" target="_blank" class="bold">CoreTemp.zip</a>