title: Java 日期格式模式
date: '2014-03-11 21:19:33'
updated: '2014-03-11 21:19:33'
tags: [DateFormat, Java]
permalink: /java-dateformat
---
<p>DateFormat 的使用就不介绍了，主要是记录一下用到的格式模式。</p>
<table summary="Chart shows pattern letters, date/time component, presentation, and examples." border="0" cellspacing="3" cellpadding="0">
<tbody>
<tr bgcolor="#ccccff"><th align="left">字母</th><th align="left">日期或时间元素</th><th align="left">表示</th><th align="left">示例</th></tr>
<tr>
<td><code>G</code></td>
<td>Era 标志符</td>
<td>Text</td>
<td><code>AD</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>y</code></td>
<td>年</td>
<td>Year</td>
<td><code>1996</code>;&nbsp;<code>96</code></td>
</tr>
<tr>
<td><code>M</code></td>
<td>年中的月份</td>
<td>Month</td>
<td><code>July</code>;&nbsp;<code>Jul</code>;&nbsp;<code>07</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>w</code></td>
<td>年中的周数</td>
<td>Number</td>
<td><code>27</code></td>
</tr>
<tr>
<td><code>W</code></td>
<td>月份中的周数</td>
<td>Number</td>
<td><code>2</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>D</code></td>
<td>年中的天数</td>
<td>Number</td>
<td><code>189</code></td>
</tr>
<tr>
<td><code>d</code></td>
<td>月份中的天数</td>
<td>Number</td>
<td><code>10</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>F</code></td>
<td>月份中的星期</td>
<td>Number</td>
<td><code>2</code></td>
</tr>
<tr>
<td><code>E</code></td>
<td>星期中的天数</td>
<td>Text</td>
<td><code>Tuesday</code>;&nbsp;<code>Tue</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>a</code></td>
<td>Am/pm 标记</td>
<td>Text</td>
<td><code>PM</code></td>
</tr>
<tr>
<td><code>H</code></td>
<td>一天中的小时数（0-23）</td>
<td>Number</td>
<td><code>0</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>k</code></td>
<td>一天中的小时数（1-24）</td>
<td>Number</td>
<td><code>24</code></td>
</tr>
<tr>
<td><code>K</code></td>
<td>am/pm 中的小时数（0-11）</td>
<td>Number</td>
<td><code>0</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>h</code></td>
<td>am/pm 中的小时数（1-12）</td>
<td>Number</td>
<td><code>12</code></td>
</tr>
<tr>
<td><code>m</code></td>
<td>小时中的分钟数</td>
<td>Number</td>
<td><code>30</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>s</code></td>
<td>分钟中的秒数</td>
<td>Number</td>
<td><code>55</code></td>
</tr>
<tr>
<td><code>S</code></td>
<td>毫秒数</td>
<td>Number</td>
<td><code>978</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>z</code></td>
<td>时区</td>
<td>General time zone</td>
<td><code>Pacific Standard Time</code>;&nbsp;<code>PST</code>;&nbsp;<code>GMT-08:00</code></td>
</tr>
<tr>
<td><code>Z</code></td>
<td>时区</td>
<td>RFC 822 time zone</td>
<td><code>-0800</code></td>
</tr>
</tbody>
</table>
<p>实例：</p>
<table summary="Examples of date and time patterns interpreted in the U.S. locale" border="0" cellspacing="3" cellpadding="0">
<tbody>
<tr bgcolor="#ccccff"><th align="left">日期和时间模式</th><th align="left">结果</th></tr>
<tr>
<td><code>"yyyy.MM.dd G 'at' HH:mm:ss z"</code></td>
<td><code>2001.07.04 AD at 12:08:56 PDT</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>"EEE, MMM d, ''yy"</code></td>
<td><code>Wed, Jul 4, '01</code></td>
</tr>
<tr>
<td><code>"h:mm a"</code></td>
<td><code>12:08 PM</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>"hh 'o''clock' a, zzzz"</code></td>
<td><code>12 o'clock PM, Pacific Daylight Time</code></td>
</tr>
<tr>
<td><code>"K:mm a, z"</code></td>
<td><code>0:08 PM, PDT</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>"yyyyy.MMMMM.dd GGG hh:mm aaa"</code></td>
<td><code>02001.July.04 AD 12:08 PM</code></td>
</tr>
<tr>
<td><code>"EEE, d MMM yyyy HH:mm:ss Z"</code></td>
<td><code>Wed, 4 Jul 2001 12:08:56 -0700</code></td>
</tr>
<tr bgcolor="#eeeeff">
<td><code>"yyMMddHHmmssZ"</code></td>
<td><code>010704120856-0700</code></td>
</tr>
<tr>
<td><code>"yyyy-MM-dd'T'HH:mm:ss.SSSZ"</code></td>
<td><code>2001-07-04T12:08:56.235-0700</code></td>
</tr>
</tbody>
</table>