title: LivaPlayer正式挂入SF.NET[00原创]
date: '2007-09-16 00:54:00'
updated: '2007-09-16 00:54:00'
tags: [LivaPlayer]
permalink: /articles/2007/09/15/1189846440000.html
---
现在LivaPlayer已经正式挂入了SourceForge.NET了，如果有兴趣参与项目开发的朋友，可以访问如下网址：<br /><span class="postbody"><br /><a class="postlink" target="_blank" href="https://sourceforge.net/projects/livaplayer">https://sourceforge.net/projects/livaplayer</a><br /><br />项目期待你的参与！<br /></span>