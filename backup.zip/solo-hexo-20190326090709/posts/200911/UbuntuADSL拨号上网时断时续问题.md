title: Ubuntu ADSL 拨号上网时断时续问题
date: '2009-11-01 09:18:00'
updated: '2009-11-01 09:18:00'
tags: [My Linux]
permalink: /articles/2009/10/31/1257009480000.html
---
<p>在使用 pppoeconf 后可能出现网络链接时断时续以及网络管理器显示设备未托管。原因是 NetWorkManager 与 networking 命令有冲突，不能混合使用。如果遇到该问题，请尝试：</p>
<p>&nbsp;</p>
<p>1. 在终端里运行：</p>
<div class="codetitle"><strong><br />
</strong>
</div>
<div class="codecontent">sudo mv /etc/network/interfaces /etc/network/interfaces_backup</div>
<p><br />
2. 删除dns设置：</p>
<div class="codecontent">sudo mv /etc/resolv.conf /etc/resolv.conf_backup</div>
<p><br />
3. 重启network-manager服务：</p>
<div class="codecontent">sudo service network-manager restart</div>
<div class="codecontent"><br />
</div>
<div class="codecontent"><br />
</div>
<div class="codecontent">参考：</div>
<div class="codecontent">1. <a class="titles" href="http://forum.ubuntu.org.cn/viewtopic.php?f=116&amp;t=162276&amp;start=0" class="titles">[学习]ubuntu  网卡指定 eth0及其它</a>
</div>
<div class="codecontent">2. <a class="titles" href="http://forum.ubuntu.org.cn/viewtopic.php?f=116&amp;t=236555&amp;start=0" class="titles">ubuntu 9.10无法ADSL拨号以及Network Manager显示设备未托管的解决办法</a>
</div>
<div class="codecontent">
<pre><br />
</pre>
</div>