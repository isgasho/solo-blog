title: Google Code Bug
date: '2010-11-05 17:05:42'
updated: '2011-11-27 03:07:31'
tags: [Open Source, B3log, Google]
permalink: /articles/2010/11/05/1288919142093.html
---
<p>今早发现挂在 Google Code 上的 <a href="http://code.google.com/p/b3log-solo/">B3log Solo</a> 项目 <a href="http://code.google.com/p/b3log-solo/downloads/list?can=1&amp;q=&amp;colspec=Filename+Summary+Uploaded+Size+DownloadCount">Downloads</a> 出现了统计问题：</p>
<p><img src="https://sn2files.storage.live.com/y1pwhiP95TvdZpNPknq1ONHUTV_eBD-COUtkYjWaRB8ZgsXSyWOEm148mzJU-f07NvJJ2lbMxnbo2I/GooogleCodeBug.png?psid=1" alt="GoogleCode Bug" width="800" height="109" /></p>
<p>下载数统计于昨天半夜被清 0 了。</p>
<p>0.0.1-preview1 的上传日期变 1969 年？在我未出生之前就已经在使用为开发 Google Code？</p>
<p>。。。。</p>
<p>----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>